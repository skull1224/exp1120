﻿#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
This experiment was created using PsychoPy3 Experiment Builder (v2024.2.5),
    on 11월 17, 2026, at 11:19
If you publish work using this script the most relevant publication is:

    Peirce J, Gray JR, Simpson S, MacAskill M, Höchenberger R, Sogo H, Kastman E, Lindeløv JK. (2019) 
        PsychoPy2: Experiments in behavior made easy Behav Res 51: 195. 
        https://doi.org/10.3758/s13428-018-01193-y

"""

# --- Import packages ---
from psychopy import locale_setup
from psychopy import prefs
from psychopy import plugins
plugins.activatePlugins()
prefs.hardware['audioLib'] = 'ptb'
prefs.hardware['audioLatencyMode'] = '3'
from psychopy import sound, gui, visual, core, data, event, logging, clock, colors, layout, hardware
from psychopy.tools import environmenttools
from psychopy.constants import (NOT_STARTED, STARTED, PLAYING, PAUSED,
                                STOPPED, FINISHED, PRESSED, RELEASED, FOREVER, priority)

import numpy as np  # whole numpy lib is available, prepend 'np.'
from numpy import (sin, cos, tan, log, log10, pi, average,
                   sqrt, std, deg2rad, rad2deg, linspace, asarray)
from numpy.random import random, randint, normal, shuffle, choice as randchoice
import os  # handy system and path functions
import sys  # to get file system encoding

import psychopy.iohub as io
from psychopy.hardware import keyboard

# --- Setup global variables (available in all functions) ---
# create a device manager to handle hardware (keyboards, mice, mirophones, speakers, etc.)
deviceManager = hardware.DeviceManager()
# ensure that relative paths start from the same directory as this script
_thisDir = os.path.dirname(os.path.abspath(__file__))
# store info about the experiment session
psychopyVersion = '2024.2.5'
expName = 'sprt_final_A'  # from the Builder filename that created this script
# information about this experiment
expInfo = {
    'participant': f"{randint(0, 999999):06.0f}",
    'session': '001',
    'date|hid': data.getDateStr(),
    'expName|hid': expName,
    'psychopyVersion|hid': psychopyVersion,
}

# --- Define some variables which will change depending on pilot mode ---
'''
To run in pilot mode, either use the run/pilot toggle in Builder, Coder and Runner, 
or run the experiment with `--pilot` as an argument. To change what pilot 
#mode does, check out the 'Pilot mode' tab in preferences.
'''
# work out from system args whether we are running in pilot mode
PILOTING = core.setPilotModeFromArgs()
# start off with values from experiment settings
_fullScr = True
_winSize = (1024, 768)
# if in pilot mode, apply overrides according to preferences
if PILOTING:
    # force windowed mode
    if prefs.piloting['forceWindowed']:
        _fullScr = False
        # set window size
        _winSize = prefs.piloting['forcedWindowSize']

def showExpInfoDlg(expInfo):
    """
    Show participant info dialog.
    Parameters
    ==========
    expInfo : dict
        Information about this experiment.
    
    Returns
    ==========
    dict
        Information about this experiment.
    """
    # show participant info dialog
    dlg = gui.DlgFromDict(
        dictionary=expInfo, sortKeys=False, title=expName, alwaysOnTop=True
    )
    if dlg.OK == False:
        core.quit()  # user pressed cancel
    # return expInfo
    return expInfo


def setupData(expInfo, dataDir=None):
    """
    Make an ExperimentHandler to handle trials and saving.
    
    Parameters
    ==========
    expInfo : dict
        Information about this experiment, created by the `setupExpInfo` function.
    dataDir : Path, str or None
        Folder to save the data to, leave as None to create a folder in the current directory.    
    Returns
    ==========
    psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    """
    # remove dialog-specific syntax from expInfo
    for key, val in expInfo.copy().items():
        newKey, _ = data.utils.parsePipeSyntax(key)
        expInfo[newKey] = expInfo.pop(key)
    
    # data file name stem = absolute path + name; later add .psyexp, .csv, .log, etc
    if dataDir is None:
        dataDir = _thisDir
    filename = u'data/%s_%s_%s' % (expInfo['participant'], expName, expInfo['date'])
    # make sure filename is relative to dataDir
    if os.path.isabs(filename):
        dataDir = os.path.commonprefix([dataDir, filename])
        filename = os.path.relpath(filename, dataDir)
    
    # an ExperimentHandler isn't essential but helps with data saving
    thisExp = data.ExperimentHandler(
        name=expName, version='',
        extraInfo=expInfo, runtimeInfo=None,
        originPath='C:\\Users\\김태령\\Desktop\\LAB MATERIALS\\-ㄴ new self paced reading\\new SPRT exp file\\sprt_new_A_lastrun.py',
        savePickle=True, saveWideText=True,
        dataFileName=dataDir + os.sep + filename, sortColumns='time'
    )
    thisExp.setPriority('thisRow.t', priority.CRITICAL)
    thisExp.setPriority('expName', priority.LOW)
    # return experiment handler
    return thisExp


def setupLogging(filename):
    """
    Setup a log file and tell it what level to log at.
    
    Parameters
    ==========
    filename : str or pathlib.Path
        Filename to save log file and data files as, doesn't need an extension.
    
    Returns
    ==========
    psychopy.logging.LogFile
        Text stream to receive inputs from the logging system.
    """
    # set how much information should be printed to the console / app
    if PILOTING:
        logging.console.setLevel(
            prefs.piloting['pilotConsoleLoggingLevel']
        )
    else:
        logging.console.setLevel('warning')
    # save a log file for detail verbose info
    logFile = logging.LogFile(filename+'.log')
    if PILOTING:
        logFile.setLevel(
            prefs.piloting['pilotLoggingLevel']
        )
    else:
        logFile.setLevel(
            logging.getLevel('info')
        )
    
    return logFile


def setupWindow(expInfo=None, win=None):
    """
    Setup the Window
    
    Parameters
    ==========
    expInfo : dict
        Information about this experiment, created by the `setupExpInfo` function.
    win : psychopy.visual.Window
        Window to setup - leave as None to create a new window.
    
    Returns
    ==========
    psychopy.visual.Window
        Window in which to run this experiment.
    """
    if PILOTING:
        logging.debug('Fullscreen settings ignored as running in pilot mode.')
    
    if win is None:
        # if not given a window to setup, make one
        win = visual.Window(
            size=_winSize, fullscr=_fullScr, screen=0,
            winType='pyglet', allowGUI=False, allowStencil=False,
            monitor='testMonitor', color=[0,0,0], colorSpace='rgb',
            backgroundImage='', backgroundFit='none',
            blendMode='avg', useFBO=True,
            units='height',
            checkTiming=False  # we're going to do this ourselves in a moment
        )
    else:
        # if we have a window, just set the attributes which are safe to set
        win.color = [0,0,0]
        win.colorSpace = 'rgb'
        win.backgroundImage = ''
        win.backgroundFit = 'none'
        win.units = 'height'
    if expInfo is not None:
        # get/measure frame rate if not already in expInfo
        if win._monitorFrameRate is None:
            win._monitorFrameRate = win.getActualFrameRate(infoMsg='Attempting to measure frame rate of screen, please wait...')
        expInfo['frameRate'] = win._monitorFrameRate
    win.hideMessage()
    # show a visual indicator if we're in piloting mode
    if PILOTING and prefs.piloting['showPilotingIndicator']:
        win.showPilotingIndicator()
    
    return win


def setupDevices(expInfo, thisExp, win):
    """
    Setup whatever devices are available (mouse, keyboard, speaker, eyetracker, etc.) and add them to 
    the device manager (deviceManager)
    
    Parameters
    ==========
    expInfo : dict
        Information about this experiment, created by the `setupExpInfo` function.
    thisExp : psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    win : psychopy.visual.Window
        Window in which to run this experiment.
    Returns
    ==========
    bool
        True if completed successfully.
    """
    # --- Setup input devices ---
    ioConfig = {}
    
    # Setup iohub keyboard
    ioConfig['Keyboard'] = dict(use_keymap='psychopy')
    
    # Setup iohub experiment
    ioConfig['Experiment'] = dict(filename=thisExp.dataFileName)
    
    # Start ioHub server
    ioServer = io.launchHubServer(window=win, **ioConfig)
    
    # store ioServer object in the device manager
    deviceManager.ioServer = ioServer
    
    # create a default keyboard (e.g. to check for escape)
    if deviceManager.getDevice('defaultKeyboard') is None:
        deviceManager.addDevice(
            deviceClass='keyboard', deviceName='defaultKeyboard', backend='iohub'
        )
    if deviceManager.getDevice('key_resp') is None:
        # initialise key_resp
        key_resp = deviceManager.addDevice(
            deviceClass='keyboard',
            deviceName='key_resp',
        )
    if deviceManager.getDevice('skip_masking') is None:
        # initialise skip_masking
        skip_masking = deviceManager.addDevice(
            deviceClass='keyboard',
            deviceName='skip_masking',
        )
    if deviceManager.getDevice('prac_p1_resp') is None:
        # initialise prac_p1_resp
        prac_p1_resp = deviceManager.addDevice(
            deviceClass='keyboard',
            deviceName='prac_p1_resp',
        )
    if deviceManager.getDevice('prac_p2_resp') is None:
        # initialise prac_p2_resp
        prac_p2_resp = deviceManager.addDevice(
            deviceClass='keyboard',
            deviceName='prac_p2_resp',
        )
    if deviceManager.getDevice('prac_p3_resp') is None:
        # initialise prac_p3_resp
        prac_p3_resp = deviceManager.addDevice(
            deviceClass='keyboard',
            deviceName='prac_p3_resp',
        )
    if deviceManager.getDevice('prac_p4_resp') is None:
        # initialise prac_p4_resp
        prac_p4_resp = deviceManager.addDevice(
            deviceClass='keyboard',
            deviceName='prac_p4_resp',
        )
    if deviceManager.getDevice('comp1_resp') is None:
        # initialise comp1_resp
        comp1_resp = deviceManager.addDevice(
            deviceClass='keyboard',
            deviceName='comp1_resp',
        )
    if deviceManager.getDevice('key_resp_2') is None:
        # initialise key_resp_2
        key_resp_2 = deviceManager.addDevice(
            deviceClass='keyboard',
            deviceName='key_resp_2',
        )
    if deviceManager.getDevice('skip_mask2') is None:
        # initialise skip_mask2
        skip_mask2 = deviceManager.addDevice(
            deviceClass='keyboard',
            deviceName='skip_mask2',
        )
    if deviceManager.getDevice('main_p1_resp') is None:
        # initialise main_p1_resp
        main_p1_resp = deviceManager.addDevice(
            deviceClass='keyboard',
            deviceName='main_p1_resp',
        )
    if deviceManager.getDevice('main_p2_resp') is None:
        # initialise main_p2_resp
        main_p2_resp = deviceManager.addDevice(
            deviceClass='keyboard',
            deviceName='main_p2_resp',
        )
    if deviceManager.getDevice('main_p3_resp') is None:
        # initialise main_p3_resp
        main_p3_resp = deviceManager.addDevice(
            deviceClass='keyboard',
            deviceName='main_p3_resp',
        )
    if deviceManager.getDevice('main_p4_resp') is None:
        # initialise main_p4_resp
        main_p4_resp = deviceManager.addDevice(
            deviceClass='keyboard',
            deviceName='main_p4_resp',
        )
    if deviceManager.getDevice('main_comp_resp') is None:
        # initialise main_comp_resp
        main_comp_resp = deviceManager.addDevice(
            deviceClass='keyboard',
            deviceName='main_comp_resp',
        )
    # return True if completed successfully
    return True

def pauseExperiment(thisExp, win=None, timers=[], playbackComponents=[]):
    """
    Pause this experiment, preventing the flow from advancing to the next routine until resumed.
    
    Parameters
    ==========
    thisExp : psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    win : psychopy.visual.Window
        Window for this experiment.
    timers : list, tuple
        List of timers to reset once pausing is finished.
    playbackComponents : list, tuple
        List of any components with a `pause` method which need to be paused.
    """
    # if we are not paused, do nothing
    if thisExp.status != PAUSED:
        return
    
    # start a timer to figure out how long we're paused for
    pauseTimer = core.Clock()
    # pause any playback components
    for comp in playbackComponents:
        comp.pause()
    # make sure we have a keyboard
    defaultKeyboard = deviceManager.getDevice('defaultKeyboard')
    if defaultKeyboard is None:
        defaultKeyboard = deviceManager.addKeyboard(
            deviceClass='keyboard',
            deviceName='defaultKeyboard',
            backend='ioHub',
        )
    # run a while loop while we wait to unpause
    while thisExp.status == PAUSED:
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=['escape']):
            endExperiment(thisExp, win=win)
        # sleep 1ms so other threads can execute
        clock.time.sleep(0.001)
    # if stop was requested while paused, quit
    if thisExp.status == FINISHED:
        endExperiment(thisExp, win=win)
    # resume any playback components
    for comp in playbackComponents:
        comp.play()
    # reset any timers
    for timer in timers:
        timer.addTime(-pauseTimer.getTime())


def run(expInfo, thisExp, win, globalClock=None, thisSession=None):
    """
    Run the experiment flow.
    
    Parameters
    ==========
    expInfo : dict
        Information about this experiment, created by the `setupExpInfo` function.
    thisExp : psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    psychopy.visual.Window
        Window in which to run this experiment.
    globalClock : psychopy.core.clock.Clock or None
        Clock to get global time from - supply None to make a new one.
    thisSession : psychopy.session.Session or None
        Handle of the Session object this experiment is being run from, if any.
    """
    # mark experiment as started
    thisExp.status = STARTED
    # make sure window is set to foreground to prevent losing focus
    win.winHandle.activate()
    # make sure variables created by exec are available globally
    exec = environmenttools.setExecEnvironment(globals())
    # get device handles from dict of input devices
    ioServer = deviceManager.ioServer
    # get/create a default keyboard (e.g. to check for escape)
    defaultKeyboard = deviceManager.getDevice('defaultKeyboard')
    if defaultKeyboard is None:
        deviceManager.addDevice(
            deviceClass='keyboard', deviceName='defaultKeyboard', backend='ioHub'
        )
    eyetracker = deviceManager.getDevice('eyetracker')
    # make sure we're running in the directory for this experiment
    os.chdir(_thisDir)
    # get filename from ExperimentHandler for convenience
    filename = thisExp.dataFileName
    frameTolerance = 0.001  # how close to onset before 'same' frame
    endExpNow = False  # flag for 'escape' or other condition => quit the exp
    # get frame duration from frame rate in expInfo
    if 'frameRate' in expInfo and expInfo['frameRate'] is not None:
        frameDur = 1.0 / round(expInfo['frameRate'])
    else:
        frameDur = 1.0 / 60.0  # could not measure, so guess
    
    # Start Code - component code to be run after the window creation
    
    # --- Initialize components for Routine "intro" ---
    # Run 'Begin Experiment' code from code
    pp1 = "###"
    pp2 = "###"
    pp3 = "###"
    pp4 = "###"
    sen = pp1 + " " + pp2 + " " + pp3 + " " + pp4 + " "
    prac_intro = visual.TextStim(win=win, name='prac_intro',
        text="-실험 안내-\n\n실험에 참여해주셔서 감사합니다. \n실험은 다음과 같이 진행됩니다. \n\n1. 화면의 각 위치에 단어가 등장합니다. \n\n2. 스페이스 바를 눌러 다음 내용을 확인할 수 있습니다.\n\n3. 다음 단어를 확인할 경우 이전의 단어는 사라집니다. \n\n4. 스페이스 바를 눌러가며 전체 문장을 확인하신 후, \n질문에 답하실 수 있습니다. \n\n5. 질문의 내용이 참이라면 오른손으로 'j', \n질문의 내용이 거짓이라면 왼손으로 'f'를 눌러주시기 바랍니다. \n\n스페이스 바를 눌러 연습 시행을 시작할 수 있습니다. ",
        font='Arial',
        pos=(0, 0), draggable=False, height=0.03, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-1.0);
    key_resp = keyboard.Keyboard(deviceName='key_resp')
    
    # --- Initialize components for Routine "prac_fix" ---
    fixation1 = visual.TextStim(win=win, name='fixation1',
        text='+',
        font='Arial',
        pos=(0, 0), draggable=False, height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=0.0);
    
    # --- Initialize components for Routine "mask" ---
    masking = visual.TextStim(win=win, name='masking',
        text='',
        font='Arial',
        pos=(0, 0), draggable=False, height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=0.0);
    skip_masking = keyboard.Keyboard(deviceName='skip_masking')
    
    # --- Initialize components for Routine "prac_P1" ---
    prac_p1_stim = visual.TextStim(win=win, name='prac_p1_stim',
        text='',
        font='Arial',
        pos=(0, 0), draggable=False, height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-1.0);
    prac_p1_resp = keyboard.Keyboard(deviceName='prac_p1_resp')
    
    # --- Initialize components for Routine "prac_P2" ---
    prac_p2_stim = visual.TextStim(win=win, name='prac_p2_stim',
        text='',
        font='Arial',
        pos=(0, 0), draggable=False, height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-1.0);
    prac_p2_resp = keyboard.Keyboard(deviceName='prac_p2_resp')
    
    # --- Initialize components for Routine "prac_P3" ---
    prac_p3_stim = visual.TextStim(win=win, name='prac_p3_stim',
        text='',
        font='Arial',
        pos=(0, 0), draggable=False, height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-1.0);
    prac_p3_resp = keyboard.Keyboard(deviceName='prac_p3_resp')
    
    # --- Initialize components for Routine "prac_P4" ---
    prac_p4_stim = visual.TextStim(win=win, name='prac_p4_stim',
        text='',
        font='Arial',
        pos=(0, 0), draggable=False, height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-1.0);
    prac_p4_resp = keyboard.Keyboard(deviceName='prac_p4_resp')
    
    # --- Initialize components for Routine "prac_comp" ---
    comprehension1 = visual.TextStim(win=win, name='comprehension1',
        text='',
        font='Arial',
        pos=(0, 0), draggable=False, height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=0.0);
    comp1_resp = keyboard.Keyboard(deviceName='comp1_resp')
    
    # --- Initialize components for Routine "feedback" ---
    fb = visual.TextStim(win=win, name='fb',
        text='',
        font='Arial',
        pos=(0, 0), draggable=False, height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-1.0);
    
    # --- Initialize components for Routine "main_intro" ---
    main = visual.TextStim(win=win, name='main',
        text="지금부터 본 시행이 시작됩니다. \n연습시행과 마찬가지로 스페이스 바를 눌러가며\n각 단어를 확인하실 수 있습니다. \n이후 질문의 내용이 참일 경우 오른손으로 'j'를, \n질문의 내용이 거짓일 경우 왼손으로 'f'를 눌러주시면 됩니다. \n본 시행에서는 정/오답 여부가 제공되지 않으니\n주의하시기 바랍니다. \n스페이스 바를 누르면 실험이 시작됩니다. ",
        font='Arial',
        pos=(0, 0), draggable=False, height=0.03, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=0.0);
    # Run 'Begin Experiment' code from code_7
    pp1 = "###"
    pp2 = "###"
    pp3 = "###"
    pp4 = "###"
    sen = pp1 + " " + pp2 + " " + pp3 + " " + pp4 + " "
    key_resp_2 = keyboard.Keyboard(deviceName='key_resp_2')
    
    # --- Initialize components for Routine "main_fix" ---
    fixation2 = visual.TextStim(win=win, name='fixation2',
        text='+',
        font='Arial',
        pos=(0, 0), draggable=False, height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=0.0);
    
    # --- Initialize components for Routine "main_mask" ---
    masking2 = visual.TextStim(win=win, name='masking2',
        text='',
        font='Arial',
        pos=(0, 0), draggable=False, height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=0.0);
    skip_mask2 = keyboard.Keyboard(deviceName='skip_mask2')
    
    # --- Initialize components for Routine "main_P1" ---
    main_p1_stim = visual.TextStim(win=win, name='main_p1_stim',
        text='',
        font='Arial',
        pos=(0, 0), draggable=False, height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-1.0);
    main_p1_resp = keyboard.Keyboard(deviceName='main_p1_resp')
    
    # --- Initialize components for Routine "main_P2" ---
    main_p2_stim = visual.TextStim(win=win, name='main_p2_stim',
        text='',
        font='Arial',
        pos=(0, 0), draggable=False, height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-1.0);
    main_p2_resp = keyboard.Keyboard(deviceName='main_p2_resp')
    
    # --- Initialize components for Routine "main_P3" ---
    main_p3_stim = visual.TextStim(win=win, name='main_p3_stim',
        text='',
        font='Arial',
        pos=(0, 0), draggable=False, height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-1.0);
    main_p3_resp = keyboard.Keyboard(deviceName='main_p3_resp')
    
    # --- Initialize components for Routine "main_P4" ---
    main_p4_stim = visual.TextStim(win=win, name='main_p4_stim',
        text='',
        font='Arial',
        pos=(0, 0), draggable=False, height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-1.0);
    main_p4_resp = keyboard.Keyboard(deviceName='main_p4_resp')
    
    # --- Initialize components for Routine "main_comp" ---
    comprehension2 = visual.TextStim(win=win, name='comprehension2',
        text='',
        font='Arial',
        pos=(0, 0), draggable=False, height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=0.0);
    main_comp_resp = keyboard.Keyboard(deviceName='main_comp_resp')
    
    # --- Initialize components for Routine "ending" ---
    end = visual.TextStim(win=win, name='end',
        text='모든 실험이 종료되었습니다. \n고생하셨습니다.',
        font='Arial',
        pos=(0, 0), draggable=False, height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=0.0);
    
    # create some handy timers
    
    # global clock to track the time since experiment started
    if globalClock is None:
        # create a clock if not given one
        globalClock = core.Clock()
    if isinstance(globalClock, str):
        # if given a string, make a clock accoridng to it
        if globalClock == 'float':
            # get timestamps as a simple value
            globalClock = core.Clock(format='float')
        elif globalClock == 'iso':
            # get timestamps in ISO format
            globalClock = core.Clock(format='%Y-%m-%d_%H:%M:%S.%f%z')
        else:
            # get timestamps in a custom format
            globalClock = core.Clock(format=globalClock)
    if ioServer is not None:
        ioServer.syncClock(globalClock)
    logging.setDefaultClock(globalClock)
    # routine timer to track time remaining of each (possibly non-slip) routine
    routineTimer = core.Clock()
    win.flip()  # flip window to reset last flip timer
    # store the exact time the global clock started
    expInfo['expStart'] = data.getDateStr(
        format='%Y-%m-%d %Hh%M.%S.%f %z', fractionalSecondDigits=6
    )
    
    # --- Prepare to start Routine "intro" ---
    # create an object to store info about Routine intro
    intro = data.Routine(
        name='intro',
        components=[prac_intro, key_resp],
    )
    intro.status = NOT_STARTED
    continueRoutine = True
    # update component parameters for each repeat
    # create starting attributes for key_resp
    key_resp.keys = []
    key_resp.rt = []
    _key_resp_allKeys = []
    # store start times for intro
    intro.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
    intro.tStart = globalClock.getTime(format='float')
    intro.status = STARTED
    thisExp.addData('intro.started', intro.tStart)
    intro.maxDuration = None
    # keep track of which components have finished
    introComponents = intro.components
    for thisComponent in intro.components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "intro" ---
    intro.forceEnded = routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *prac_intro* updates
        
        # if prac_intro is starting this frame...
        if prac_intro.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            prac_intro.frameNStart = frameN  # exact frame index
            prac_intro.tStart = t  # local t and not account for scr refresh
            prac_intro.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(prac_intro, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'prac_intro.started')
            # update status
            prac_intro.status = STARTED
            prac_intro.setAutoDraw(True)
        
        # if prac_intro is active this frame...
        if prac_intro.status == STARTED:
            # update params
            pass
        
        # *key_resp* updates
        waitOnFlip = False
        
        # if key_resp is starting this frame...
        if key_resp.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            key_resp.frameNStart = frameN  # exact frame index
            key_resp.tStart = t  # local t and not account for scr refresh
            key_resp.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(key_resp, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'key_resp.started')
            # update status
            key_resp.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(key_resp.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(key_resp.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if key_resp.status == STARTED and not waitOnFlip:
            theseKeys = key_resp.getKeys(keyList=['space'], ignoreKeys=["escape"], waitRelease=False)
            _key_resp_allKeys.extend(theseKeys)
            if len(_key_resp_allKeys):
                key_resp.keys = _key_resp_allKeys[-1].name  # just the last key pressed
                key_resp.rt = _key_resp_allKeys[-1].rt
                key_resp.duration = _key_resp_allKeys[-1].duration
                # a response ends the routine
                continueRoutine = False
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, win=win)
            return
        # pause experiment here if requested
        if thisExp.status == PAUSED:
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[routineTimer], 
                playbackComponents=[]
            )
            # skip the frame we paused on
            continue
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            intro.forceEnded = routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in intro.components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "intro" ---
    for thisComponent in intro.components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # store stop times for intro
    intro.tStop = globalClock.getTime(format='float')
    intro.tStopRefresh = tThisFlipGlobal
    thisExp.addData('intro.stopped', intro.tStop)
    # check responses
    if key_resp.keys in ['', [], None]:  # No response was made
        key_resp.keys = None
    thisExp.addData('key_resp.keys',key_resp.keys)
    if key_resp.keys != None:  # we had a response
        thisExp.addData('key_resp.rt', key_resp.rt)
        thisExp.addData('key_resp.duration', key_resp.duration)
    thisExp.nextEntry()
    # the Routine "intro" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # set up handler to look after randomisation of conditions etc
    practice = data.TrialHandler2(
        name='practice',
        nReps=1.0, 
        method='random', 
        extraInfo=expInfo, 
        originPath=-1, 
        trialList=data.importConditions('new_practice trial.xlsx'), 
        seed=None, 
    )
    thisExp.addLoop(practice)  # add the loop to the experiment
    thisPractice = practice.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisPractice.rgb)
    if thisPractice != None:
        for paramName in thisPractice:
            globals()[paramName] = thisPractice[paramName]
    if thisSession is not None:
        # if running in a Session with a Liaison client, send data up to now
        thisSession.sendExperimentData()
    
    for thisPractice in practice:
        currentLoop = practice
        thisExp.timestampOnFlip(win, 'thisRow.t', format=globalClock.format)
        if thisSession is not None:
            # if running in a Session with a Liaison client, send data up to now
            thisSession.sendExperimentData()
        # abbreviate parameter names if possible (e.g. rgb = thisPractice.rgb)
        if thisPractice != None:
            for paramName in thisPractice:
                globals()[paramName] = thisPractice[paramName]
        
        # --- Prepare to start Routine "prac_fix" ---
        # create an object to store info about Routine prac_fix
        prac_fix = data.Routine(
            name='prac_fix',
            components=[fixation1],
        )
        prac_fix.status = NOT_STARTED
        continueRoutine = True
        # update component parameters for each repeat
        # store start times for prac_fix
        prac_fix.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
        prac_fix.tStart = globalClock.getTime(format='float')
        prac_fix.status = STARTED
        thisExp.addData('prac_fix.started', prac_fix.tStart)
        prac_fix.maxDuration = None
        # keep track of which components have finished
        prac_fixComponents = prac_fix.components
        for thisComponent in prac_fix.components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "prac_fix" ---
        # if trial has changed, end Routine now
        if isinstance(practice, data.TrialHandler2) and thisPractice.thisN != practice.thisTrial.thisN:
            continueRoutine = False
        prac_fix.forceEnded = routineForceEnded = not continueRoutine
        while continueRoutine and routineTimer.getTime() < 1.0:
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *fixation1* updates
            
            # if fixation1 is starting this frame...
            if fixation1.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                fixation1.frameNStart = frameN  # exact frame index
                fixation1.tStart = t  # local t and not account for scr refresh
                fixation1.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(fixation1, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'fixation1.started')
                # update status
                fixation1.status = STARTED
                fixation1.setAutoDraw(True)
            
            # if fixation1 is active this frame...
            if fixation1.status == STARTED:
                # update params
                pass
            
            # if fixation1 is stopping this frame...
            if fixation1.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > fixation1.tStartRefresh + 1.0-frameTolerance:
                    # keep track of stop time/frame for later
                    fixation1.tStop = t  # not accounting for scr refresh
                    fixation1.tStopRefresh = tThisFlipGlobal  # on global time
                    fixation1.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'fixation1.stopped')
                    # update status
                    fixation1.status = FINISHED
                    fixation1.setAutoDraw(False)
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, win=win)
                return
            # pause experiment here if requested
            if thisExp.status == PAUSED:
                pauseExperiment(
                    thisExp=thisExp, 
                    win=win, 
                    timers=[routineTimer], 
                    playbackComponents=[]
                )
                # skip the frame we paused on
                continue
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                prac_fix.forceEnded = routineForceEnded = True
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in prac_fix.components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "prac_fix" ---
        for thisComponent in prac_fix.components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # store stop times for prac_fix
        prac_fix.tStop = globalClock.getTime(format='float')
        prac_fix.tStopRefresh = tThisFlipGlobal
        thisExp.addData('prac_fix.stopped', prac_fix.tStop)
        # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
        if prac_fix.maxDurationReached:
            routineTimer.addTime(-prac_fix.maxDuration)
        elif prac_fix.forceEnded:
            routineTimer.reset()
        else:
            routineTimer.addTime(-1.000000)
        
        # --- Prepare to start Routine "mask" ---
        # create an object to store info about Routine mask
        mask = data.Routine(
            name='mask',
            components=[masking, skip_masking],
        )
        mask.status = NOT_STARTED
        continueRoutine = True
        # update component parameters for each repeat
        masking.setText('#### ### ### ####')
        # create starting attributes for skip_masking
        skip_masking.keys = []
        skip_masking.rt = []
        _skip_masking_allKeys = []
        # store start times for mask
        mask.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
        mask.tStart = globalClock.getTime(format='float')
        mask.status = STARTED
        thisExp.addData('mask.started', mask.tStart)
        mask.maxDuration = None
        # keep track of which components have finished
        maskComponents = mask.components
        for thisComponent in mask.components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "mask" ---
        # if trial has changed, end Routine now
        if isinstance(practice, data.TrialHandler2) and thisPractice.thisN != practice.thisTrial.thisN:
            continueRoutine = False
        mask.forceEnded = routineForceEnded = not continueRoutine
        while continueRoutine:
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *masking* updates
            
            # if masking is starting this frame...
            if masking.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                masking.frameNStart = frameN  # exact frame index
                masking.tStart = t  # local t and not account for scr refresh
                masking.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(masking, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'masking.started')
                # update status
                masking.status = STARTED
                masking.setAutoDraw(True)
            
            # if masking is active this frame...
            if masking.status == STARTED:
                # update params
                pass
            
            # *skip_masking* updates
            waitOnFlip = False
            
            # if skip_masking is starting this frame...
            if skip_masking.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                skip_masking.frameNStart = frameN  # exact frame index
                skip_masking.tStart = t  # local t and not account for scr refresh
                skip_masking.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(skip_masking, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'skip_masking.started')
                # update status
                skip_masking.status = STARTED
                # keyboard checking is just starting
                waitOnFlip = True
                win.callOnFlip(skip_masking.clock.reset)  # t=0 on next screen flip
                win.callOnFlip(skip_masking.clearEvents, eventType='keyboard')  # clear events on next screen flip
            if skip_masking.status == STARTED and not waitOnFlip:
                theseKeys = skip_masking.getKeys(keyList=['space'], ignoreKeys=["escape"], waitRelease=False)
                _skip_masking_allKeys.extend(theseKeys)
                if len(_skip_masking_allKeys):
                    skip_masking.keys = _skip_masking_allKeys[-1].name  # just the last key pressed
                    skip_masking.rt = _skip_masking_allKeys[-1].rt
                    skip_masking.duration = _skip_masking_allKeys[-1].duration
                    # a response ends the routine
                    continueRoutine = False
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, win=win)
                return
            # pause experiment here if requested
            if thisExp.status == PAUSED:
                pauseExperiment(
                    thisExp=thisExp, 
                    win=win, 
                    timers=[routineTimer], 
                    playbackComponents=[]
                )
                # skip the frame we paused on
                continue
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                mask.forceEnded = routineForceEnded = True
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in mask.components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "mask" ---
        for thisComponent in mask.components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # store stop times for mask
        mask.tStop = globalClock.getTime(format='float')
        mask.tStopRefresh = tThisFlipGlobal
        thisExp.addData('mask.stopped', mask.tStop)
        # check responses
        if skip_masking.keys in ['', [], None]:  # No response was made
            skip_masking.keys = None
        practice.addData('skip_masking.keys',skip_masking.keys)
        if skip_masking.keys != None:  # we had a response
            practice.addData('skip_masking.rt', skip_masking.rt)
            practice.addData('skip_masking.duration', skip_masking.duration)
        # the Routine "mask" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        
        # --- Prepare to start Routine "prac_P1" ---
        # create an object to store info about Routine prac_P1
        prac_P1 = data.Routine(
            name='prac_P1',
            components=[prac_p1_stim, prac_p1_resp],
        )
        prac_P1.status = NOT_STARTED
        continueRoutine = True
        # update component parameters for each repeat
        # Run 'Begin Routine' code from code_2
        pp1 = p1
        pp2 = "###"
        pp3 = "###"
        pp4 = "####"
        sen = pp1 + " " + pp2 + " " + pp3 + " " + pp4+ " "
        prac_p1_stim.setText(sen)
        # create starting attributes for prac_p1_resp
        prac_p1_resp.keys = []
        prac_p1_resp.rt = []
        _prac_p1_resp_allKeys = []
        # store start times for prac_P1
        prac_P1.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
        prac_P1.tStart = globalClock.getTime(format='float')
        prac_P1.status = STARTED
        thisExp.addData('prac_P1.started', prac_P1.tStart)
        prac_P1.maxDuration = None
        # keep track of which components have finished
        prac_P1Components = prac_P1.components
        for thisComponent in prac_P1.components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "prac_P1" ---
        # if trial has changed, end Routine now
        if isinstance(practice, data.TrialHandler2) and thisPractice.thisN != practice.thisTrial.thisN:
            continueRoutine = False
        prac_P1.forceEnded = routineForceEnded = not continueRoutine
        while continueRoutine:
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *prac_p1_stim* updates
            
            # if prac_p1_stim is starting this frame...
            if prac_p1_stim.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                prac_p1_stim.frameNStart = frameN  # exact frame index
                prac_p1_stim.tStart = t  # local t and not account for scr refresh
                prac_p1_stim.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(prac_p1_stim, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'prac_p1_stim.started')
                # update status
                prac_p1_stim.status = STARTED
                prac_p1_stim.setAutoDraw(True)
            
            # if prac_p1_stim is active this frame...
            if prac_p1_stim.status == STARTED:
                # update params
                pass
            
            # *prac_p1_resp* updates
            waitOnFlip = False
            
            # if prac_p1_resp is starting this frame...
            if prac_p1_resp.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                prac_p1_resp.frameNStart = frameN  # exact frame index
                prac_p1_resp.tStart = t  # local t and not account for scr refresh
                prac_p1_resp.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(prac_p1_resp, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'prac_p1_resp.started')
                # update status
                prac_p1_resp.status = STARTED
                # keyboard checking is just starting
                waitOnFlip = True
                win.callOnFlip(prac_p1_resp.clock.reset)  # t=0 on next screen flip
                win.callOnFlip(prac_p1_resp.clearEvents, eventType='keyboard')  # clear events on next screen flip
            if prac_p1_resp.status == STARTED and not waitOnFlip:
                theseKeys = prac_p1_resp.getKeys(keyList=['space'], ignoreKeys=["escape"], waitRelease=False)
                _prac_p1_resp_allKeys.extend(theseKeys)
                if len(_prac_p1_resp_allKeys):
                    prac_p1_resp.keys = _prac_p1_resp_allKeys[-1].name  # just the last key pressed
                    prac_p1_resp.rt = _prac_p1_resp_allKeys[-1].rt
                    prac_p1_resp.duration = _prac_p1_resp_allKeys[-1].duration
                    # a response ends the routine
                    continueRoutine = False
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, win=win)
                return
            # pause experiment here if requested
            if thisExp.status == PAUSED:
                pauseExperiment(
                    thisExp=thisExp, 
                    win=win, 
                    timers=[routineTimer], 
                    playbackComponents=[]
                )
                # skip the frame we paused on
                continue
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                prac_P1.forceEnded = routineForceEnded = True
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in prac_P1.components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "prac_P1" ---
        for thisComponent in prac_P1.components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # store stop times for prac_P1
        prac_P1.tStop = globalClock.getTime(format='float')
        prac_P1.tStopRefresh = tThisFlipGlobal
        thisExp.addData('prac_P1.stopped', prac_P1.tStop)
        # check responses
        if prac_p1_resp.keys in ['', [], None]:  # No response was made
            prac_p1_resp.keys = None
        practice.addData('prac_p1_resp.keys',prac_p1_resp.keys)
        if prac_p1_resp.keys != None:  # we had a response
            practice.addData('prac_p1_resp.rt', prac_p1_resp.rt)
            practice.addData('prac_p1_resp.duration', prac_p1_resp.duration)
        # the Routine "prac_P1" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        
        # --- Prepare to start Routine "prac_P2" ---
        # create an object to store info about Routine prac_P2
        prac_P2 = data.Routine(
            name='prac_P2',
            components=[prac_p2_stim, prac_p2_resp],
        )
        prac_P2.status = NOT_STARTED
        continueRoutine = True
        # update component parameters for each repeat
        # Run 'Begin Routine' code from code_3
        pp1 = "####"
        pp2 = p2
        pp3 = "###"
        pp4 = "####"
        sen = pp1 + " " + pp2 + " " + pp3 + " " + pp4+ " "
        prac_p2_stim.setText(sen)
        # create starting attributes for prac_p2_resp
        prac_p2_resp.keys = []
        prac_p2_resp.rt = []
        _prac_p2_resp_allKeys = []
        # store start times for prac_P2
        prac_P2.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
        prac_P2.tStart = globalClock.getTime(format='float')
        prac_P2.status = STARTED
        thisExp.addData('prac_P2.started', prac_P2.tStart)
        prac_P2.maxDuration = None
        # keep track of which components have finished
        prac_P2Components = prac_P2.components
        for thisComponent in prac_P2.components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "prac_P2" ---
        # if trial has changed, end Routine now
        if isinstance(practice, data.TrialHandler2) and thisPractice.thisN != practice.thisTrial.thisN:
            continueRoutine = False
        prac_P2.forceEnded = routineForceEnded = not continueRoutine
        while continueRoutine:
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *prac_p2_stim* updates
            
            # if prac_p2_stim is starting this frame...
            if prac_p2_stim.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                prac_p2_stim.frameNStart = frameN  # exact frame index
                prac_p2_stim.tStart = t  # local t and not account for scr refresh
                prac_p2_stim.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(prac_p2_stim, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'prac_p2_stim.started')
                # update status
                prac_p2_stim.status = STARTED
                prac_p2_stim.setAutoDraw(True)
            
            # if prac_p2_stim is active this frame...
            if prac_p2_stim.status == STARTED:
                # update params
                pass
            
            # *prac_p2_resp* updates
            waitOnFlip = False
            
            # if prac_p2_resp is starting this frame...
            if prac_p2_resp.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                prac_p2_resp.frameNStart = frameN  # exact frame index
                prac_p2_resp.tStart = t  # local t and not account for scr refresh
                prac_p2_resp.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(prac_p2_resp, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'prac_p2_resp.started')
                # update status
                prac_p2_resp.status = STARTED
                # keyboard checking is just starting
                waitOnFlip = True
                win.callOnFlip(prac_p2_resp.clock.reset)  # t=0 on next screen flip
                win.callOnFlip(prac_p2_resp.clearEvents, eventType='keyboard')  # clear events on next screen flip
            if prac_p2_resp.status == STARTED and not waitOnFlip:
                theseKeys = prac_p2_resp.getKeys(keyList=['space'], ignoreKeys=["escape"], waitRelease=False)
                _prac_p2_resp_allKeys.extend(theseKeys)
                if len(_prac_p2_resp_allKeys):
                    prac_p2_resp.keys = _prac_p2_resp_allKeys[0].name  # just the first key pressed
                    prac_p2_resp.rt = _prac_p2_resp_allKeys[0].rt
                    prac_p2_resp.duration = _prac_p2_resp_allKeys[0].duration
                    # a response ends the routine
                    continueRoutine = False
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, win=win)
                return
            # pause experiment here if requested
            if thisExp.status == PAUSED:
                pauseExperiment(
                    thisExp=thisExp, 
                    win=win, 
                    timers=[routineTimer], 
                    playbackComponents=[]
                )
                # skip the frame we paused on
                continue
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                prac_P2.forceEnded = routineForceEnded = True
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in prac_P2.components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "prac_P2" ---
        for thisComponent in prac_P2.components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # store stop times for prac_P2
        prac_P2.tStop = globalClock.getTime(format='float')
        prac_P2.tStopRefresh = tThisFlipGlobal
        thisExp.addData('prac_P2.stopped', prac_P2.tStop)
        # check responses
        if prac_p2_resp.keys in ['', [], None]:  # No response was made
            prac_p2_resp.keys = None
        practice.addData('prac_p2_resp.keys',prac_p2_resp.keys)
        if prac_p2_resp.keys != None:  # we had a response
            practice.addData('prac_p2_resp.rt', prac_p2_resp.rt)
            practice.addData('prac_p2_resp.duration', prac_p2_resp.duration)
        # the Routine "prac_P2" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        
        # --- Prepare to start Routine "prac_P3" ---
        # create an object to store info about Routine prac_P3
        prac_P3 = data.Routine(
            name='prac_P3',
            components=[prac_p3_stim, prac_p3_resp],
        )
        prac_P3.status = NOT_STARTED
        continueRoutine = True
        # update component parameters for each repeat
        # Run 'Begin Routine' code from code_4
        pp1 = "####"
        pp2 = "###"
        pp3 = p3
        pp4 = "####"
        sen = pp1 + " " + pp2 + " " + pp3 + " " + pp4+ " "
        prac_p3_stim.setText(sen)
        # create starting attributes for prac_p3_resp
        prac_p3_resp.keys = []
        prac_p3_resp.rt = []
        _prac_p3_resp_allKeys = []
        # store start times for prac_P3
        prac_P3.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
        prac_P3.tStart = globalClock.getTime(format='float')
        prac_P3.status = STARTED
        thisExp.addData('prac_P3.started', prac_P3.tStart)
        prac_P3.maxDuration = None
        # keep track of which components have finished
        prac_P3Components = prac_P3.components
        for thisComponent in prac_P3.components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "prac_P3" ---
        # if trial has changed, end Routine now
        if isinstance(practice, data.TrialHandler2) and thisPractice.thisN != practice.thisTrial.thisN:
            continueRoutine = False
        prac_P3.forceEnded = routineForceEnded = not continueRoutine
        while continueRoutine:
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *prac_p3_stim* updates
            
            # if prac_p3_stim is starting this frame...
            if prac_p3_stim.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                prac_p3_stim.frameNStart = frameN  # exact frame index
                prac_p3_stim.tStart = t  # local t and not account for scr refresh
                prac_p3_stim.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(prac_p3_stim, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'prac_p3_stim.started')
                # update status
                prac_p3_stim.status = STARTED
                prac_p3_stim.setAutoDraw(True)
            
            # if prac_p3_stim is active this frame...
            if prac_p3_stim.status == STARTED:
                # update params
                pass
            
            # *prac_p3_resp* updates
            waitOnFlip = False
            
            # if prac_p3_resp is starting this frame...
            if prac_p3_resp.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                prac_p3_resp.frameNStart = frameN  # exact frame index
                prac_p3_resp.tStart = t  # local t and not account for scr refresh
                prac_p3_resp.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(prac_p3_resp, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'prac_p3_resp.started')
                # update status
                prac_p3_resp.status = STARTED
                # keyboard checking is just starting
                waitOnFlip = True
                win.callOnFlip(prac_p3_resp.clock.reset)  # t=0 on next screen flip
                win.callOnFlip(prac_p3_resp.clearEvents, eventType='keyboard')  # clear events on next screen flip
            if prac_p3_resp.status == STARTED and not waitOnFlip:
                theseKeys = prac_p3_resp.getKeys(keyList=['space'], ignoreKeys=["escape"], waitRelease=False)
                _prac_p3_resp_allKeys.extend(theseKeys)
                if len(_prac_p3_resp_allKeys):
                    prac_p3_resp.keys = _prac_p3_resp_allKeys[-1].name  # just the last key pressed
                    prac_p3_resp.rt = _prac_p3_resp_allKeys[-1].rt
                    prac_p3_resp.duration = _prac_p3_resp_allKeys[-1].duration
                    # a response ends the routine
                    continueRoutine = False
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, win=win)
                return
            # pause experiment here if requested
            if thisExp.status == PAUSED:
                pauseExperiment(
                    thisExp=thisExp, 
                    win=win, 
                    timers=[routineTimer], 
                    playbackComponents=[]
                )
                # skip the frame we paused on
                continue
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                prac_P3.forceEnded = routineForceEnded = True
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in prac_P3.components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "prac_P3" ---
        for thisComponent in prac_P3.components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # store stop times for prac_P3
        prac_P3.tStop = globalClock.getTime(format='float')
        prac_P3.tStopRefresh = tThisFlipGlobal
        thisExp.addData('prac_P3.stopped', prac_P3.tStop)
        # check responses
        if prac_p3_resp.keys in ['', [], None]:  # No response was made
            prac_p3_resp.keys = None
        practice.addData('prac_p3_resp.keys',prac_p3_resp.keys)
        if prac_p3_resp.keys != None:  # we had a response
            practice.addData('prac_p3_resp.rt', prac_p3_resp.rt)
            practice.addData('prac_p3_resp.duration', prac_p3_resp.duration)
        # the Routine "prac_P3" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        
        # --- Prepare to start Routine "prac_P4" ---
        # create an object to store info about Routine prac_P4
        prac_P4 = data.Routine(
            name='prac_P4',
            components=[prac_p4_stim, prac_p4_resp],
        )
        prac_P4.status = NOT_STARTED
        continueRoutine = True
        # update component parameters for each repeat
        # Run 'Begin Routine' code from code_5
        pp1 = "####"
        pp2 = "###"
        pp3 = "####"
        pp4 = p4
        sen = pp1 + " " + pp2 + " " + pp3 + " " + pp4+ " "
        prac_p4_stim.setText(sen)
        # create starting attributes for prac_p4_resp
        prac_p4_resp.keys = []
        prac_p4_resp.rt = []
        _prac_p4_resp_allKeys = []
        # store start times for prac_P4
        prac_P4.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
        prac_P4.tStart = globalClock.getTime(format='float')
        prac_P4.status = STARTED
        thisExp.addData('prac_P4.started', prac_P4.tStart)
        prac_P4.maxDuration = None
        # keep track of which components have finished
        prac_P4Components = prac_P4.components
        for thisComponent in prac_P4.components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "prac_P4" ---
        # if trial has changed, end Routine now
        if isinstance(practice, data.TrialHandler2) and thisPractice.thisN != practice.thisTrial.thisN:
            continueRoutine = False
        prac_P4.forceEnded = routineForceEnded = not continueRoutine
        while continueRoutine:
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *prac_p4_stim* updates
            
            # if prac_p4_stim is starting this frame...
            if prac_p4_stim.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                prac_p4_stim.frameNStart = frameN  # exact frame index
                prac_p4_stim.tStart = t  # local t and not account for scr refresh
                prac_p4_stim.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(prac_p4_stim, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'prac_p4_stim.started')
                # update status
                prac_p4_stim.status = STARTED
                prac_p4_stim.setAutoDraw(True)
            
            # if prac_p4_stim is active this frame...
            if prac_p4_stim.status == STARTED:
                # update params
                pass
            
            # *prac_p4_resp* updates
            waitOnFlip = False
            
            # if prac_p4_resp is starting this frame...
            if prac_p4_resp.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                prac_p4_resp.frameNStart = frameN  # exact frame index
                prac_p4_resp.tStart = t  # local t and not account for scr refresh
                prac_p4_resp.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(prac_p4_resp, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'prac_p4_resp.started')
                # update status
                prac_p4_resp.status = STARTED
                # keyboard checking is just starting
                waitOnFlip = True
                win.callOnFlip(prac_p4_resp.clock.reset)  # t=0 on next screen flip
                win.callOnFlip(prac_p4_resp.clearEvents, eventType='keyboard')  # clear events on next screen flip
            if prac_p4_resp.status == STARTED and not waitOnFlip:
                theseKeys = prac_p4_resp.getKeys(keyList=['space'], ignoreKeys=["escape"], waitRelease=False)
                _prac_p4_resp_allKeys.extend(theseKeys)
                if len(_prac_p4_resp_allKeys):
                    prac_p4_resp.keys = _prac_p4_resp_allKeys[-1].name  # just the last key pressed
                    prac_p4_resp.rt = _prac_p4_resp_allKeys[-1].rt
                    prac_p4_resp.duration = _prac_p4_resp_allKeys[-1].duration
                    # a response ends the routine
                    continueRoutine = False
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, win=win)
                return
            # pause experiment here if requested
            if thisExp.status == PAUSED:
                pauseExperiment(
                    thisExp=thisExp, 
                    win=win, 
                    timers=[routineTimer], 
                    playbackComponents=[]
                )
                # skip the frame we paused on
                continue
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                prac_P4.forceEnded = routineForceEnded = True
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in prac_P4.components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "prac_P4" ---
        for thisComponent in prac_P4.components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # store stop times for prac_P4
        prac_P4.tStop = globalClock.getTime(format='float')
        prac_P4.tStopRefresh = tThisFlipGlobal
        thisExp.addData('prac_P4.stopped', prac_P4.tStop)
        # check responses
        if prac_p4_resp.keys in ['', [], None]:  # No response was made
            prac_p4_resp.keys = None
        practice.addData('prac_p4_resp.keys',prac_p4_resp.keys)
        if prac_p4_resp.keys != None:  # we had a response
            practice.addData('prac_p4_resp.rt', prac_p4_resp.rt)
            practice.addData('prac_p4_resp.duration', prac_p4_resp.duration)
        # the Routine "prac_P4" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        
        # --- Prepare to start Routine "prac_comp" ---
        # create an object to store info about Routine prac_comp
        prac_comp = data.Routine(
            name='prac_comp',
            components=[comprehension1, comp1_resp],
        )
        prac_comp.status = NOT_STARTED
        continueRoutine = True
        # update component parameters for each repeat
        comprehension1.setText(comprehension)
        # create starting attributes for comp1_resp
        comp1_resp.keys = []
        comp1_resp.rt = []
        _comp1_resp_allKeys = []
        # store start times for prac_comp
        prac_comp.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
        prac_comp.tStart = globalClock.getTime(format='float')
        prac_comp.status = STARTED
        thisExp.addData('prac_comp.started', prac_comp.tStart)
        prac_comp.maxDuration = None
        # keep track of which components have finished
        prac_compComponents = prac_comp.components
        for thisComponent in prac_comp.components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "prac_comp" ---
        # if trial has changed, end Routine now
        if isinstance(practice, data.TrialHandler2) and thisPractice.thisN != practice.thisTrial.thisN:
            continueRoutine = False
        prac_comp.forceEnded = routineForceEnded = not continueRoutine
        while continueRoutine:
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *comprehension1* updates
            
            # if comprehension1 is starting this frame...
            if comprehension1.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                comprehension1.frameNStart = frameN  # exact frame index
                comprehension1.tStart = t  # local t and not account for scr refresh
                comprehension1.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(comprehension1, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'comprehension1.started')
                # update status
                comprehension1.status = STARTED
                comprehension1.setAutoDraw(True)
            
            # if comprehension1 is active this frame...
            if comprehension1.status == STARTED:
                # update params
                pass
            
            # *comp1_resp* updates
            waitOnFlip = False
            
            # if comp1_resp is starting this frame...
            if comp1_resp.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                comp1_resp.frameNStart = frameN  # exact frame index
                comp1_resp.tStart = t  # local t and not account for scr refresh
                comp1_resp.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(comp1_resp, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'comp1_resp.started')
                # update status
                comp1_resp.status = STARTED
                # keyboard checking is just starting
                waitOnFlip = True
                win.callOnFlip(comp1_resp.clock.reset)  # t=0 on next screen flip
                win.callOnFlip(comp1_resp.clearEvents, eventType='keyboard')  # clear events on next screen flip
            if comp1_resp.status == STARTED and not waitOnFlip:
                theseKeys = comp1_resp.getKeys(keyList=['j', 'f','J','F'], ignoreKeys=["escape"], waitRelease=False)
                _comp1_resp_allKeys.extend(theseKeys)
                if len(_comp1_resp_allKeys):
                    comp1_resp.keys = _comp1_resp_allKeys[-1].name  # just the last key pressed
                    comp1_resp.rt = _comp1_resp_allKeys[-1].rt
                    comp1_resp.duration = _comp1_resp_allKeys[-1].duration
                    # was this correct?
                    if (comp1_resp.keys == str(response)) or (comp1_resp.keys == response):
                        comp1_resp.corr = 1
                    else:
                        comp1_resp.corr = 0
                    # a response ends the routine
                    continueRoutine = False
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, win=win)
                return
            # pause experiment here if requested
            if thisExp.status == PAUSED:
                pauseExperiment(
                    thisExp=thisExp, 
                    win=win, 
                    timers=[routineTimer], 
                    playbackComponents=[]
                )
                # skip the frame we paused on
                continue
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                prac_comp.forceEnded = routineForceEnded = True
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in prac_comp.components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "prac_comp" ---
        for thisComponent in prac_comp.components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # store stop times for prac_comp
        prac_comp.tStop = globalClock.getTime(format='float')
        prac_comp.tStopRefresh = tThisFlipGlobal
        thisExp.addData('prac_comp.stopped', prac_comp.tStop)
        # check responses
        if comp1_resp.keys in ['', [], None]:  # No response was made
            comp1_resp.keys = None
            # was no response the correct answer?!
            if str(response).lower() == 'none':
               comp1_resp.corr = 1;  # correct non-response
            else:
               comp1_resp.corr = 0;  # failed to respond (incorrectly)
        # store data for practice (TrialHandler)
        practice.addData('comp1_resp.keys',comp1_resp.keys)
        practice.addData('comp1_resp.corr', comp1_resp.corr)
        if comp1_resp.keys != None:  # we had a response
            practice.addData('comp1_resp.rt', comp1_resp.rt)
            practice.addData('comp1_resp.duration', comp1_resp.duration)
        # the Routine "prac_comp" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        
        # --- Prepare to start Routine "feedback" ---
        # create an object to store info about Routine feedback
        feedback = data.Routine(
            name='feedback',
            components=[fb],
        )
        feedback.status = NOT_STARTED
        continueRoutine = True
        # update component parameters for each repeat
        # Run 'Begin Routine' code from code_11
        if comp1_resp.keys:
            user_key = comp1_resp.keys[0] if isinstance(comp1_resp.keys, list) else comp1_resp.keys
        else:
            user_key = ""
        correct_ans = str(response).lower().strip()
        user_key = str(user_key).lower().strip()
        if user_key == correct_ans:
            fb_text = "정답!"
            fb_col = "green"
        else:
            fb_text = "오답"
            fb_col = "red"
        fb.setText(fb_text)
        # store start times for feedback
        feedback.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
        feedback.tStart = globalClock.getTime(format='float')
        feedback.status = STARTED
        thisExp.addData('feedback.started', feedback.tStart)
        feedback.maxDuration = None
        # keep track of which components have finished
        feedbackComponents = feedback.components
        for thisComponent in feedback.components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "feedback" ---
        # if trial has changed, end Routine now
        if isinstance(practice, data.TrialHandler2) and thisPractice.thisN != practice.thisTrial.thisN:
            continueRoutine = False
        feedback.forceEnded = routineForceEnded = not continueRoutine
        while continueRoutine and routineTimer.getTime() < 0.5:
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *fb* updates
            
            # if fb is starting this frame...
            if fb.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                fb.frameNStart = frameN  # exact frame index
                fb.tStart = t  # local t and not account for scr refresh
                fb.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(fb, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'fb.started')
                # update status
                fb.status = STARTED
                fb.setAutoDraw(True)
            
            # if fb is active this frame...
            if fb.status == STARTED:
                # update params
                pass
            
            # if fb is stopping this frame...
            if fb.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > fb.tStartRefresh + 0.5-frameTolerance:
                    # keep track of stop time/frame for later
                    fb.tStop = t  # not accounting for scr refresh
                    fb.tStopRefresh = tThisFlipGlobal  # on global time
                    fb.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'fb.stopped')
                    # update status
                    fb.status = FINISHED
                    fb.setAutoDraw(False)
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, win=win)
                return
            # pause experiment here if requested
            if thisExp.status == PAUSED:
                pauseExperiment(
                    thisExp=thisExp, 
                    win=win, 
                    timers=[routineTimer], 
                    playbackComponents=[]
                )
                # skip the frame we paused on
                continue
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                feedback.forceEnded = routineForceEnded = True
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in feedback.components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "feedback" ---
        for thisComponent in feedback.components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # store stop times for feedback
        feedback.tStop = globalClock.getTime(format='float')
        feedback.tStopRefresh = tThisFlipGlobal
        thisExp.addData('feedback.stopped', feedback.tStop)
        # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
        if feedback.maxDurationReached:
            routineTimer.addTime(-feedback.maxDuration)
        elif feedback.forceEnded:
            routineTimer.reset()
        else:
            routineTimer.addTime(-0.500000)
        thisExp.nextEntry()
        
    # completed 1.0 repeats of 'practice'
    
    if thisSession is not None:
        # if running in a Session with a Liaison client, send data up to now
        thisSession.sendExperimentData()
    
    # --- Prepare to start Routine "main_intro" ---
    # create an object to store info about Routine main_intro
    main_intro = data.Routine(
        name='main_intro',
        components=[main, key_resp_2],
    )
    main_intro.status = NOT_STARTED
    continueRoutine = True
    # update component parameters for each repeat
    # create starting attributes for key_resp_2
    key_resp_2.keys = []
    key_resp_2.rt = []
    _key_resp_2_allKeys = []
    # store start times for main_intro
    main_intro.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
    main_intro.tStart = globalClock.getTime(format='float')
    main_intro.status = STARTED
    thisExp.addData('main_intro.started', main_intro.tStart)
    main_intro.maxDuration = None
    # keep track of which components have finished
    main_introComponents = main_intro.components
    for thisComponent in main_intro.components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "main_intro" ---
    main_intro.forceEnded = routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *main* updates
        
        # if main is starting this frame...
        if main.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            main.frameNStart = frameN  # exact frame index
            main.tStart = t  # local t and not account for scr refresh
            main.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(main, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'main.started')
            # update status
            main.status = STARTED
            main.setAutoDraw(True)
        
        # if main is active this frame...
        if main.status == STARTED:
            # update params
            pass
        
        # *key_resp_2* updates
        waitOnFlip = False
        
        # if key_resp_2 is starting this frame...
        if key_resp_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            key_resp_2.frameNStart = frameN  # exact frame index
            key_resp_2.tStart = t  # local t and not account for scr refresh
            key_resp_2.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(key_resp_2, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'key_resp_2.started')
            # update status
            key_resp_2.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(key_resp_2.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(key_resp_2.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if key_resp_2.status == STARTED and not waitOnFlip:
            theseKeys = key_resp_2.getKeys(keyList=['space'], ignoreKeys=["escape"], waitRelease=False)
            _key_resp_2_allKeys.extend(theseKeys)
            if len(_key_resp_2_allKeys):
                key_resp_2.keys = _key_resp_2_allKeys[-1].name  # just the last key pressed
                key_resp_2.rt = _key_resp_2_allKeys[-1].rt
                key_resp_2.duration = _key_resp_2_allKeys[-1].duration
                # a response ends the routine
                continueRoutine = False
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, win=win)
            return
        # pause experiment here if requested
        if thisExp.status == PAUSED:
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[routineTimer], 
                playbackComponents=[]
            )
            # skip the frame we paused on
            continue
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            main_intro.forceEnded = routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in main_intro.components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "main_intro" ---
    for thisComponent in main_intro.components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # store stop times for main_intro
    main_intro.tStop = globalClock.getTime(format='float')
    main_intro.tStopRefresh = tThisFlipGlobal
    thisExp.addData('main_intro.stopped', main_intro.tStop)
    # check responses
    if key_resp_2.keys in ['', [], None]:  # No response was made
        key_resp_2.keys = None
    thisExp.addData('key_resp_2.keys',key_resp_2.keys)
    if key_resp_2.keys != None:  # we had a response
        thisExp.addData('key_resp_2.rt', key_resp_2.rt)
        thisExp.addData('key_resp_2.duration', key_resp_2.duration)
    thisExp.nextEntry()
    # the Routine "main_intro" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # set up handler to look after randomisation of conditions etc
    main_exp = data.TrialHandler2(
        name='main_exp',
        nReps=1.0, 
        method='random', 
        extraInfo=expInfo, 
        originPath=-1, 
        trialList=data.importConditions('sprt_list_A.xlsx'), 
        seed=None, 
    )
    thisExp.addLoop(main_exp)  # add the loop to the experiment
    thisMain_exp = main_exp.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisMain_exp.rgb)
    if thisMain_exp != None:
        for paramName in thisMain_exp:
            globals()[paramName] = thisMain_exp[paramName]
    if thisSession is not None:
        # if running in a Session with a Liaison client, send data up to now
        thisSession.sendExperimentData()
    
    for thisMain_exp in main_exp:
        currentLoop = main_exp
        thisExp.timestampOnFlip(win, 'thisRow.t', format=globalClock.format)
        if thisSession is not None:
            # if running in a Session with a Liaison client, send data up to now
            thisSession.sendExperimentData()
        # abbreviate parameter names if possible (e.g. rgb = thisMain_exp.rgb)
        if thisMain_exp != None:
            for paramName in thisMain_exp:
                globals()[paramName] = thisMain_exp[paramName]
        
        # --- Prepare to start Routine "main_fix" ---
        # create an object to store info about Routine main_fix
        main_fix = data.Routine(
            name='main_fix',
            components=[fixation2],
        )
        main_fix.status = NOT_STARTED
        continueRoutine = True
        # update component parameters for each repeat
        # store start times for main_fix
        main_fix.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
        main_fix.tStart = globalClock.getTime(format='float')
        main_fix.status = STARTED
        thisExp.addData('main_fix.started', main_fix.tStart)
        main_fix.maxDuration = None
        # keep track of which components have finished
        main_fixComponents = main_fix.components
        for thisComponent in main_fix.components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "main_fix" ---
        # if trial has changed, end Routine now
        if isinstance(main_exp, data.TrialHandler2) and thisMain_exp.thisN != main_exp.thisTrial.thisN:
            continueRoutine = False
        main_fix.forceEnded = routineForceEnded = not continueRoutine
        while continueRoutine and routineTimer.getTime() < 1.0:
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *fixation2* updates
            
            # if fixation2 is starting this frame...
            if fixation2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                fixation2.frameNStart = frameN  # exact frame index
                fixation2.tStart = t  # local t and not account for scr refresh
                fixation2.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(fixation2, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'fixation2.started')
                # update status
                fixation2.status = STARTED
                fixation2.setAutoDraw(True)
            
            # if fixation2 is active this frame...
            if fixation2.status == STARTED:
                # update params
                pass
            
            # if fixation2 is stopping this frame...
            if fixation2.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > fixation2.tStartRefresh + 1.0-frameTolerance:
                    # keep track of stop time/frame for later
                    fixation2.tStop = t  # not accounting for scr refresh
                    fixation2.tStopRefresh = tThisFlipGlobal  # on global time
                    fixation2.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'fixation2.stopped')
                    # update status
                    fixation2.status = FINISHED
                    fixation2.setAutoDraw(False)
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, win=win)
                return
            # pause experiment here if requested
            if thisExp.status == PAUSED:
                pauseExperiment(
                    thisExp=thisExp, 
                    win=win, 
                    timers=[routineTimer], 
                    playbackComponents=[]
                )
                # skip the frame we paused on
                continue
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                main_fix.forceEnded = routineForceEnded = True
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in main_fix.components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "main_fix" ---
        for thisComponent in main_fix.components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # store stop times for main_fix
        main_fix.tStop = globalClock.getTime(format='float')
        main_fix.tStopRefresh = tThisFlipGlobal
        thisExp.addData('main_fix.stopped', main_fix.tStop)
        # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
        if main_fix.maxDurationReached:
            routineTimer.addTime(-main_fix.maxDuration)
        elif main_fix.forceEnded:
            routineTimer.reset()
        else:
            routineTimer.addTime(-1.000000)
        
        # --- Prepare to start Routine "main_mask" ---
        # create an object to store info about Routine main_mask
        main_mask = data.Routine(
            name='main_mask',
            components=[masking2, skip_mask2],
        )
        main_mask.status = NOT_STARTED
        continueRoutine = True
        # update component parameters for each repeat
        masking2.setText('### ### ### ###')
        # create starting attributes for skip_mask2
        skip_mask2.keys = []
        skip_mask2.rt = []
        _skip_mask2_allKeys = []
        # store start times for main_mask
        main_mask.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
        main_mask.tStart = globalClock.getTime(format='float')
        main_mask.status = STARTED
        thisExp.addData('main_mask.started', main_mask.tStart)
        main_mask.maxDuration = None
        # keep track of which components have finished
        main_maskComponents = main_mask.components
        for thisComponent in main_mask.components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "main_mask" ---
        # if trial has changed, end Routine now
        if isinstance(main_exp, data.TrialHandler2) and thisMain_exp.thisN != main_exp.thisTrial.thisN:
            continueRoutine = False
        main_mask.forceEnded = routineForceEnded = not continueRoutine
        while continueRoutine:
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *masking2* updates
            
            # if masking2 is starting this frame...
            if masking2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                masking2.frameNStart = frameN  # exact frame index
                masking2.tStart = t  # local t and not account for scr refresh
                masking2.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(masking2, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'masking2.started')
                # update status
                masking2.status = STARTED
                masking2.setAutoDraw(True)
            
            # if masking2 is active this frame...
            if masking2.status == STARTED:
                # update params
                pass
            
            # *skip_mask2* updates
            waitOnFlip = False
            
            # if skip_mask2 is starting this frame...
            if skip_mask2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                skip_mask2.frameNStart = frameN  # exact frame index
                skip_mask2.tStart = t  # local t and not account for scr refresh
                skip_mask2.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(skip_mask2, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'skip_mask2.started')
                # update status
                skip_mask2.status = STARTED
                # keyboard checking is just starting
                waitOnFlip = True
                win.callOnFlip(skip_mask2.clock.reset)  # t=0 on next screen flip
                win.callOnFlip(skip_mask2.clearEvents, eventType='keyboard')  # clear events on next screen flip
            if skip_mask2.status == STARTED and not waitOnFlip:
                theseKeys = skip_mask2.getKeys(keyList=['space'], ignoreKeys=["escape"], waitRelease=False)
                _skip_mask2_allKeys.extend(theseKeys)
                if len(_skip_mask2_allKeys):
                    skip_mask2.keys = _skip_mask2_allKeys[-1].name  # just the last key pressed
                    skip_mask2.rt = _skip_mask2_allKeys[-1].rt
                    skip_mask2.duration = _skip_mask2_allKeys[-1].duration
                    # a response ends the routine
                    continueRoutine = False
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, win=win)
                return
            # pause experiment here if requested
            if thisExp.status == PAUSED:
                pauseExperiment(
                    thisExp=thisExp, 
                    win=win, 
                    timers=[routineTimer], 
                    playbackComponents=[]
                )
                # skip the frame we paused on
                continue
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                main_mask.forceEnded = routineForceEnded = True
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in main_mask.components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "main_mask" ---
        for thisComponent in main_mask.components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # store stop times for main_mask
        main_mask.tStop = globalClock.getTime(format='float')
        main_mask.tStopRefresh = tThisFlipGlobal
        thisExp.addData('main_mask.stopped', main_mask.tStop)
        # check responses
        if skip_mask2.keys in ['', [], None]:  # No response was made
            skip_mask2.keys = None
        main_exp.addData('skip_mask2.keys',skip_mask2.keys)
        if skip_mask2.keys != None:  # we had a response
            main_exp.addData('skip_mask2.rt', skip_mask2.rt)
            main_exp.addData('skip_mask2.duration', skip_mask2.duration)
        # the Routine "main_mask" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        
        # --- Prepare to start Routine "main_P1" ---
        # create an object to store info about Routine main_P1
        main_P1 = data.Routine(
            name='main_P1',
            components=[main_p1_stim, main_p1_resp],
        )
        main_P1.status = NOT_STARTED
        continueRoutine = True
        # update component parameters for each repeat
        # Run 'Begin Routine' code from code_6
        pp1 = p1
        pp2 = "###"
        pp3 = "###"
        pp4 = "###"
        sen = pp1 + " " + pp2 + " " + pp3 + " " + pp4+ " "
        main_p1_stim.setText(sen)
        # create starting attributes for main_p1_resp
        main_p1_resp.keys = []
        main_p1_resp.rt = []
        _main_p1_resp_allKeys = []
        # store start times for main_P1
        main_P1.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
        main_P1.tStart = globalClock.getTime(format='float')
        main_P1.status = STARTED
        thisExp.addData('main_P1.started', main_P1.tStart)
        main_P1.maxDuration = None
        # keep track of which components have finished
        main_P1Components = main_P1.components
        for thisComponent in main_P1.components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "main_P1" ---
        # if trial has changed, end Routine now
        if isinstance(main_exp, data.TrialHandler2) and thisMain_exp.thisN != main_exp.thisTrial.thisN:
            continueRoutine = False
        main_P1.forceEnded = routineForceEnded = not continueRoutine
        while continueRoutine:
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *main_p1_stim* updates
            
            # if main_p1_stim is starting this frame...
            if main_p1_stim.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                main_p1_stim.frameNStart = frameN  # exact frame index
                main_p1_stim.tStart = t  # local t and not account for scr refresh
                main_p1_stim.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(main_p1_stim, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'main_p1_stim.started')
                # update status
                main_p1_stim.status = STARTED
                main_p1_stim.setAutoDraw(True)
            
            # if main_p1_stim is active this frame...
            if main_p1_stim.status == STARTED:
                # update params
                pass
            
            # *main_p1_resp* updates
            waitOnFlip = False
            
            # if main_p1_resp is starting this frame...
            if main_p1_resp.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                main_p1_resp.frameNStart = frameN  # exact frame index
                main_p1_resp.tStart = t  # local t and not account for scr refresh
                main_p1_resp.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(main_p1_resp, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'main_p1_resp.started')
                # update status
                main_p1_resp.status = STARTED
                # keyboard checking is just starting
                waitOnFlip = True
                win.callOnFlip(main_p1_resp.clock.reset)  # t=0 on next screen flip
                win.callOnFlip(main_p1_resp.clearEvents, eventType='keyboard')  # clear events on next screen flip
            if main_p1_resp.status == STARTED and not waitOnFlip:
                theseKeys = main_p1_resp.getKeys(keyList=['space'], ignoreKeys=["escape"], waitRelease=False)
                _main_p1_resp_allKeys.extend(theseKeys)
                if len(_main_p1_resp_allKeys):
                    main_p1_resp.keys = _main_p1_resp_allKeys[-1].name  # just the last key pressed
                    main_p1_resp.rt = _main_p1_resp_allKeys[-1].rt
                    main_p1_resp.duration = _main_p1_resp_allKeys[-1].duration
                    # a response ends the routine
                    continueRoutine = False
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, win=win)
                return
            # pause experiment here if requested
            if thisExp.status == PAUSED:
                pauseExperiment(
                    thisExp=thisExp, 
                    win=win, 
                    timers=[routineTimer], 
                    playbackComponents=[]
                )
                # skip the frame we paused on
                continue
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                main_P1.forceEnded = routineForceEnded = True
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in main_P1.components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "main_P1" ---
        for thisComponent in main_P1.components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # store stop times for main_P1
        main_P1.tStop = globalClock.getTime(format='float')
        main_P1.tStopRefresh = tThisFlipGlobal
        thisExp.addData('main_P1.stopped', main_P1.tStop)
        # check responses
        if main_p1_resp.keys in ['', [], None]:  # No response was made
            main_p1_resp.keys = None
        main_exp.addData('main_p1_resp.keys',main_p1_resp.keys)
        if main_p1_resp.keys != None:  # we had a response
            main_exp.addData('main_p1_resp.rt', main_p1_resp.rt)
            main_exp.addData('main_p1_resp.duration', main_p1_resp.duration)
        # the Routine "main_P1" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        
        # --- Prepare to start Routine "main_P2" ---
        # create an object to store info about Routine main_P2
        main_P2 = data.Routine(
            name='main_P2',
            components=[main_p2_stim, main_p2_resp],
        )
        main_P2.status = NOT_STARTED
        continueRoutine = True
        # update component parameters for each repeat
        # Run 'Begin Routine' code from code_8
        pp1 = "###"
        pp2 = p2
        pp3 = "###"
        pp4 = "###"
        sen = pp1 + " " + pp2 + " " + pp3 + " " + pp4+ " "
        main_p2_stim.setText(sen)
        # create starting attributes for main_p2_resp
        main_p2_resp.keys = []
        main_p2_resp.rt = []
        _main_p2_resp_allKeys = []
        # store start times for main_P2
        main_P2.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
        main_P2.tStart = globalClock.getTime(format='float')
        main_P2.status = STARTED
        thisExp.addData('main_P2.started', main_P2.tStart)
        main_P2.maxDuration = None
        # keep track of which components have finished
        main_P2Components = main_P2.components
        for thisComponent in main_P2.components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "main_P2" ---
        # if trial has changed, end Routine now
        if isinstance(main_exp, data.TrialHandler2) and thisMain_exp.thisN != main_exp.thisTrial.thisN:
            continueRoutine = False
        main_P2.forceEnded = routineForceEnded = not continueRoutine
        while continueRoutine:
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *main_p2_stim* updates
            
            # if main_p2_stim is starting this frame...
            if main_p2_stim.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                main_p2_stim.frameNStart = frameN  # exact frame index
                main_p2_stim.tStart = t  # local t and not account for scr refresh
                main_p2_stim.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(main_p2_stim, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'main_p2_stim.started')
                # update status
                main_p2_stim.status = STARTED
                main_p2_stim.setAutoDraw(True)
            
            # if main_p2_stim is active this frame...
            if main_p2_stim.status == STARTED:
                # update params
                pass
            
            # *main_p2_resp* updates
            waitOnFlip = False
            
            # if main_p2_resp is starting this frame...
            if main_p2_resp.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                main_p2_resp.frameNStart = frameN  # exact frame index
                main_p2_resp.tStart = t  # local t and not account for scr refresh
                main_p2_resp.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(main_p2_resp, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'main_p2_resp.started')
                # update status
                main_p2_resp.status = STARTED
                # keyboard checking is just starting
                waitOnFlip = True
                win.callOnFlip(main_p2_resp.clock.reset)  # t=0 on next screen flip
                win.callOnFlip(main_p2_resp.clearEvents, eventType='keyboard')  # clear events on next screen flip
            if main_p2_resp.status == STARTED and not waitOnFlip:
                theseKeys = main_p2_resp.getKeys(keyList=['space'], ignoreKeys=["escape"], waitRelease=False)
                _main_p2_resp_allKeys.extend(theseKeys)
                if len(_main_p2_resp_allKeys):
                    main_p2_resp.keys = _main_p2_resp_allKeys[-1].name  # just the last key pressed
                    main_p2_resp.rt = _main_p2_resp_allKeys[-1].rt
                    main_p2_resp.duration = _main_p2_resp_allKeys[-1].duration
                    # a response ends the routine
                    continueRoutine = False
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, win=win)
                return
            # pause experiment here if requested
            if thisExp.status == PAUSED:
                pauseExperiment(
                    thisExp=thisExp, 
                    win=win, 
                    timers=[routineTimer], 
                    playbackComponents=[]
                )
                # skip the frame we paused on
                continue
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                main_P2.forceEnded = routineForceEnded = True
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in main_P2.components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "main_P2" ---
        for thisComponent in main_P2.components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # store stop times for main_P2
        main_P2.tStop = globalClock.getTime(format='float')
        main_P2.tStopRefresh = tThisFlipGlobal
        thisExp.addData('main_P2.stopped', main_P2.tStop)
        # check responses
        if main_p2_resp.keys in ['', [], None]:  # No response was made
            main_p2_resp.keys = None
        main_exp.addData('main_p2_resp.keys',main_p2_resp.keys)
        if main_p2_resp.keys != None:  # we had a response
            main_exp.addData('main_p2_resp.rt', main_p2_resp.rt)
            main_exp.addData('main_p2_resp.duration', main_p2_resp.duration)
        # the Routine "main_P2" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        
        # --- Prepare to start Routine "main_P3" ---
        # create an object to store info about Routine main_P3
        main_P3 = data.Routine(
            name='main_P3',
            components=[main_p3_stim, main_p3_resp],
        )
        main_P3.status = NOT_STARTED
        continueRoutine = True
        # update component parameters for each repeat
        # Run 'Begin Routine' code from code_9
        pp1 = "###"
        pp2 = "###"
        pp3 = p3
        pp4 = "###"
        sen = pp1 + " " + pp2 + " " + pp3 + " " + pp4+ " "
        main_p3_stim.setText(sen)
        # create starting attributes for main_p3_resp
        main_p3_resp.keys = []
        main_p3_resp.rt = []
        _main_p3_resp_allKeys = []
        # store start times for main_P3
        main_P3.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
        main_P3.tStart = globalClock.getTime(format='float')
        main_P3.status = STARTED
        thisExp.addData('main_P3.started', main_P3.tStart)
        main_P3.maxDuration = None
        # keep track of which components have finished
        main_P3Components = main_P3.components
        for thisComponent in main_P3.components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "main_P3" ---
        # if trial has changed, end Routine now
        if isinstance(main_exp, data.TrialHandler2) and thisMain_exp.thisN != main_exp.thisTrial.thisN:
            continueRoutine = False
        main_P3.forceEnded = routineForceEnded = not continueRoutine
        while continueRoutine:
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *main_p3_stim* updates
            
            # if main_p3_stim is starting this frame...
            if main_p3_stim.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                main_p3_stim.frameNStart = frameN  # exact frame index
                main_p3_stim.tStart = t  # local t and not account for scr refresh
                main_p3_stim.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(main_p3_stim, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'main_p3_stim.started')
                # update status
                main_p3_stim.status = STARTED
                main_p3_stim.setAutoDraw(True)
            
            # if main_p3_stim is active this frame...
            if main_p3_stim.status == STARTED:
                # update params
                pass
            
            # *main_p3_resp* updates
            waitOnFlip = False
            
            # if main_p3_resp is starting this frame...
            if main_p3_resp.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                main_p3_resp.frameNStart = frameN  # exact frame index
                main_p3_resp.tStart = t  # local t and not account for scr refresh
                main_p3_resp.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(main_p3_resp, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'main_p3_resp.started')
                # update status
                main_p3_resp.status = STARTED
                # keyboard checking is just starting
                waitOnFlip = True
                win.callOnFlip(main_p3_resp.clock.reset)  # t=0 on next screen flip
                win.callOnFlip(main_p3_resp.clearEvents, eventType='keyboard')  # clear events on next screen flip
            if main_p3_resp.status == STARTED and not waitOnFlip:
                theseKeys = main_p3_resp.getKeys(keyList=['space'], ignoreKeys=["escape"], waitRelease=False)
                _main_p3_resp_allKeys.extend(theseKeys)
                if len(_main_p3_resp_allKeys):
                    main_p3_resp.keys = _main_p3_resp_allKeys[-1].name  # just the last key pressed
                    main_p3_resp.rt = _main_p3_resp_allKeys[-1].rt
                    main_p3_resp.duration = _main_p3_resp_allKeys[-1].duration
                    # a response ends the routine
                    continueRoutine = False
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, win=win)
                return
            # pause experiment here if requested
            if thisExp.status == PAUSED:
                pauseExperiment(
                    thisExp=thisExp, 
                    win=win, 
                    timers=[routineTimer], 
                    playbackComponents=[]
                )
                # skip the frame we paused on
                continue
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                main_P3.forceEnded = routineForceEnded = True
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in main_P3.components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "main_P3" ---
        for thisComponent in main_P3.components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # store stop times for main_P3
        main_P3.tStop = globalClock.getTime(format='float')
        main_P3.tStopRefresh = tThisFlipGlobal
        thisExp.addData('main_P3.stopped', main_P3.tStop)
        # check responses
        if main_p3_resp.keys in ['', [], None]:  # No response was made
            main_p3_resp.keys = None
        main_exp.addData('main_p3_resp.keys',main_p3_resp.keys)
        if main_p3_resp.keys != None:  # we had a response
            main_exp.addData('main_p3_resp.rt', main_p3_resp.rt)
            main_exp.addData('main_p3_resp.duration', main_p3_resp.duration)
        # the Routine "main_P3" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        
        # --- Prepare to start Routine "main_P4" ---
        # create an object to store info about Routine main_P4
        main_P4 = data.Routine(
            name='main_P4',
            components=[main_p4_stim, main_p4_resp],
        )
        main_P4.status = NOT_STARTED
        continueRoutine = True
        # update component parameters for each repeat
        # Run 'Begin Routine' code from code_10
        pp1 = "###"
        pp2 = "###"
        pp3 = "###"
        pp4 = p4
        sen = pp1 + " " + pp2 + " " + pp3 + " " + pp4+ " "
        main_p4_stim.setText(sen)
        # create starting attributes for main_p4_resp
        main_p4_resp.keys = []
        main_p4_resp.rt = []
        _main_p4_resp_allKeys = []
        # store start times for main_P4
        main_P4.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
        main_P4.tStart = globalClock.getTime(format='float')
        main_P4.status = STARTED
        thisExp.addData('main_P4.started', main_P4.tStart)
        main_P4.maxDuration = None
        # keep track of which components have finished
        main_P4Components = main_P4.components
        for thisComponent in main_P4.components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "main_P4" ---
        # if trial has changed, end Routine now
        if isinstance(main_exp, data.TrialHandler2) and thisMain_exp.thisN != main_exp.thisTrial.thisN:
            continueRoutine = False
        main_P4.forceEnded = routineForceEnded = not continueRoutine
        while continueRoutine:
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *main_p4_stim* updates
            
            # if main_p4_stim is starting this frame...
            if main_p4_stim.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                main_p4_stim.frameNStart = frameN  # exact frame index
                main_p4_stim.tStart = t  # local t and not account for scr refresh
                main_p4_stim.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(main_p4_stim, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'main_p4_stim.started')
                # update status
                main_p4_stim.status = STARTED
                main_p4_stim.setAutoDraw(True)
            
            # if main_p4_stim is active this frame...
            if main_p4_stim.status == STARTED:
                # update params
                pass
            
            # *main_p4_resp* updates
            waitOnFlip = False
            
            # if main_p4_resp is starting this frame...
            if main_p4_resp.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                main_p4_resp.frameNStart = frameN  # exact frame index
                main_p4_resp.tStart = t  # local t and not account for scr refresh
                main_p4_resp.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(main_p4_resp, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'main_p4_resp.started')
                # update status
                main_p4_resp.status = STARTED
                # keyboard checking is just starting
                waitOnFlip = True
                win.callOnFlip(main_p4_resp.clock.reset)  # t=0 on next screen flip
                win.callOnFlip(main_p4_resp.clearEvents, eventType='keyboard')  # clear events on next screen flip
            if main_p4_resp.status == STARTED and not waitOnFlip:
                theseKeys = main_p4_resp.getKeys(keyList=['space'], ignoreKeys=["escape"], waitRelease=False)
                _main_p4_resp_allKeys.extend(theseKeys)
                if len(_main_p4_resp_allKeys):
                    main_p4_resp.keys = _main_p4_resp_allKeys[-1].name  # just the last key pressed
                    main_p4_resp.rt = _main_p4_resp_allKeys[-1].rt
                    main_p4_resp.duration = _main_p4_resp_allKeys[-1].duration
                    # a response ends the routine
                    continueRoutine = False
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, win=win)
                return
            # pause experiment here if requested
            if thisExp.status == PAUSED:
                pauseExperiment(
                    thisExp=thisExp, 
                    win=win, 
                    timers=[routineTimer], 
                    playbackComponents=[]
                )
                # skip the frame we paused on
                continue
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                main_P4.forceEnded = routineForceEnded = True
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in main_P4.components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "main_P4" ---
        for thisComponent in main_P4.components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # store stop times for main_P4
        main_P4.tStop = globalClock.getTime(format='float')
        main_P4.tStopRefresh = tThisFlipGlobal
        thisExp.addData('main_P4.stopped', main_P4.tStop)
        # check responses
        if main_p4_resp.keys in ['', [], None]:  # No response was made
            main_p4_resp.keys = None
        main_exp.addData('main_p4_resp.keys',main_p4_resp.keys)
        if main_p4_resp.keys != None:  # we had a response
            main_exp.addData('main_p4_resp.rt', main_p4_resp.rt)
            main_exp.addData('main_p4_resp.duration', main_p4_resp.duration)
        # the Routine "main_P4" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        
        # --- Prepare to start Routine "main_comp" ---
        # create an object to store info about Routine main_comp
        main_comp = data.Routine(
            name='main_comp',
            components=[comprehension2, main_comp_resp],
        )
        main_comp.status = NOT_STARTED
        continueRoutine = True
        # update component parameters for each repeat
        comprehension2.setText(comprehension)
        # create starting attributes for main_comp_resp
        main_comp_resp.keys = []
        main_comp_resp.rt = []
        _main_comp_resp_allKeys = []
        # store start times for main_comp
        main_comp.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
        main_comp.tStart = globalClock.getTime(format='float')
        main_comp.status = STARTED
        thisExp.addData('main_comp.started', main_comp.tStart)
        main_comp.maxDuration = None
        # keep track of which components have finished
        main_compComponents = main_comp.components
        for thisComponent in main_comp.components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "main_comp" ---
        # if trial has changed, end Routine now
        if isinstance(main_exp, data.TrialHandler2) and thisMain_exp.thisN != main_exp.thisTrial.thisN:
            continueRoutine = False
        main_comp.forceEnded = routineForceEnded = not continueRoutine
        while continueRoutine:
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *comprehension2* updates
            
            # if comprehension2 is starting this frame...
            if comprehension2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                comprehension2.frameNStart = frameN  # exact frame index
                comprehension2.tStart = t  # local t and not account for scr refresh
                comprehension2.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(comprehension2, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'comprehension2.started')
                # update status
                comprehension2.status = STARTED
                comprehension2.setAutoDraw(True)
            
            # if comprehension2 is active this frame...
            if comprehension2.status == STARTED:
                # update params
                pass
            
            # *main_comp_resp* updates
            waitOnFlip = False
            
            # if main_comp_resp is starting this frame...
            if main_comp_resp.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                main_comp_resp.frameNStart = frameN  # exact frame index
                main_comp_resp.tStart = t  # local t and not account for scr refresh
                main_comp_resp.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(main_comp_resp, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'main_comp_resp.started')
                # update status
                main_comp_resp.status = STARTED
                # keyboard checking is just starting
                waitOnFlip = True
                win.callOnFlip(main_comp_resp.clock.reset)  # t=0 on next screen flip
                win.callOnFlip(main_comp_resp.clearEvents, eventType='keyboard')  # clear events on next screen flip
            if main_comp_resp.status == STARTED and not waitOnFlip:
                theseKeys = main_comp_resp.getKeys(keyList=['j', 'f','J', 'F'], ignoreKeys=["escape"], waitRelease=False)
                _main_comp_resp_allKeys.extend(theseKeys)
                if len(_main_comp_resp_allKeys):
                    main_comp_resp.keys = _main_comp_resp_allKeys[-1].name  # just the last key pressed
                    main_comp_resp.rt = _main_comp_resp_allKeys[-1].rt
                    main_comp_resp.duration = _main_comp_resp_allKeys[-1].duration
                    # was this correct?
                    if (main_comp_resp.keys == str(response)) or (main_comp_resp.keys == response):
                        main_comp_resp.corr = 1
                    else:
                        main_comp_resp.corr = 0
                    # a response ends the routine
                    continueRoutine = False
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, win=win)
                return
            # pause experiment here if requested
            if thisExp.status == PAUSED:
                pauseExperiment(
                    thisExp=thisExp, 
                    win=win, 
                    timers=[routineTimer], 
                    playbackComponents=[]
                )
                # skip the frame we paused on
                continue
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                main_comp.forceEnded = routineForceEnded = True
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in main_comp.components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "main_comp" ---
        for thisComponent in main_comp.components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # store stop times for main_comp
        main_comp.tStop = globalClock.getTime(format='float')
        main_comp.tStopRefresh = tThisFlipGlobal
        thisExp.addData('main_comp.stopped', main_comp.tStop)
        # check responses
        if main_comp_resp.keys in ['', [], None]:  # No response was made
            main_comp_resp.keys = None
            # was no response the correct answer?!
            if str(response).lower() == 'none':
               main_comp_resp.corr = 1;  # correct non-response
            else:
               main_comp_resp.corr = 0;  # failed to respond (incorrectly)
        # store data for main_exp (TrialHandler)
        main_exp.addData('main_comp_resp.keys',main_comp_resp.keys)
        main_exp.addData('main_comp_resp.corr', main_comp_resp.corr)
        if main_comp_resp.keys != None:  # we had a response
            main_exp.addData('main_comp_resp.rt', main_comp_resp.rt)
            main_exp.addData('main_comp_resp.duration', main_comp_resp.duration)
        # the Routine "main_comp" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        thisExp.nextEntry()
        
    # completed 1.0 repeats of 'main_exp'
    
    if thisSession is not None:
        # if running in a Session with a Liaison client, send data up to now
        thisSession.sendExperimentData()
    
    # --- Prepare to start Routine "ending" ---
    # create an object to store info about Routine ending
    ending = data.Routine(
        name='ending',
        components=[end],
    )
    ending.status = NOT_STARTED
    continueRoutine = True
    # update component parameters for each repeat
    # store start times for ending
    ending.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
    ending.tStart = globalClock.getTime(format='float')
    ending.status = STARTED
    thisExp.addData('ending.started', ending.tStart)
    ending.maxDuration = None
    # keep track of which components have finished
    endingComponents = ending.components
    for thisComponent in ending.components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "ending" ---
    ending.forceEnded = routineForceEnded = not continueRoutine
    while continueRoutine and routineTimer.getTime() < 3.0:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *end* updates
        
        # if end is starting this frame...
        if end.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            end.frameNStart = frameN  # exact frame index
            end.tStart = t  # local t and not account for scr refresh
            end.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(end, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'end.started')
            # update status
            end.status = STARTED
            end.setAutoDraw(True)
        
        # if end is active this frame...
        if end.status == STARTED:
            # update params
            pass
        
        # if end is stopping this frame...
        if end.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > end.tStartRefresh + 3.0-frameTolerance:
                # keep track of stop time/frame for later
                end.tStop = t  # not accounting for scr refresh
                end.tStopRefresh = tThisFlipGlobal  # on global time
                end.frameNStop = frameN  # exact frame index
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'end.stopped')
                # update status
                end.status = FINISHED
                end.setAutoDraw(False)
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, win=win)
            return
        # pause experiment here if requested
        if thisExp.status == PAUSED:
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[routineTimer], 
                playbackComponents=[]
            )
            # skip the frame we paused on
            continue
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            ending.forceEnded = routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in ending.components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "ending" ---
    for thisComponent in ending.components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # store stop times for ending
    ending.tStop = globalClock.getTime(format='float')
    ending.tStopRefresh = tThisFlipGlobal
    thisExp.addData('ending.stopped', ending.tStop)
    # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
    if ending.maxDurationReached:
        routineTimer.addTime(-ending.maxDuration)
    elif ending.forceEnded:
        routineTimer.reset()
    else:
        routineTimer.addTime(-3.000000)
    thisExp.nextEntry()
    
    # mark experiment as finished
    endExperiment(thisExp, win=win)


def saveData(thisExp):
    """
    Save data from this experiment
    
    Parameters
    ==========
    thisExp : psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    """
    filename = thisExp.dataFileName
    # these shouldn't be strictly necessary (should auto-save)
    thisExp.saveAsWideText(filename + '.csv', delim='auto')
    thisExp.saveAsPickle(filename)


def endExperiment(thisExp, win=None):
    """
    End this experiment, performing final shut down operations.
    
    This function does NOT close the window or end the Python process - use `quit` for this.
    
    Parameters
    ==========
    thisExp : psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    win : psychopy.visual.Window
        Window for this experiment.
    """
    if win is not None:
        # remove autodraw from all current components
        win.clearAutoDraw()
        # Flip one final time so any remaining win.callOnFlip() 
        # and win.timeOnFlip() tasks get executed
        win.flip()
    # return console logger level to WARNING
    logging.console.setLevel(logging.WARNING)
    # mark experiment handler as finished
    thisExp.status = FINISHED
    logging.flush()


def quit(thisExp, win=None, thisSession=None):
    """
    Fully quit, closing the window and ending the Python process.
    
    Parameters
    ==========
    win : psychopy.visual.Window
        Window to close.
    thisSession : psychopy.session.Session or None
        Handle of the Session object this experiment is being run from, if any.
    """
    thisExp.abort()  # or data files will save again on exit
    # make sure everything is closed down
    if win is not None:
        # Flip one final time so any remaining win.callOnFlip() 
        # and win.timeOnFlip() tasks get executed before quitting
        win.flip()
        win.close()
    logging.flush()
    if thisSession is not None:
        thisSession.stop()
    # terminate Python process
    core.quit()


# if running this experiment as a script...
if __name__ == '__main__':
    # call all functions in order
    expInfo = showExpInfoDlg(expInfo=expInfo)
    thisExp = setupData(expInfo=expInfo)
    logFile = setupLogging(filename=thisExp.dataFileName)
    win = setupWindow(expInfo=expInfo)
    setupDevices(expInfo=expInfo, thisExp=thisExp, win=win)
    run(
        expInfo=expInfo, 
        thisExp=thisExp, 
        win=win,
        globalClock='float'
    )
    saveData(thisExp=thisExp)
    quit(thisExp=thisExp, win=win)
