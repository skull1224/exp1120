﻿#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
This experiment was created using PsychoPy3 Experiment Builder (v2026.1.3),
    on Wed Nov 18 16:01:14 2026
If you publish work using this script the most relevant publication is:

    Peirce J, Gray JR, Simpson S, MacAskill M, Höchenberger R, Sogo H, Kastman E, Lindeløv JK. (2019) 
        PsychoPy2: Experiments in behavior made easy Behav Res 51: 195. 
        https://doi.org/10.3758/s13428-018-01193-y

"""

# --- Import packages ---
from psychopy import locale_setup
from psychopy import prefs
from psychopy import plugins
plugins.activatePlugins()
from psychopy import sound, gui, visual, core, data, event, logging, clock, colors, layout, hardware
from psychopy.tools import environmenttools
from psychopy.constants import (
    NOT_STARTED, STARTED, PLAYING, PAUSED, STOPPED, STOPPING, FINISHED, PRESSED, 
    RELEASED, FOREVER, priority
)

import numpy as np  # whole numpy lib is available, prepend 'np.'
from numpy import (sin, cos, tan, log, log10, pi, average,
                   sqrt, std, deg2rad, rad2deg, linspace, asarray)
from numpy.random import random, randint, normal, shuffle, choice as randchoice
import os  # handy system and path functions
import sys  # to get file system encoding

from psychopy.hardware import keyboard

# --- Setup global variables (available in all functions) ---
# create a device manager to handle hardware (keyboards, mice, mirophones, speakers, etc.)
deviceManager = hardware.DeviceManager()
# ensure that relative paths start from the same directory as this script
_thisDir = os.path.dirname(os.path.abspath(__file__))
# store info about the experiment session
psychopyVersion = '2026.1.3'
expName = 'form_priming'  # from the Builder filename that created this script
expVersion = '1.0'
# a list of functions to run when the experiment ends (starts off blank)
runAtExit = []
# information about this experiment
expInfo = {
    'participant': '',
    'group': ['A', 'B', 'C'],
    'order': ['1st-2nd', '2nd-1st'],
    'date|hid': data.getDateStr(),
    'expName|hid': expName,
    'expVersion|hid': expVersion,
    'psychopyVersion|hid': psychopyVersion,
}

# --- Define some variables which will change depending on pilot mode ---
'''
To run in pilot mode, either use the run/pilot toggle in Builder, Coder and Runner, 
or run the experiment with `--pilot` as an argument. To change what pilot 
#mode does, check out the 'Pilot mode' tab in preferences.
'''
# work out from system args whether we are running in pilot mode
PILOTING = core.setPilotModeFromArgs()
# start off with values from experiment settings
_fullScr = True
_winSize = [1920, 1080]
# if in pilot mode, apply overrides according to preferences
if PILOTING:
    # force windowed mode
    if prefs.piloting['forceWindowed']:
        _fullScr = False
        # set window size
        _winSize = prefs.piloting['forcedWindowSize']
    # replace default participant ID
    if prefs.piloting['replaceParticipantID']:
        expInfo['participant'] = 'pilot'

def showExpInfoDlg(expInfo):
    """
    Show participant info dialog.
    Parameters
    ==========
    expInfo : dict
        Information about this experiment.
    
    Returns
    ==========
    dict
        Information about this experiment.
    """
    # show participant info dialog
    dlg = gui.DlgFromDict(
        dictionary=expInfo, sortKeys=False, title=expName, alwaysOnTop=True
    )
    if dlg.OK == False:
        core.quit()  # user pressed cancel
    # return expInfo
    return expInfo


def setupData(expInfo, dataDir=None):
    """
    Make an ExperimentHandler to handle trials and saving.
    
    Parameters
    ==========
    expInfo : dict
        Information about this experiment, created by the `setupExpInfo` function.
    dataDir : Path, str or None
        Folder to save the data to, leave as None to create a folder in the current directory.    
    Returns
    ==========
    psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    """
    # remove dialog-specific syntax from expInfo
    for key, val in expInfo.copy().items():
        newKey, _ = data.utils.parsePipeSyntax(key)
        expInfo[newKey] = expInfo.pop(key)
    
    # data file name stem = absolute path + name; later add .psyexp, .csv, .log, etc
    if dataDir is None:
        dataDir = _thisDir
    filename = u'data' + os.sep + '%s_%s_%s_%s' % (expInfo['participant'], expInfo['group'], expInfo['order'], expInfo['date'])
    # make sure filename is relative to dataDir
    if os.path.isabs(filename):
        dataDir = os.path.commonprefix([dataDir, filename])
        filename = os.path.relpath(filename, dataDir)
    
    # an ExperimentHandler isn't essential but helps with data saving
    thisExp = data.ExperimentHandler(
        name=expName, version=expVersion,
        extraInfo=expInfo, runtimeInfo=None,
        originPath='/Users/yeri/Documents/연구 아이디어/form priming/psychopy_150ms exp/form_priming_builder_fixed_SOA150_lastrun.py',
        savePickle=True, saveWideText=True,
        dataFileName=dataDir + os.sep + filename, sortColumns='time'
    )
    # store pilot mode in data file
    thisExp.addData('piloting', PILOTING, priority=priority.LOW)
    thisExp.setPriority('thisRow.t', priority.CRITICAL)
    thisExp.setPriority('expName', priority.LOW)
    # return experiment handler
    return thisExp


def setupLogging(filename):
    """
    Setup a log file and tell it what level to log at.
    
    Parameters
    ==========
    filename : str or pathlib.Path
        Filename to save log file and data files as, doesn't need an extension.
    
    Returns
    ==========
    psychopy.logging.LogFile
        Text stream to receive inputs from the logging system.
    """
    # set how much information should be printed to the console / app
    if PILOTING:
        logging.console.setLevel(
            prefs.piloting['pilotConsoleLoggingLevel']
        )
    else:
        logging.console.setLevel('warning')
    # save a log file for detail verbose info
    logFile = logging.LogFile(filename+'.log')
    if PILOTING:
        logFile.setLevel(
            prefs.piloting['pilotLoggingLevel']
        )
    else:
        logFile.setLevel(
            logging.getLevel('warning')
        )
    
    return logFile


def setupWindow(expInfo=None, win=None):
    """
    Setup the Window
    
    Parameters
    ==========
    expInfo : dict
        Information about this experiment, created by the `setupExpInfo` function.
    win : psychopy.visual.Window
        Window to setup - leave as None to create a new window.
    
    Returns
    ==========
    psychopy.visual.Window
        Window in which to run this experiment.
    """
    if PILOTING:
        logging.debug('Fullscreen settings ignored as running in pilot mode.')
    
    if win is None:
        # if not given a window to setup, make one
        win = visual.Window(
            size=_winSize, fullscr=_fullScr, screen=0,
            winType='pyglet', allowGUI=False, allowStencil=False,
            monitor='testMonitor', color='black', colorSpace='rgb',
            backgroundImage='', backgroundFit='none',
            blendMode='avg', useFBO=True,
            units='height',
            checkTiming=False  # we're going to do this ourselves in a moment
        )
    else:
        # if we have a window, just set the attributes which are safe to set
        win.color = 'black'
        win.colorSpace = 'rgb'
        win.backgroundImage = ''
        win.backgroundFit = 'none'
        win.units = 'height'
    if expInfo is not None:
        # get/measure frame rate if not already in expInfo
        if win._monitorFrameRate is None:
            win._monitorFrameRate = win.getActualFrameRate(infoMsg='Attempting to measure frame rate of screen, please wait...')
        expInfo['frameRate'] = win._monitorFrameRate
    win.hideMessage()
    if PILOTING:
        # show a visual indicator if we're in piloting mode
        if prefs.piloting['showPilotingIndicator']:
            win.showPilotingIndicator()
        # always show the mouse in piloting mode
        if prefs.piloting['forceMouseVisible']:
            win.mouseVisible = True
    
    return win


def setupDevices(expInfo, thisExp, win):
    """
    Setup whatever devices are available (mouse, keyboard, speaker, eyetracker, etc.) and add them to 
    the device manager (deviceManager)
    
    Parameters
    ==========
    expInfo : dict
        Information about this experiment, created by the `setupExpInfo` function.
    thisExp : psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    win : psychopy.visual.Window
        Window in which to run this experiment.
    Returns
    ==========
    bool
        True if completed successfully.
    """
    # --- Setup input devices ---
    ioConfig = {}
    ioSession = ioServer = eyetracker = None
    
    # store ioServer object in the device manager
    deviceManager.ioServer = ioServer
    
    # create a default keyboard (e.g. to check for escape)
    if deviceManager.getDevice('defaultKeyboard') is None:
        deviceManager.addDevice(
            deviceClass='keyboard', deviceName='defaultKeyboard', backend='ptb'
        )
    # return True if completed successfully
    return True

def pauseExperiment(thisExp, win=None, timers=[], currentRoutine=None):
    """
    Pause this experiment, preventing the flow from advancing to the next routine until resumed.
    
    Parameters
    ==========
    thisExp : psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    win : psychopy.visual.Window
        Window for this experiment.
    timers : list, tuple
        List of timers to reset once pausing is finished.
    currentRoutine : psychopy.data.Routine
        Current Routine we are in at time of pausing, if any. This object tells PsychoPy what Components to pause/play/dispatch.
    """
    # if we are not paused, do nothing
    if thisExp.status != PAUSED:
        return
    
    # start a timer to figure out how long we're paused for
    pauseTimer = core.Clock()
    # pause any playback components
    if currentRoutine is not None:
        for comp in currentRoutine.getPlaybackComponents():
            comp.pause()
    # make sure we have a keyboard
    defaultKeyboard = deviceManager.getDevice('defaultKeyboard')
    if defaultKeyboard is None:
        defaultKeyboard = deviceManager.addKeyboard(
            deviceClass='keyboard',
            deviceName='defaultKeyboard',
            backend='PsychToolbox',
        )
    # run a while loop while we wait to unpause
    while thisExp.status == PAUSED:
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=['escape']):
            endExperiment(thisExp, win=win)
        # dispatch messages on response components
        if currentRoutine is not None:
            for comp in currentRoutine.getDispatchComponents():
                comp.device.dispatchMessages()
        # sleep 1ms so other threads can execute
        clock.time.sleep(0.001)
    # if stop was requested while paused, quit
    if thisExp.status == FINISHED:
        endExperiment(thisExp, win=win)
    # resume any playback components
    if currentRoutine is not None:
        for comp in currentRoutine.getPlaybackComponents():
            comp.play()
    # reset any timers
    for timer in timers:
        timer.addTime(-pauseTimer.getTime())


def run(expInfo, thisExp, win, globalClock=None, thisSession=None):
    """
    Run the experiment flow.
    
    Parameters
    ==========
    expInfo : dict
        Information about this experiment, created by the `setupExpInfo` function.
    thisExp : psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    psychopy.visual.Window
        Window in which to run this experiment.
    globalClock : psychopy.core.clock.Clock or None
        Clock to get global time from - supply None to make a new one.
    thisSession : psychopy.session.Session or None
        Handle of the Session object this experiment is being run from, if any.
    """
    # mark experiment as started
    thisExp.status = STARTED
    # update experiment info
    expInfo['date'] = data.getDateStr()
    expInfo['expName'] = expName
    expInfo['expVersion'] = expVersion
    expInfo['psychopyVersion'] = psychopyVersion
    # make sure window is set to foreground to prevent losing focus
    win.winHandle.activate()
    # make sure variables created by exec are available globally
    exec = environmenttools.setExecEnvironment(globals())
    # get device handles from dict of input devices
    ioServer = deviceManager.ioServer
    # get/create a default keyboard (e.g. to check for escape)
    defaultKeyboard = deviceManager.getDevice('defaultKeyboard')
    if defaultKeyboard is None:
        deviceManager.addDevice(
            deviceClass='keyboard', deviceName='defaultKeyboard', backend='PsychToolbox'
        )
    eyetracker = deviceManager.getDevice('eyetracker')
    # make sure we're running in the directory for this experiment
    os.chdir(_thisDir)
    # get filename from ExperimentHandler for convenience
    filename = thisExp.dataFileName
    frameTolerance = 0.001  # how close to onset before 'same' frame
    endExpNow = False  # flag for 'escape' or other condition => quit the exp
    # get frame duration from frame rate in expInfo
    if 'frameRate' in expInfo and expInfo['frameRate'] is not None:
        frameDur = 1.0 / round(expInfo['frameRate'])
    else:
        frameDur = 1.0 / 60.0  # could not measure, so guess
    
    # Start Code - component code to be run after the window creation
    
    # --- Initialize components for Routine "initialize" ---
    # Run 'Begin Experiment' code from initialize_code
    # --- timing: prime 50 ms + blank 100 ms (SOA 150 ms), frame-based ---
    # PROVISIONAL refresh-rate window (to be fixed by the researcher); outside it -> assume 60 Hz
    FR_MIN, FR_MAX = 55, 65
    frameRateRaw = expInfo['frameRate']
    frameRateOK = bool(frameRateRaw) and (FR_MIN <= frameRateRaw <= FR_MAX)
    frameRateUsed = frameRateRaw if frameRateOK else 60
    primeFrames = int(round(0.05 * frameRateUsed))   # 50 ms  (3 frames at 60 Hz)
    blankFrames = int(round(0.10 * frameRateUsed))   # 100 ms (6 frames at 60 Hz)
    targetOnset = 1.0 + (primeFrames + blankFrames) / float(frameRateUsed)   # prime onset = 1.0 s
    thisExp.addData('frameRateRaw', frameRateRaw)
    thisExp.addData('frameRateOK', frameRateOK)
    thisExp.addData('primeFrames', primeFrames)
    thisExp.addData('blankFrames', blankFrames)
    mainFile = f"group_{expInfo['group']}_{expInfo['order']}_constrained.csv"
    thisExp.addData('selected_conditions_file', mainFile)
    
    # --- Initialize components for Routine "instruction_1" ---
    instruction_1_text = visual.TextStim(win=win, name='instruction_1_text',
        text='안녕하세요.\n실험에 참여해주셔서 감사합니다.\n\n본 실험은 어휘 판단 과제입니다.\n화면에 단어 또는 단어가 아닌 글자열이 나타납니다.\n단어라고 생각이 되시면 J, 단어가 아니라고 판단되시면 F키를 눌러주세요.\ne.g. 책상 → J, 궵셉 → F\n\n스페이스바를 누르면 다음 화면으로 넘어갑니다.',
        font='AppleGothic',
        units='height', pos=(0, 0), draggable=False, height=0.046, wrapWidth=1.55, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=0.0);
    instruction_1_resp = keyboard.Keyboard(deviceName='defaultKeyboard')
    
    # --- Initialize components for Routine "instruction_2" ---
    instruction_2_text = visual.TextStim(win=win, name='instruction_2_text',
        text='매 시행마다 정확도와 응답 속도가 기록되고 있습니다.\n가능한 한 빠르고 정확히 응답해주십시오.\n정답률이 70%가 넘은 경우에 참여비를 드리고 있습니다.\n\n스페이스바를 누르면 연습시행이 시작됩니다.',
        font='AppleGothic',
        units='height', pos=(0, 0), draggable=False, height=0.046, wrapWidth=1.55, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=0.0);
    instruction_2_resp = keyboard.Keyboard(deviceName='defaultKeyboard')
    
    # --- Initialize components for Routine "practice_trial" ---
    practice_trial_fixation = visual.TextStim(win=win, name='practice_trial_fixation',
        text='+',
        font='AppleGothic',
        units='height', pos=(0, 0), draggable=False, height=0.06, wrapWidth=1.55, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-1.0);
    practice_trial_mask = visual.TextStim(win=win, name='practice_trial_mask',
        text='####',
        font='AppleGothic',
        units='height', pos=(0, 0), draggable=False, height=0.06, wrapWidth=1.55, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-2.0);
    practice_trial_prime = visual.TextStim(win=win, name='practice_trial_prime',
        text='',
        font='AppleGothic',
        units='height', pos=(0, 0), draggable=False, height=0.06, wrapWidth=1.55, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-3.0);
    practice_trial_target = visual.TextStim(win=win, name='practice_trial_target',
        text='',
        font='AppleGothic',
        units='height', pos=(0, 0), draggable=False, height=0.06, wrapWidth=1.55, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-4.0);
    practice_resp = keyboard.Keyboard(deviceName='defaultKeyboard')
    
    # --- Initialize components for Routine "practice_feedback" ---
    practice_feedback_text = visual.TextStim(win=win, name='practice_feedback_text',
        text='',
        font='AppleGothic',
        units='height', pos=(0, 0), draggable=False, height=0.06, wrapWidth=1.55, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-1.0);
    
    # --- Initialize components for Routine "practice_iti" ---
    practice_iti_blank = visual.TextStim(win=win, name='practice_iti_blank',
        text=None,
        font='AppleGothic',
        units='height', pos=(0, 0), draggable=False, height=0.055, wrapWidth=1.55, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-1.0);
    
    # --- Initialize components for Routine "practice_choice" ---
    practice_choice_text = visual.TextStim(win=win, name='practice_choice_text',
        text='연습이 끝났습니다.\n\n연습을 다시 하려면 백스페이스를 누르십시오.\n본 실험을 시작하려면 스페이스바를 누르십시오.',
        font='AppleGothic',
        units='height', pos=(0, 0), draggable=False, height=0.052, wrapWidth=1.55, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=0.0);
    practice_choice_resp = keyboard.Keyboard(deviceName='defaultKeyboard')
    
    # --- Initialize components for Routine "main_ready" ---
    main_ready_text = visual.TextStim(win=win, name='main_ready_text',
        text='이제 본 실험을 시작합니다.\n\n단어이면 J, 단어가 아니면 F키를 누르십시오.\n준비되었으면 스페이스바를 눌러 시작하십시오.',
        font='AppleGothic',
        units='height', pos=(0, 0), draggable=False, height=0.052, wrapWidth=1.55, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=0.0);
    main_ready_resp = keyboard.Keyboard(deviceName='defaultKeyboard')
    
    # --- Initialize components for Routine "main_trial" ---
    main_trial_fixation = visual.TextStim(win=win, name='main_trial_fixation',
        text='+',
        font='AppleGothic',
        units='height', pos=(0, 0), draggable=False, height=0.06, wrapWidth=1.55, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-1.0);
    main_trial_mask = visual.TextStim(win=win, name='main_trial_mask',
        text='####',
        font='AppleGothic',
        units='height', pos=(0, 0), draggable=False, height=0.06, wrapWidth=1.55, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-2.0);
    main_trial_prime = visual.TextStim(win=win, name='main_trial_prime',
        text='',
        font='AppleGothic',
        units='height', pos=(0, 0), draggable=False, height=0.06, wrapWidth=1.55, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-3.0);
    main_trial_target = visual.TextStim(win=win, name='main_trial_target',
        text='',
        font='AppleGothic',
        units='height', pos=(0, 0), draggable=False, height=0.06, wrapWidth=1.55, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-4.0);
    main_resp = keyboard.Keyboard(deviceName='defaultKeyboard')
    
    # --- Initialize components for Routine "main_iti" ---
    main_iti_blank = visual.TextStim(win=win, name='main_iti_blank',
        text=None,
        font='AppleGothic',
        units='height', pos=(0, 0), draggable=False, height=0.055, wrapWidth=1.55, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-1.0);
    
    # --- Initialize components for Routine "break_1_timer" ---
    break_1_display = visual.TextStim(win=win, name='break_1_display',
        text='지금부터 1분간 쉬는시간입니다.',
        font='AppleGothic',
        units='height', pos=(0, 0), draggable=False, height=0.055, wrapWidth=1.55, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=0.0);
    
    # --- Initialize components for Routine "break_1_ready" ---
    break_1_ready_text = visual.TextStim(win=win, name='break_1_ready_text',
        text='실험을 시작할 준비가 되셨으면,\n스페이스바를 눌러 계속하십시오.',
        font='AppleGothic',
        units='height', pos=(0, 0), draggable=False, height=0.055, wrapWidth=1.55, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=0.0);
    break_1_ready_resp = keyboard.Keyboard(deviceName='defaultKeyboard')
    
    # --- Initialize components for Routine "main_trial" ---
    main_trial_fixation = visual.TextStim(win=win, name='main_trial_fixation',
        text='+',
        font='AppleGothic',
        units='height', pos=(0, 0), draggable=False, height=0.06, wrapWidth=1.55, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-1.0);
    main_trial_mask = visual.TextStim(win=win, name='main_trial_mask',
        text='####',
        font='AppleGothic',
        units='height', pos=(0, 0), draggable=False, height=0.06, wrapWidth=1.55, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-2.0);
    main_trial_prime = visual.TextStim(win=win, name='main_trial_prime',
        text='',
        font='AppleGothic',
        units='height', pos=(0, 0), draggable=False, height=0.06, wrapWidth=1.55, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-3.0);
    main_trial_target = visual.TextStim(win=win, name='main_trial_target',
        text='',
        font='AppleGothic',
        units='height', pos=(0, 0), draggable=False, height=0.06, wrapWidth=1.55, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-4.0);
    main_resp = keyboard.Keyboard(deviceName='defaultKeyboard')
    
    # --- Initialize components for Routine "main_iti" ---
    main_iti_blank = visual.TextStim(win=win, name='main_iti_blank',
        text=None,
        font='AppleGothic',
        units='height', pos=(0, 0), draggable=False, height=0.055, wrapWidth=1.55, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-1.0);
    
    # --- Initialize components for Routine "break_2_timer" ---
    break_2_display = visual.TextStim(win=win, name='break_2_display',
        text='지금부터 1분간 쉬는시간입니다.',
        font='AppleGothic',
        units='height', pos=(0, 0), draggable=False, height=0.055, wrapWidth=1.55, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=0.0);
    
    # --- Initialize components for Routine "break_2_ready" ---
    break_2_ready_text = visual.TextStim(win=win, name='break_2_ready_text',
        text='실험을 시작할 준비가 되셨으면,\n스페이스바를 눌러 계속하십시오.',
        font='AppleGothic',
        units='height', pos=(0, 0), draggable=False, height=0.055, wrapWidth=1.55, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=0.0);
    break_2_ready_resp = keyboard.Keyboard(deviceName='defaultKeyboard')
    
    # --- Initialize components for Routine "main_trial" ---
    main_trial_fixation = visual.TextStim(win=win, name='main_trial_fixation',
        text='+',
        font='AppleGothic',
        units='height', pos=(0, 0), draggable=False, height=0.06, wrapWidth=1.55, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-1.0);
    main_trial_mask = visual.TextStim(win=win, name='main_trial_mask',
        text='####',
        font='AppleGothic',
        units='height', pos=(0, 0), draggable=False, height=0.06, wrapWidth=1.55, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-2.0);
    main_trial_prime = visual.TextStim(win=win, name='main_trial_prime',
        text='',
        font='AppleGothic',
        units='height', pos=(0, 0), draggable=False, height=0.06, wrapWidth=1.55, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-3.0);
    main_trial_target = visual.TextStim(win=win, name='main_trial_target',
        text='',
        font='AppleGothic',
        units='height', pos=(0, 0), draggable=False, height=0.06, wrapWidth=1.55, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-4.0);
    main_resp = keyboard.Keyboard(deviceName='defaultKeyboard')
    
    # --- Initialize components for Routine "main_iti" ---
    main_iti_blank = visual.TextStim(win=win, name='main_iti_blank',
        text=None,
        font='AppleGothic',
        units='height', pos=(0, 0), draggable=False, height=0.055, wrapWidth=1.55, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-1.0);
    
    # --- Initialize components for Routine "break_3_timer" ---
    break_3_display = visual.TextStim(win=win, name='break_3_display',
        text='지금부터 1분간 쉬는시간입니다.',
        font='AppleGothic',
        units='height', pos=(0, 0), draggable=False, height=0.055, wrapWidth=1.55, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=0.0);
    
    # --- Initialize components for Routine "break_3_ready" ---
    break_3_ready_text = visual.TextStim(win=win, name='break_3_ready_text',
        text='실험을 시작할 준비가 되셨으면,\n스페이스바를 눌러 계속하십시오.',
        font='AppleGothic',
        units='height', pos=(0, 0), draggable=False, height=0.055, wrapWidth=1.55, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=0.0);
    break_3_ready_resp = keyboard.Keyboard(deviceName='defaultKeyboard')
    
    # --- Initialize components for Routine "main_trial" ---
    main_trial_fixation = visual.TextStim(win=win, name='main_trial_fixation',
        text='+',
        font='AppleGothic',
        units='height', pos=(0, 0), draggable=False, height=0.06, wrapWidth=1.55, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-1.0);
    main_trial_mask = visual.TextStim(win=win, name='main_trial_mask',
        text='####',
        font='AppleGothic',
        units='height', pos=(0, 0), draggable=False, height=0.06, wrapWidth=1.55, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-2.0);
    main_trial_prime = visual.TextStim(win=win, name='main_trial_prime',
        text='',
        font='AppleGothic',
        units='height', pos=(0, 0), draggable=False, height=0.06, wrapWidth=1.55, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-3.0);
    main_trial_target = visual.TextStim(win=win, name='main_trial_target',
        text='',
        font='AppleGothic',
        units='height', pos=(0, 0), draggable=False, height=0.06, wrapWidth=1.55, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-4.0);
    main_resp = keyboard.Keyboard(deviceName='defaultKeyboard')
    
    # --- Initialize components for Routine "main_iti" ---
    main_iti_blank = visual.TextStim(win=win, name='main_iti_blank',
        text=None,
        font='AppleGothic',
        units='height', pos=(0, 0), draggable=False, height=0.055, wrapWidth=1.55, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-1.0);
    
    # --- Initialize components for Routine "finish" ---
    finish_text = visual.TextStim(win=win, name='finish_text',
        text='실험이 종료되었습니다.\n참여해주셔서 감사합니다.\n\n스페이스바를 눌러 종료하십시오.',
        font='AppleGothic',
        units='height', pos=(0, 0), draggable=False, height=0.058, wrapWidth=1.55, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=0.0);
    finish_resp = keyboard.Keyboard(deviceName='defaultKeyboard')
    
    # create some handy timers
    
    # global clock to track the time since experiment started
    if globalClock is None:
        # create a clock if not given one
        globalClock = core.Clock()
    if isinstance(globalClock, str):
        # if given a string, make a clock accoridng to it
        if globalClock == 'float':
            # get timestamps as a simple value
            globalClock = core.Clock(format='float')
        elif globalClock == 'iso':
            # get timestamps in ISO format
            globalClock = core.Clock(format='%Y-%m-%d_%H:%M:%S.%f%z')
        else:
            # get timestamps in a custom format
            globalClock = core.Clock(format=globalClock)
    if ioServer is not None:
        ioServer.syncClock(globalClock)
    logging.setDefaultClock(globalClock)
    if eyetracker is not None:
        eyetracker.enableEventReporting()
    # routine timer to track time remaining of each (possibly non-slip) routine
    routineTimer = core.Clock()
    win.flip()  # flip window to reset last flip timer
    # store the exact time the global clock started
    expInfo['expStart'] = data.getDateStr(
        format='%Y-%m-%d %Hh%M.%S.%f %z', fractionalSecondDigits=6
    )
    
    # --- Prepare to start Routine "initialize" ---
    # create an object to store info about Routine initialize
    initialize = data.Routine(
        name='initialize',
        components=[],
    )
    initialize.status = NOT_STARTED
    continueRoutine = True
    # update component parameters for each repeat
    # store start times for initialize
    initialize.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
    initialize.tStart = globalClock.getTime(format='float')
    initialize.status = STARTED
    thisExp.addData('initialize.started', initialize.tStart)
    initialize.maxDuration = None
    # keep track of which components have finished
    initializeComponents = initialize.components
    for thisComponent in initialize.components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "initialize" ---
    thisExp.currentRoutine = initialize
    initialize.forceEnded = routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, win=win)
            return
        # pause experiment here if requested
        if thisExp.status == PAUSED:
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[routineTimer, globalClock], 
                currentRoutine=initialize,
            )
            # skip the frame we paused on
            continue
        
        # has a Component requested the Routine to end?
        if not continueRoutine:
            initialize.forceEnded = routineForceEnded = True
        # has the Routine been forcibly ended?
        if initialize.forceEnded or routineForceEnded:
            break
        # has every Component finished?
        continueRoutine = False
        for thisComponent in initialize.components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "initialize" ---
    for thisComponent in initialize.components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # store stop times for initialize
    initialize.tStop = globalClock.getTime(format='float')
    initialize.tStopRefresh = tThisFlipGlobal
    thisExp.addData('initialize.stopped', initialize.tStop)
    thisExp.nextEntry()
    # the Routine "initialize" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # --- Prepare to start Routine "instruction_1" ---
    # create an object to store info about Routine instruction_1
    instruction_1 = data.Routine(
        name='instruction_1',
        components=[instruction_1_text, instruction_1_resp],
    )
    instruction_1.status = NOT_STARTED
    continueRoutine = True
    # update component parameters for each repeat
    # create starting attributes for instruction_1_resp
    instruction_1_resp.keys = []
    instruction_1_resp.rt = []
    _instruction_1_resp_allKeys = []
    # store start times for instruction_1
    instruction_1.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
    instruction_1.tStart = globalClock.getTime(format='float')
    instruction_1.status = STARTED
    thisExp.addData('instruction_1.started', instruction_1.tStart)
    instruction_1.maxDuration = None
    # keep track of which components have finished
    instruction_1Components = instruction_1.components
    for thisComponent in instruction_1.components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "instruction_1" ---
    thisExp.currentRoutine = instruction_1
    instruction_1.forceEnded = routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *instruction_1_text* updates
        
        # if instruction_1_text is starting this frame...
        if instruction_1_text.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
            # keep track of start time/frame for later
            instruction_1_text.frameNStart = frameN  # exact frame index
            instruction_1_text.tStart = t  # local t and not account for scr refresh
            instruction_1_text.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(instruction_1_text, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'instruction_1_text.started')
            # update status
            instruction_1_text.status = STARTED
            instruction_1_text.setAutoDraw(True)
        
        # if instruction_1_text is active this frame...
        if instruction_1_text.status == STARTED:
            # update params
            pass
        
        # *instruction_1_resp* updates
        waitOnFlip = False
        
        # if instruction_1_resp is starting this frame...
        if instruction_1_resp.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
            # keep track of start time/frame for later
            instruction_1_resp.frameNStart = frameN  # exact frame index
            instruction_1_resp.tStart = t  # local t and not account for scr refresh
            instruction_1_resp.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(instruction_1_resp, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'instruction_1_resp.started')
            # update status
            instruction_1_resp.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(instruction_1_resp.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(instruction_1_resp.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if instruction_1_resp.status == STARTED and not waitOnFlip:
            theseKeys = instruction_1_resp.getKeys(keyList=['space'], ignoreKeys=["escape"], waitRelease=False)
            _instruction_1_resp_allKeys.extend(theseKeys)
            if len(_instruction_1_resp_allKeys):
                instruction_1_resp.keys = _instruction_1_resp_allKeys[-1].name  # just the last key pressed
                instruction_1_resp.rt = _instruction_1_resp_allKeys[-1].rt
                instruction_1_resp.duration = _instruction_1_resp_allKeys[-1].duration
                # a response ends the routine
                continueRoutine = False
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, win=win)
            return
        # pause experiment here if requested
        if thisExp.status == PAUSED:
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[routineTimer, globalClock], 
                currentRoutine=instruction_1,
            )
            # skip the frame we paused on
            continue
        
        # has a Component requested the Routine to end?
        if not continueRoutine:
            instruction_1.forceEnded = routineForceEnded = True
        # has the Routine been forcibly ended?
        if instruction_1.forceEnded or routineForceEnded:
            break
        # has every Component finished?
        continueRoutine = False
        for thisComponent in instruction_1.components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "instruction_1" ---
    for thisComponent in instruction_1.components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # store stop times for instruction_1
    instruction_1.tStop = globalClock.getTime(format='float')
    instruction_1.tStopRefresh = tThisFlipGlobal
    thisExp.addData('instruction_1.stopped', instruction_1.tStop)
    # check responses
    if instruction_1_resp.keys in ['', [], None]:  # No response was made
        instruction_1_resp.keys = None
    thisExp.addData('instruction_1_resp.keys',instruction_1_resp.keys)
    if instruction_1_resp.keys != None:  # we had a response
        thisExp.addData('instruction_1_resp.rt', instruction_1_resp.rt)
        thisExp.addData('instruction_1_resp.duration', instruction_1_resp.duration)
    thisExp.nextEntry()
    # the Routine "instruction_1" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # --- Prepare to start Routine "instruction_2" ---
    # create an object to store info about Routine instruction_2
    instruction_2 = data.Routine(
        name='instruction_2',
        components=[instruction_2_text, instruction_2_resp],
    )
    instruction_2.status = NOT_STARTED
    continueRoutine = True
    # update component parameters for each repeat
    # create starting attributes for instruction_2_resp
    instruction_2_resp.keys = []
    instruction_2_resp.rt = []
    _instruction_2_resp_allKeys = []
    # store start times for instruction_2
    instruction_2.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
    instruction_2.tStart = globalClock.getTime(format='float')
    instruction_2.status = STARTED
    thisExp.addData('instruction_2.started', instruction_2.tStart)
    instruction_2.maxDuration = None
    # keep track of which components have finished
    instruction_2Components = instruction_2.components
    for thisComponent in instruction_2.components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "instruction_2" ---
    thisExp.currentRoutine = instruction_2
    instruction_2.forceEnded = routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *instruction_2_text* updates
        
        # if instruction_2_text is starting this frame...
        if instruction_2_text.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
            # keep track of start time/frame for later
            instruction_2_text.frameNStart = frameN  # exact frame index
            instruction_2_text.tStart = t  # local t and not account for scr refresh
            instruction_2_text.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(instruction_2_text, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'instruction_2_text.started')
            # update status
            instruction_2_text.status = STARTED
            instruction_2_text.setAutoDraw(True)
        
        # if instruction_2_text is active this frame...
        if instruction_2_text.status == STARTED:
            # update params
            pass
        
        # *instruction_2_resp* updates
        waitOnFlip = False
        
        # if instruction_2_resp is starting this frame...
        if instruction_2_resp.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
            # keep track of start time/frame for later
            instruction_2_resp.frameNStart = frameN  # exact frame index
            instruction_2_resp.tStart = t  # local t and not account for scr refresh
            instruction_2_resp.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(instruction_2_resp, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'instruction_2_resp.started')
            # update status
            instruction_2_resp.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(instruction_2_resp.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(instruction_2_resp.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if instruction_2_resp.status == STARTED and not waitOnFlip:
            theseKeys = instruction_2_resp.getKeys(keyList=['space'], ignoreKeys=["escape"], waitRelease=False)
            _instruction_2_resp_allKeys.extend(theseKeys)
            if len(_instruction_2_resp_allKeys):
                instruction_2_resp.keys = _instruction_2_resp_allKeys[-1].name  # just the last key pressed
                instruction_2_resp.rt = _instruction_2_resp_allKeys[-1].rt
                instruction_2_resp.duration = _instruction_2_resp_allKeys[-1].duration
                # a response ends the routine
                continueRoutine = False
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, win=win)
            return
        # pause experiment here if requested
        if thisExp.status == PAUSED:
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[routineTimer, globalClock], 
                currentRoutine=instruction_2,
            )
            # skip the frame we paused on
            continue
        
        # has a Component requested the Routine to end?
        if not continueRoutine:
            instruction_2.forceEnded = routineForceEnded = True
        # has the Routine been forcibly ended?
        if instruction_2.forceEnded or routineForceEnded:
            break
        # has every Component finished?
        continueRoutine = False
        for thisComponent in instruction_2.components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "instruction_2" ---
    for thisComponent in instruction_2.components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # store stop times for instruction_2
    instruction_2.tStop = globalClock.getTime(format='float')
    instruction_2.tStopRefresh = tThisFlipGlobal
    thisExp.addData('instruction_2.stopped', instruction_2.tStop)
    # check responses
    if instruction_2_resp.keys in ['', [], None]:  # No response was made
        instruction_2_resp.keys = None
    thisExp.addData('instruction_2_resp.keys',instruction_2_resp.keys)
    if instruction_2_resp.keys != None:  # we had a response
        thisExp.addData('instruction_2_resp.rt', instruction_2_resp.rt)
        thisExp.addData('instruction_2_resp.duration', instruction_2_resp.duration)
    thisExp.nextEntry()
    # the Routine "instruction_2" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # set up handler to look after randomisation of conditions etc
    practice_repeat = data.TrialHandler2(
        name='practice_repeat',
        nReps=99.0, 
        method='sequential', 
        extraInfo=expInfo, 
        originPath=-1, 
        trialList=[None], 
        seed=None, 
        isTrials=False, 
    )
    thisExp.addLoop(practice_repeat)  # add the loop to the experiment
    thisPractice_repeat = practice_repeat.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisPractice_repeat.rgb)
    if thisPractice_repeat != None:
        for paramName in thisPractice_repeat:
            globals()[paramName] = thisPractice_repeat[paramName]
    
    for thisPractice_repeat in practice_repeat:
        practice_repeat.status = STARTED
        if hasattr(thisPractice_repeat, 'status'):
            thisPractice_repeat.status = STARTED
        currentLoop = practice_repeat
        thisExp.timestampOnFlip(win, 'thisRow.t', format=globalClock.format)
        # abbreviate parameter names if possible (e.g. rgb = thisPractice_repeat.rgb)
        if thisPractice_repeat != None:
            for paramName in thisPractice_repeat:
                globals()[paramName] = thisPractice_repeat[paramName]
        
        # set up handler to look after randomisation of conditions etc
        practice_trials = data.TrialHandler2(
            name='practice_trials',
            nReps=1.0, 
            method='sequential', 
            extraInfo=expInfo, 
            originPath=-1, 
            trialList=data.importConditions('practice_trials.csv'), 
            seed=None, 
            isTrials=True, 
        )
        thisExp.addLoop(practice_trials)  # add the loop to the experiment
        thisPractice_trial = practice_trials.trialList[0]  # so we can initialise stimuli with some values
        # abbreviate parameter names if possible (e.g. rgb = thisPractice_trial.rgb)
        if thisPractice_trial != None:
            for paramName in thisPractice_trial:
                globals()[paramName] = thisPractice_trial[paramName]
        if thisSession is not None:
            # if running in a Session with a Liaison client, send data up to now
            thisSession.sendExperimentData()
        
        for thisPractice_trial in practice_trials:
            practice_trials.status = STARTED
            if hasattr(thisPractice_trial, 'status'):
                thisPractice_trial.status = STARTED
            currentLoop = practice_trials
            thisExp.timestampOnFlip(win, 'thisRow.t', format=globalClock.format)
            if thisSession is not None:
                # if running in a Session with a Liaison client, send data up to now
                thisSession.sendExperimentData()
            # abbreviate parameter names if possible (e.g. rgb = thisPractice_trial.rgb)
            if thisPractice_trial != None:
                for paramName in thisPractice_trial:
                    globals()[paramName] = thisPractice_trial[paramName]
            
            # --- Prepare to start Routine "practice_trial" ---
            # create an object to store info about Routine practice_trial
            practice_trial = data.Routine(
                name='practice_trial',
                components=[practice_trial_fixation, practice_trial_mask, practice_trial_prime, practice_trial_target, practice_resp],
            )
            practice_trial.status = NOT_STARTED
            continueRoutine = True
            # update component parameters for each repeat
            # Run 'Begin Routine' code from practice_trial_key_map
            corrKey = correct_response
            practice_trial_prime.setText(prime_word)
            practice_trial_target.setText(stimulus)
            # create starting attributes for practice_resp
            practice_resp.keys = []
            practice_resp.rt = []
            _practice_resp_allKeys = []
            # store start times for practice_trial
            practice_trial.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
            practice_trial.tStart = globalClock.getTime(format='float')
            practice_trial.status = STARTED
            thisExp.addData('practice_trial.started', practice_trial.tStart)
            practice_trial.maxDuration = None
            # keep track of which components have finished
            practice_trialComponents = practice_trial.components
            for thisComponent in practice_trial.components:
                thisComponent.tStart = None
                thisComponent.tStop = None
                thisComponent.tStartRefresh = None
                thisComponent.tStopRefresh = None
                if hasattr(thisComponent, 'status'):
                    thisComponent.status = NOT_STARTED
            # reset timers
            t = 0
            _timeToFirstFrame = win.getFutureFlipTime(clock="now")
            frameN = -1
            
            # --- Run Routine "practice_trial" ---
            thisExp.currentRoutine = practice_trial
            practice_trial.forceEnded = routineForceEnded = not continueRoutine
            while continueRoutine:
                # if trial has changed, end Routine now
                if hasattr(thisPractice_trial, 'status') and thisPractice_trial.status == STOPPING:
                    continueRoutine = False
                # get current time
                t = routineTimer.getTime()
                tThisFlip = win.getFutureFlipTime(clock=routineTimer)
                tThisFlipGlobal = win.getFutureFlipTime(clock=None)
                frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
                # update/draw components on each frame
                
                # *practice_trial_fixation* updates
                
                # if practice_trial_fixation is starting this frame...
                if practice_trial_fixation.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                    # keep track of start time/frame for later
                    practice_trial_fixation.frameNStart = frameN  # exact frame index
                    practice_trial_fixation.tStart = t  # local t and not account for scr refresh
                    practice_trial_fixation.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(practice_trial_fixation, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'practice_trial_fixation.started')
                    # update status
                    practice_trial_fixation.status = STARTED
                    practice_trial_fixation.setAutoDraw(True)
                
                # if practice_trial_fixation is active this frame...
                if practice_trial_fixation.status == STARTED:
                    # update params
                    pass
                
                # if practice_trial_fixation is stopping this frame...
                if practice_trial_fixation.status == STARTED:
                    # is it time to stop? (based on global clock, using actual start)
                    if tThisFlipGlobal > practice_trial_fixation.tStartRefresh + 0.5-frameTolerance:
                        # keep track of stop time/frame for later
                        practice_trial_fixation.tStop = t  # not accounting for scr refresh
                        practice_trial_fixation.tStopRefresh = tThisFlipGlobal  # on global time
                        practice_trial_fixation.frameNStop = frameN  # exact frame index
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'practice_trial_fixation.stopped')
                        # update status
                        practice_trial_fixation.status = FINISHED
                        practice_trial_fixation.setAutoDraw(False)
                
                # *practice_trial_mask* updates
                
                # if practice_trial_mask is starting this frame...
                if practice_trial_mask.status == NOT_STARTED and tThisFlip >= 0.5-frameTolerance:
                    # keep track of start time/frame for later
                    practice_trial_mask.frameNStart = frameN  # exact frame index
                    practice_trial_mask.tStart = t  # local t and not account for scr refresh
                    practice_trial_mask.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(practice_trial_mask, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'practice_trial_mask.started')
                    # update status
                    practice_trial_mask.status = STARTED
                    practice_trial_mask.setAutoDraw(True)
                
                # if practice_trial_mask is active this frame...
                if practice_trial_mask.status == STARTED:
                    # update params
                    pass
                
                # if practice_trial_mask is stopping this frame...
                if practice_trial_mask.status == STARTED:
                    # is it time to stop? (based on global clock, using actual start)
                    if tThisFlipGlobal > practice_trial_mask.tStartRefresh + 0.5-frameTolerance:
                        # keep track of stop time/frame for later
                        practice_trial_mask.tStop = t  # not accounting for scr refresh
                        practice_trial_mask.tStopRefresh = tThisFlipGlobal  # on global time
                        practice_trial_mask.frameNStop = frameN  # exact frame index
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'practice_trial_mask.stopped')
                        # update status
                        practice_trial_mask.status = FINISHED
                        practice_trial_mask.setAutoDraw(False)
                
                # *practice_trial_prime* updates
                
                # if practice_trial_prime is starting this frame...
                if practice_trial_prime.status == NOT_STARTED and tThisFlip >= 1.0-frameTolerance:
                    # keep track of start time/frame for later
                    practice_trial_prime.frameNStart = frameN  # exact frame index
                    practice_trial_prime.tStart = t  # local t and not account for scr refresh
                    practice_trial_prime.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(practice_trial_prime, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'practice_trial_prime.started')
                    # update status
                    practice_trial_prime.status = STARTED
                    practice_trial_prime.setAutoDraw(True)
                
                # if practice_trial_prime is active this frame...
                if practice_trial_prime.status == STARTED:
                    # update params
                    pass
                
                # if practice_trial_prime is stopping this frame...
                if practice_trial_prime.status == STARTED:
                    if frameN >= (practice_trial_prime.frameNStart + primeFrames):
                        # keep track of stop time/frame for later
                        practice_trial_prime.tStop = t  # not accounting for scr refresh
                        practice_trial_prime.tStopRefresh = tThisFlipGlobal  # on global time
                        practice_trial_prime.frameNStop = frameN  # exact frame index
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'practice_trial_prime.stopped')
                        # update status
                        practice_trial_prime.status = FINISHED
                        practice_trial_prime.setAutoDraw(False)
                
                # *practice_trial_target* updates
                
                # if practice_trial_target is starting this frame...
                if practice_trial_target.status == NOT_STARTED and tThisFlip >= targetOnset-frameTolerance:
                    # keep track of start time/frame for later
                    practice_trial_target.frameNStart = frameN  # exact frame index
                    practice_trial_target.tStart = t  # local t and not account for scr refresh
                    practice_trial_target.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(practice_trial_target, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'practice_trial_target.started')
                    # update status
                    practice_trial_target.status = STARTED
                    practice_trial_target.setAutoDraw(True)
                
                # if practice_trial_target is active this frame...
                if practice_trial_target.status == STARTED:
                    # update params
                    pass
                
                # if practice_trial_target is stopping this frame...
                if practice_trial_target.status == STARTED:
                    # is it time to stop? (based on global clock, using actual start)
                    if tThisFlipGlobal > practice_trial_target.tStartRefresh + 2.0-frameTolerance:
                        # keep track of stop time/frame for later
                        practice_trial_target.tStop = t  # not accounting for scr refresh
                        practice_trial_target.tStopRefresh = tThisFlipGlobal  # on global time
                        practice_trial_target.frameNStop = frameN  # exact frame index
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'practice_trial_target.stopped')
                        # update status
                        practice_trial_target.status = FINISHED
                        practice_trial_target.setAutoDraw(False)
                
                # *practice_resp* updates
                waitOnFlip = False
                
                # if practice_resp is starting this frame...
                if practice_resp.status == NOT_STARTED and tThisFlip >= targetOnset-frameTolerance:
                    # keep track of start time/frame for later
                    practice_resp.frameNStart = frameN  # exact frame index
                    practice_resp.tStart = t  # local t and not account for scr refresh
                    practice_resp.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(practice_resp, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'practice_resp.started')
                    # update status
                    practice_resp.status = STARTED
                    # keyboard checking is just starting
                    waitOnFlip = True
                    win.callOnFlip(practice_resp.clock.reset)  # t=0 on next screen flip
                    win.callOnFlip(practice_resp.clearEvents, eventType='keyboard')  # clear events on next screen flip
                
                # if practice_resp is stopping this frame...
                if practice_resp.status == STARTED:
                    # is it time to stop? (based on global clock, using actual start)
                    if tThisFlipGlobal > practice_resp.tStartRefresh + 2.0-frameTolerance:
                        # keep track of stop time/frame for later
                        practice_resp.tStop = t  # not accounting for scr refresh
                        practice_resp.tStopRefresh = tThisFlipGlobal  # on global time
                        practice_resp.frameNStop = frameN  # exact frame index
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'practice_resp.stopped')
                        # update status
                        practice_resp.status = FINISHED
                        practice_resp.status = FINISHED
                if practice_resp.status == STARTED and not waitOnFlip:
                    theseKeys = practice_resp.getKeys(keyList=['j','f'], ignoreKeys=["escape"], waitRelease=False)
                    _practice_resp_allKeys.extend(theseKeys)
                    if len(_practice_resp_allKeys):
                        practice_resp.keys = _practice_resp_allKeys[-1].name  # just the last key pressed
                        practice_resp.rt = _practice_resp_allKeys[-1].rt
                        practice_resp.duration = _practice_resp_allKeys[-1].duration
                        # was this correct?
                        if (practice_resp.keys == str(corrKey)) or (practice_resp.keys == corrKey):
                            practice_resp.corr = 1
                        else:
                            practice_resp.corr = 0
                        # a response ends the routine
                        continueRoutine = False
                
                # check for quit (typically the Esc key)
                if defaultKeyboard.getKeys(keyList=["escape"]):
                    thisExp.status = FINISHED
                if thisExp.status == FINISHED or endExpNow:
                    endExperiment(thisExp, win=win)
                    return
                # pause experiment here if requested
                if thisExp.status == PAUSED:
                    pauseExperiment(
                        thisExp=thisExp, 
                        win=win, 
                        timers=[routineTimer, globalClock], 
                        currentRoutine=practice_trial,
                    )
                    # skip the frame we paused on
                    continue
                
                # has a Component requested the Routine to end?
                if not continueRoutine:
                    practice_trial.forceEnded = routineForceEnded = True
                # has the Routine been forcibly ended?
                if practice_trial.forceEnded or routineForceEnded:
                    break
                # has every Component finished?
                continueRoutine = False
                for thisComponent in practice_trial.components:
                    if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                        continueRoutine = True
                        break  # at least one component has not yet finished
                
                # refresh the screen
                if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                    win.flip()
            
            # --- Ending Routine "practice_trial" ---
            for thisComponent in practice_trial.components:
                if hasattr(thisComponent, "setAutoDraw"):
                    thisComponent.setAutoDraw(False)
            # store stop times for practice_trial
            practice_trial.tStop = globalClock.getTime(format='float')
            practice_trial.tStopRefresh = tThisFlipGlobal
            thisExp.addData('practice_trial.stopped', practice_trial.tStop)
            # Run 'End Routine' code from practice_trial_key_map
            prime_dur_ms = None
            if getattr(practice_trial_prime, 'tStartRefresh', None) is not None and getattr(practice_trial_prime, 'tStopRefresh', None) is not None:
                prime_dur_ms = (practice_trial_prime.tStopRefresh - practice_trial_prime.tStartRefresh) * 1000
            thisExp.addData('prime_actual_ms', prime_dur_ms)
            soa_actual_ms = None
            if getattr(practice_trial_target, 'tStartRefresh', None) is not None and getattr(practice_trial_prime, 'tStartRefresh', None) is not None:
                soa_actual_ms = (practice_trial_target.tStartRefresh - practice_trial_prime.tStartRefresh) * 1000
            thisExp.addData('soa_actual_ms', soa_actual_ms)
            # check responses
            if practice_resp.keys in ['', [], None]:  # No response was made
                practice_resp.keys = None
                # was no response the correct answer?!
                if str(corrKey).lower() == 'none':
                   practice_resp.corr = 1;  # correct non-response
                else:
                   practice_resp.corr = 0;  # failed to respond (incorrectly)
            # store data for practice_trials (TrialHandler)
            practice_trials.addData('practice_resp.keys',practice_resp.keys)
            practice_trials.addData('practice_resp.corr', practice_resp.corr)
            if practice_resp.keys != None:  # we had a response
                practice_trials.addData('practice_resp.rt', practice_resp.rt)
                practice_trials.addData('practice_resp.duration', practice_resp.duration)
            # the Routine "practice_trial" was not non-slip safe, so reset the non-slip timer
            routineTimer.reset()
            
            # --- Prepare to start Routine "practice_feedback" ---
            # create an object to store info about Routine practice_feedback
            practice_feedback = data.Routine(
                name='practice_feedback',
                components=[practice_feedback_text],
            )
            practice_feedback.status = NOT_STARTED
            continueRoutine = True
            # update component parameters for each repeat
            # Run 'Begin Routine' code from practice_feedback_code
            if practice_resp.keys is None:
                feedbackMessage = '너무 늦게 반응했습니다.'
            elif practice_resp.corr:
                feedbackMessage = '정답입니다.'
            else:
                feedbackMessage = '오답입니다.'
            practice_feedback_text.setText(feedbackMessage)
            # store start times for practice_feedback
            practice_feedback.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
            practice_feedback.tStart = globalClock.getTime(format='float')
            practice_feedback.status = STARTED
            thisExp.addData('practice_feedback.started', practice_feedback.tStart)
            practice_feedback.maxDuration = None
            # keep track of which components have finished
            practice_feedbackComponents = practice_feedback.components
            for thisComponent in practice_feedback.components:
                thisComponent.tStart = None
                thisComponent.tStop = None
                thisComponent.tStartRefresh = None
                thisComponent.tStopRefresh = None
                if hasattr(thisComponent, 'status'):
                    thisComponent.status = NOT_STARTED
            # reset timers
            t = 0
            _timeToFirstFrame = win.getFutureFlipTime(clock="now")
            frameN = -1
            
            # --- Run Routine "practice_feedback" ---
            thisExp.currentRoutine = practice_feedback
            practice_feedback.forceEnded = routineForceEnded = not continueRoutine
            while continueRoutine and routineTimer.getTime() < 0.7:
                # if trial has changed, end Routine now
                if hasattr(thisPractice_trial, 'status') and thisPractice_trial.status == STOPPING:
                    continueRoutine = False
                # get current time
                t = routineTimer.getTime()
                tThisFlip = win.getFutureFlipTime(clock=routineTimer)
                tThisFlipGlobal = win.getFutureFlipTime(clock=None)
                frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
                # update/draw components on each frame
                
                # *practice_feedback_text* updates
                
                # if practice_feedback_text is starting this frame...
                if practice_feedback_text.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
                    # keep track of start time/frame for later
                    practice_feedback_text.frameNStart = frameN  # exact frame index
                    practice_feedback_text.tStart = t  # local t and not account for scr refresh
                    practice_feedback_text.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(practice_feedback_text, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'practice_feedback_text.started')
                    # update status
                    practice_feedback_text.status = STARTED
                    practice_feedback_text.setAutoDraw(True)
                
                # if practice_feedback_text is active this frame...
                if practice_feedback_text.status == STARTED:
                    # update params
                    pass
                
                # if practice_feedback_text is stopping this frame...
                if practice_feedback_text.status == STARTED:
                    # is it time to stop? (based on global clock, using actual start)
                    if tThisFlipGlobal > practice_feedback_text.tStartRefresh + 0.7-frameTolerance:
                        # keep track of stop time/frame for later
                        practice_feedback_text.tStop = t  # not accounting for scr refresh
                        practice_feedback_text.tStopRefresh = tThisFlipGlobal  # on global time
                        practice_feedback_text.frameNStop = frameN  # exact frame index
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'practice_feedback_text.stopped')
                        # update status
                        practice_feedback_text.status = FINISHED
                        practice_feedback_text.setAutoDraw(False)
                
                # check for quit (typically the Esc key)
                if defaultKeyboard.getKeys(keyList=["escape"]):
                    thisExp.status = FINISHED
                if thisExp.status == FINISHED or endExpNow:
                    endExperiment(thisExp, win=win)
                    return
                # pause experiment here if requested
                if thisExp.status == PAUSED:
                    pauseExperiment(
                        thisExp=thisExp, 
                        win=win, 
                        timers=[routineTimer, globalClock], 
                        currentRoutine=practice_feedback,
                    )
                    # skip the frame we paused on
                    continue
                
                # has a Component requested the Routine to end?
                if not continueRoutine:
                    practice_feedback.forceEnded = routineForceEnded = True
                # has the Routine been forcibly ended?
                if practice_feedback.forceEnded or routineForceEnded:
                    break
                # has every Component finished?
                continueRoutine = False
                for thisComponent in practice_feedback.components:
                    if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                        continueRoutine = True
                        break  # at least one component has not yet finished
                
                # refresh the screen
                if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                    win.flip()
            
            # --- Ending Routine "practice_feedback" ---
            for thisComponent in practice_feedback.components:
                if hasattr(thisComponent, "setAutoDraw"):
                    thisComponent.setAutoDraw(False)
            # store stop times for practice_feedback
            practice_feedback.tStop = globalClock.getTime(format='float')
            practice_feedback.tStopRefresh = tThisFlipGlobal
            thisExp.addData('practice_feedback.stopped', practice_feedback.tStop)
            # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
            if practice_feedback.maxDurationReached:
                routineTimer.addTime(-practice_feedback.maxDuration)
            elif practice_feedback.forceEnded:
                routineTimer.reset()
            else:
                routineTimer.addTime(-0.700000)
            
            # --- Prepare to start Routine "practice_iti" ---
            # create an object to store info about Routine practice_iti
            practice_iti = data.Routine(
                name='practice_iti',
                components=[practice_iti_blank],
            )
            practice_iti.status = NOT_STARTED
            continueRoutine = True
            # update component parameters for each repeat
            # Run 'Begin Routine' code from practice_iti_randomize
            itiDur = 0.6 + 0.1 * randint(0, 5)
            thisExp.addData('iti_duration', itiDur)
            # store start times for practice_iti
            practice_iti.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
            practice_iti.tStart = globalClock.getTime(format='float')
            practice_iti.status = STARTED
            thisExp.addData('practice_iti.started', practice_iti.tStart)
            practice_iti.maxDuration = None
            # keep track of which components have finished
            practice_itiComponents = practice_iti.components
            for thisComponent in practice_iti.components:
                thisComponent.tStart = None
                thisComponent.tStop = None
                thisComponent.tStartRefresh = None
                thisComponent.tStopRefresh = None
                if hasattr(thisComponent, 'status'):
                    thisComponent.status = NOT_STARTED
            # reset timers
            t = 0
            _timeToFirstFrame = win.getFutureFlipTime(clock="now")
            frameN = -1
            
            # --- Run Routine "practice_iti" ---
            thisExp.currentRoutine = practice_iti
            practice_iti.forceEnded = routineForceEnded = not continueRoutine
            while continueRoutine:
                # if trial has changed, end Routine now
                if hasattr(thisPractice_trial, 'status') and thisPractice_trial.status == STOPPING:
                    continueRoutine = False
                # get current time
                t = routineTimer.getTime()
                tThisFlip = win.getFutureFlipTime(clock=routineTimer)
                tThisFlipGlobal = win.getFutureFlipTime(clock=None)
                frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
                # update/draw components on each frame
                
                # *practice_iti_blank* updates
                
                # if practice_iti_blank is starting this frame...
                if practice_iti_blank.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
                    # keep track of start time/frame for later
                    practice_iti_blank.frameNStart = frameN  # exact frame index
                    practice_iti_blank.tStart = t  # local t and not account for scr refresh
                    practice_iti_blank.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(practice_iti_blank, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'practice_iti_blank.started')
                    # update status
                    practice_iti_blank.status = STARTED
                    practice_iti_blank.setAutoDraw(True)
                
                # if practice_iti_blank is active this frame...
                if practice_iti_blank.status == STARTED:
                    # update params
                    pass
                
                # if practice_iti_blank is stopping this frame...
                if practice_iti_blank.status == STARTED:
                    # is it time to stop? (based on global clock, using actual start)
                    if tThisFlipGlobal > practice_iti_blank.tStartRefresh + itiDur-frameTolerance:
                        # keep track of stop time/frame for later
                        practice_iti_blank.tStop = t  # not accounting for scr refresh
                        practice_iti_blank.tStopRefresh = tThisFlipGlobal  # on global time
                        practice_iti_blank.frameNStop = frameN  # exact frame index
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'practice_iti_blank.stopped')
                        # update status
                        practice_iti_blank.status = FINISHED
                        practice_iti_blank.setAutoDraw(False)
                
                # check for quit (typically the Esc key)
                if defaultKeyboard.getKeys(keyList=["escape"]):
                    thisExp.status = FINISHED
                if thisExp.status == FINISHED or endExpNow:
                    endExperiment(thisExp, win=win)
                    return
                # pause experiment here if requested
                if thisExp.status == PAUSED:
                    pauseExperiment(
                        thisExp=thisExp, 
                        win=win, 
                        timers=[routineTimer, globalClock], 
                        currentRoutine=practice_iti,
                    )
                    # skip the frame we paused on
                    continue
                
                # has a Component requested the Routine to end?
                if not continueRoutine:
                    practice_iti.forceEnded = routineForceEnded = True
                # has the Routine been forcibly ended?
                if practice_iti.forceEnded or routineForceEnded:
                    break
                # has every Component finished?
                continueRoutine = False
                for thisComponent in practice_iti.components:
                    if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                        continueRoutine = True
                        break  # at least one component has not yet finished
                
                # refresh the screen
                if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                    win.flip()
            
            # --- Ending Routine "practice_iti" ---
            for thisComponent in practice_iti.components:
                if hasattr(thisComponent, "setAutoDraw"):
                    thisComponent.setAutoDraw(False)
            # store stop times for practice_iti
            practice_iti.tStop = globalClock.getTime(format='float')
            practice_iti.tStopRefresh = tThisFlipGlobal
            thisExp.addData('practice_iti.stopped', practice_iti.tStop)
            # the Routine "practice_iti" was not non-slip safe, so reset the non-slip timer
            routineTimer.reset()
            # mark thisPractice_trial as finished
            if hasattr(thisPractice_trial, 'status'):
                thisPractice_trial.status = FINISHED
            # if awaiting a pause, pause now
            if practice_trials.status == PAUSED:
                thisExp.status = PAUSED
                pauseExperiment(
                    thisExp=thisExp, 
                    win=win, 
                    timers=[globalClock], 
                )
                # once done pausing, restore running status
                practice_trials.status = STARTED
            thisExp.nextEntry()
            
        # completed 1.0 repeats of 'practice_trials'
        practice_trials.status = FINISHED
        
        if thisSession is not None:
            # if running in a Session with a Liaison client, send data up to now
            thisSession.sendExperimentData()
        # get names of stimulus parameters
        if practice_trials.trialList in ([], [None], None):
            params = []
        else:
            params = practice_trials.trialList[0].keys()
        # save data for this loop
        practice_trials.saveAsText(filename + '_practice_trials.csv', delim=',',
            stimOut=params,
            dataOut=['n','all_mean','all_std', 'all_raw'])
        
        # --- Prepare to start Routine "practice_choice" ---
        # create an object to store info about Routine practice_choice
        practice_choice = data.Routine(
            name='practice_choice',
            components=[practice_choice_text, practice_choice_resp],
        )
        practice_choice.status = NOT_STARTED
        continueRoutine = True
        # update component parameters for each repeat
        # create starting attributes for practice_choice_resp
        practice_choice_resp.keys = []
        practice_choice_resp.rt = []
        _practice_choice_resp_allKeys = []
        # store start times for practice_choice
        practice_choice.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
        practice_choice.tStart = globalClock.getTime(format='float')
        practice_choice.status = STARTED
        thisExp.addData('practice_choice.started', practice_choice.tStart)
        practice_choice.maxDuration = None
        # keep track of which components have finished
        practice_choiceComponents = practice_choice.components
        for thisComponent in practice_choice.components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "practice_choice" ---
        thisExp.currentRoutine = practice_choice
        practice_choice.forceEnded = routineForceEnded = not continueRoutine
        while continueRoutine:
            # if trial has changed, end Routine now
            if hasattr(thisPractice_repeat, 'status') and thisPractice_repeat.status == STOPPING:
                continueRoutine = False
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *practice_choice_text* updates
            
            # if practice_choice_text is starting this frame...
            if practice_choice_text.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
                # keep track of start time/frame for later
                practice_choice_text.frameNStart = frameN  # exact frame index
                practice_choice_text.tStart = t  # local t and not account for scr refresh
                practice_choice_text.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(practice_choice_text, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'practice_choice_text.started')
                # update status
                practice_choice_text.status = STARTED
                practice_choice_text.setAutoDraw(True)
            
            # if practice_choice_text is active this frame...
            if practice_choice_text.status == STARTED:
                # update params
                pass
            
            # *practice_choice_resp* updates
            waitOnFlip = False
            
            # if practice_choice_resp is starting this frame...
            if practice_choice_resp.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
                # keep track of start time/frame for later
                practice_choice_resp.frameNStart = frameN  # exact frame index
                practice_choice_resp.tStart = t  # local t and not account for scr refresh
                practice_choice_resp.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(practice_choice_resp, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'practice_choice_resp.started')
                # update status
                practice_choice_resp.status = STARTED
                # keyboard checking is just starting
                waitOnFlip = True
                win.callOnFlip(practice_choice_resp.clock.reset)  # t=0 on next screen flip
                win.callOnFlip(practice_choice_resp.clearEvents, eventType='keyboard')  # clear events on next screen flip
            if practice_choice_resp.status == STARTED and not waitOnFlip:
                theseKeys = practice_choice_resp.getKeys(keyList=['space','backspace'], ignoreKeys=["escape"], waitRelease=False)
                _practice_choice_resp_allKeys.extend(theseKeys)
                if len(_practice_choice_resp_allKeys):
                    practice_choice_resp.keys = _practice_choice_resp_allKeys[-1].name  # just the last key pressed
                    practice_choice_resp.rt = _practice_choice_resp_allKeys[-1].rt
                    practice_choice_resp.duration = _practice_choice_resp_allKeys[-1].duration
                    # a response ends the routine
                    continueRoutine = False
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, win=win)
                return
            # pause experiment here if requested
            if thisExp.status == PAUSED:
                pauseExperiment(
                    thisExp=thisExp, 
                    win=win, 
                    timers=[routineTimer, globalClock], 
                    currentRoutine=practice_choice,
                )
                # skip the frame we paused on
                continue
            
            # has a Component requested the Routine to end?
            if not continueRoutine:
                practice_choice.forceEnded = routineForceEnded = True
            # has the Routine been forcibly ended?
            if practice_choice.forceEnded or routineForceEnded:
                break
            # has every Component finished?
            continueRoutine = False
            for thisComponent in practice_choice.components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "practice_choice" ---
        for thisComponent in practice_choice.components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # store stop times for practice_choice
        practice_choice.tStop = globalClock.getTime(format='float')
        practice_choice.tStopRefresh = tThisFlipGlobal
        thisExp.addData('practice_choice.stopped', practice_choice.tStop)
        # check responses
        if practice_choice_resp.keys in ['', [], None]:  # No response was made
            practice_choice_resp.keys = None
        practice_repeat.addData('practice_choice_resp.keys',practice_choice_resp.keys)
        if practice_choice_resp.keys != None:  # we had a response
            practice_repeat.addData('practice_choice_resp.rt', practice_choice_resp.rt)
            practice_repeat.addData('practice_choice_resp.duration', practice_choice_resp.duration)
        # Run 'End Routine' code from practice_choice_code
        if practice_choice_resp.keys == 'space':
            practice_repeat.finished = True
        # the Routine "practice_choice" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        # mark thisPractice_repeat as finished
        if hasattr(thisPractice_repeat, 'status'):
            thisPractice_repeat.status = FINISHED
        # if awaiting a pause, pause now
        if practice_repeat.status == PAUSED:
            thisExp.status = PAUSED
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[globalClock], 
            )
            # once done pausing, restore running status
            practice_repeat.status = STARTED
    # completed 99.0 repeats of 'practice_repeat'
    practice_repeat.status = FINISHED
    
    
    # --- Prepare to start Routine "main_ready" ---
    # create an object to store info about Routine main_ready
    main_ready = data.Routine(
        name='main_ready',
        components=[main_ready_text, main_ready_resp],
    )
    main_ready.status = NOT_STARTED
    continueRoutine = True
    # update component parameters for each repeat
    # create starting attributes for main_ready_resp
    main_ready_resp.keys = []
    main_ready_resp.rt = []
    _main_ready_resp_allKeys = []
    # store start times for main_ready
    main_ready.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
    main_ready.tStart = globalClock.getTime(format='float')
    main_ready.status = STARTED
    thisExp.addData('main_ready.started', main_ready.tStart)
    main_ready.maxDuration = None
    # keep track of which components have finished
    main_readyComponents = main_ready.components
    for thisComponent in main_ready.components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "main_ready" ---
    thisExp.currentRoutine = main_ready
    main_ready.forceEnded = routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *main_ready_text* updates
        
        # if main_ready_text is starting this frame...
        if main_ready_text.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
            # keep track of start time/frame for later
            main_ready_text.frameNStart = frameN  # exact frame index
            main_ready_text.tStart = t  # local t and not account for scr refresh
            main_ready_text.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(main_ready_text, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'main_ready_text.started')
            # update status
            main_ready_text.status = STARTED
            main_ready_text.setAutoDraw(True)
        
        # if main_ready_text is active this frame...
        if main_ready_text.status == STARTED:
            # update params
            pass
        
        # *main_ready_resp* updates
        waitOnFlip = False
        
        # if main_ready_resp is starting this frame...
        if main_ready_resp.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
            # keep track of start time/frame for later
            main_ready_resp.frameNStart = frameN  # exact frame index
            main_ready_resp.tStart = t  # local t and not account for scr refresh
            main_ready_resp.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(main_ready_resp, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'main_ready_resp.started')
            # update status
            main_ready_resp.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(main_ready_resp.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(main_ready_resp.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if main_ready_resp.status == STARTED and not waitOnFlip:
            theseKeys = main_ready_resp.getKeys(keyList=['space'], ignoreKeys=["escape"], waitRelease=False)
            _main_ready_resp_allKeys.extend(theseKeys)
            if len(_main_ready_resp_allKeys):
                main_ready_resp.keys = _main_ready_resp_allKeys[-1].name  # just the last key pressed
                main_ready_resp.rt = _main_ready_resp_allKeys[-1].rt
                main_ready_resp.duration = _main_ready_resp_allKeys[-1].duration
                # a response ends the routine
                continueRoutine = False
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, win=win)
            return
        # pause experiment here if requested
        if thisExp.status == PAUSED:
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[routineTimer, globalClock], 
                currentRoutine=main_ready,
            )
            # skip the frame we paused on
            continue
        
        # has a Component requested the Routine to end?
        if not continueRoutine:
            main_ready.forceEnded = routineForceEnded = True
        # has the Routine been forcibly ended?
        if main_ready.forceEnded or routineForceEnded:
            break
        # has every Component finished?
        continueRoutine = False
        for thisComponent in main_ready.components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "main_ready" ---
    for thisComponent in main_ready.components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # store stop times for main_ready
    main_ready.tStop = globalClock.getTime(format='float')
    main_ready.tStopRefresh = tThisFlipGlobal
    thisExp.addData('main_ready.stopped', main_ready.tStop)
    # check responses
    if main_ready_resp.keys in ['', [], None]:  # No response was made
        main_ready_resp.keys = None
    thisExp.addData('main_ready_resp.keys',main_ready_resp.keys)
    if main_ready_resp.keys != None:  # we had a response
        thisExp.addData('main_ready_resp.rt', main_ready_resp.rt)
        thisExp.addData('main_ready_resp.duration', main_ready_resp.duration)
    thisExp.nextEntry()
    # the Routine "main_ready" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # set up handler to look after randomisation of conditions etc
    main_trials_1 = data.TrialHandler2(
        name='main_trials_1',
        nReps=1.0, 
        method='sequential', 
        extraInfo=expInfo, 
        originPath=-1, 
        trialList=data.importConditions(
        mainFile, 
        selection='0:40'
    )
    , 
        seed=None, 
        isTrials=True, 
    )
    thisExp.addLoop(main_trials_1)  # add the loop to the experiment
    thisMain_trial_1 = main_trials_1.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisMain_trial_1.rgb)
    if thisMain_trial_1 != None:
        for paramName in thisMain_trial_1:
            globals()[paramName] = thisMain_trial_1[paramName]
    if thisSession is not None:
        # if running in a Session with a Liaison client, send data up to now
        thisSession.sendExperimentData()
    
    for thisMain_trial_1 in main_trials_1:
        main_trials_1.status = STARTED
        if hasattr(thisMain_trial_1, 'status'):
            thisMain_trial_1.status = STARTED
        currentLoop = main_trials_1
        thisExp.timestampOnFlip(win, 'thisRow.t', format=globalClock.format)
        if thisSession is not None:
            # if running in a Session with a Liaison client, send data up to now
            thisSession.sendExperimentData()
        # abbreviate parameter names if possible (e.g. rgb = thisMain_trial_1.rgb)
        if thisMain_trial_1 != None:
            for paramName in thisMain_trial_1:
                globals()[paramName] = thisMain_trial_1[paramName]
        
        # --- Prepare to start Routine "main_trial" ---
        # create an object to store info about Routine main_trial
        main_trial = data.Routine(
            name='main_trial',
            components=[main_trial_fixation, main_trial_mask, main_trial_prime, main_trial_target, main_resp],
        )
        main_trial.status = NOT_STARTED
        continueRoutine = True
        # update component parameters for each repeat
        # Run 'Begin Routine' code from main_trial_key_map
        corrKey = 'j' if correct_response == 'word_key' else 'f'
        thisExp.addData('resolved_correct_key', corrKey)
        main_trial_prime.setText(prime_word)
        main_trial_target.setText(stimulus)
        # create starting attributes for main_resp
        main_resp.keys = []
        main_resp.rt = []
        _main_resp_allKeys = []
        # store start times for main_trial
        main_trial.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
        main_trial.tStart = globalClock.getTime(format='float')
        main_trial.status = STARTED
        thisExp.addData('main_trial.started', main_trial.tStart)
        main_trial.maxDuration = None
        # keep track of which components have finished
        main_trialComponents = main_trial.components
        for thisComponent in main_trial.components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "main_trial" ---
        thisExp.currentRoutine = main_trial
        main_trial.forceEnded = routineForceEnded = not continueRoutine
        while continueRoutine:
            # if trial has changed, end Routine now
            if hasattr(thisMain_trial_1, 'status') and thisMain_trial_1.status == STOPPING:
                continueRoutine = False
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *main_trial_fixation* updates
            
            # if main_trial_fixation is starting this frame...
            if main_trial_fixation.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                main_trial_fixation.frameNStart = frameN  # exact frame index
                main_trial_fixation.tStart = t  # local t and not account for scr refresh
                main_trial_fixation.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(main_trial_fixation, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'main_trial_fixation.started')
                # update status
                main_trial_fixation.status = STARTED
                main_trial_fixation.setAutoDraw(True)
            
            # if main_trial_fixation is active this frame...
            if main_trial_fixation.status == STARTED:
                # update params
                pass
            
            # if main_trial_fixation is stopping this frame...
            if main_trial_fixation.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > main_trial_fixation.tStartRefresh + 0.5-frameTolerance:
                    # keep track of stop time/frame for later
                    main_trial_fixation.tStop = t  # not accounting for scr refresh
                    main_trial_fixation.tStopRefresh = tThisFlipGlobal  # on global time
                    main_trial_fixation.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'main_trial_fixation.stopped')
                    # update status
                    main_trial_fixation.status = FINISHED
                    main_trial_fixation.setAutoDraw(False)
            
            # *main_trial_mask* updates
            
            # if main_trial_mask is starting this frame...
            if main_trial_mask.status == NOT_STARTED and tThisFlip >= 0.5-frameTolerance:
                # keep track of start time/frame for later
                main_trial_mask.frameNStart = frameN  # exact frame index
                main_trial_mask.tStart = t  # local t and not account for scr refresh
                main_trial_mask.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(main_trial_mask, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'main_trial_mask.started')
                # update status
                main_trial_mask.status = STARTED
                main_trial_mask.setAutoDraw(True)
            
            # if main_trial_mask is active this frame...
            if main_trial_mask.status == STARTED:
                # update params
                pass
            
            # if main_trial_mask is stopping this frame...
            if main_trial_mask.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > main_trial_mask.tStartRefresh + 0.5-frameTolerance:
                    # keep track of stop time/frame for later
                    main_trial_mask.tStop = t  # not accounting for scr refresh
                    main_trial_mask.tStopRefresh = tThisFlipGlobal  # on global time
                    main_trial_mask.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'main_trial_mask.stopped')
                    # update status
                    main_trial_mask.status = FINISHED
                    main_trial_mask.setAutoDraw(False)
            
            # *main_trial_prime* updates
            
            # if main_trial_prime is starting this frame...
            if main_trial_prime.status == NOT_STARTED and tThisFlip >= 1.0-frameTolerance:
                # keep track of start time/frame for later
                main_trial_prime.frameNStart = frameN  # exact frame index
                main_trial_prime.tStart = t  # local t and not account for scr refresh
                main_trial_prime.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(main_trial_prime, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'main_trial_prime.started')
                # update status
                main_trial_prime.status = STARTED
                main_trial_prime.setAutoDraw(True)
            
            # if main_trial_prime is active this frame...
            if main_trial_prime.status == STARTED:
                # update params
                pass
            
            # if main_trial_prime is stopping this frame...
            if main_trial_prime.status == STARTED:
                if frameN >= (main_trial_prime.frameNStart + primeFrames):
                    # keep track of stop time/frame for later
                    main_trial_prime.tStop = t  # not accounting for scr refresh
                    main_trial_prime.tStopRefresh = tThisFlipGlobal  # on global time
                    main_trial_prime.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'main_trial_prime.stopped')
                    # update status
                    main_trial_prime.status = FINISHED
                    main_trial_prime.setAutoDraw(False)
            
            # *main_trial_target* updates
            
            # if main_trial_target is starting this frame...
            if main_trial_target.status == NOT_STARTED and tThisFlip >= targetOnset-frameTolerance:
                # keep track of start time/frame for later
                main_trial_target.frameNStart = frameN  # exact frame index
                main_trial_target.tStart = t  # local t and not account for scr refresh
                main_trial_target.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(main_trial_target, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'main_trial_target.started')
                # update status
                main_trial_target.status = STARTED
                main_trial_target.setAutoDraw(True)
            
            # if main_trial_target is active this frame...
            if main_trial_target.status == STARTED:
                # update params
                pass
            
            # if main_trial_target is stopping this frame...
            if main_trial_target.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > main_trial_target.tStartRefresh + 2.0-frameTolerance:
                    # keep track of stop time/frame for later
                    main_trial_target.tStop = t  # not accounting for scr refresh
                    main_trial_target.tStopRefresh = tThisFlipGlobal  # on global time
                    main_trial_target.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'main_trial_target.stopped')
                    # update status
                    main_trial_target.status = FINISHED
                    main_trial_target.setAutoDraw(False)
            
            # *main_resp* updates
            waitOnFlip = False
            
            # if main_resp is starting this frame...
            if main_resp.status == NOT_STARTED and tThisFlip >= targetOnset-frameTolerance:
                # keep track of start time/frame for later
                main_resp.frameNStart = frameN  # exact frame index
                main_resp.tStart = t  # local t and not account for scr refresh
                main_resp.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(main_resp, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'main_resp.started')
                # update status
                main_resp.status = STARTED
                # keyboard checking is just starting
                waitOnFlip = True
                win.callOnFlip(main_resp.clock.reset)  # t=0 on next screen flip
                win.callOnFlip(main_resp.clearEvents, eventType='keyboard')  # clear events on next screen flip
            
            # if main_resp is stopping this frame...
            if main_resp.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > main_resp.tStartRefresh + 2.0-frameTolerance:
                    # keep track of stop time/frame for later
                    main_resp.tStop = t  # not accounting for scr refresh
                    main_resp.tStopRefresh = tThisFlipGlobal  # on global time
                    main_resp.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'main_resp.stopped')
                    # update status
                    main_resp.status = FINISHED
                    main_resp.status = FINISHED
            if main_resp.status == STARTED and not waitOnFlip:
                theseKeys = main_resp.getKeys(keyList=['j','f'], ignoreKeys=["escape"], waitRelease=False)
                _main_resp_allKeys.extend(theseKeys)
                if len(_main_resp_allKeys):
                    main_resp.keys = _main_resp_allKeys[-1].name  # just the last key pressed
                    main_resp.rt = _main_resp_allKeys[-1].rt
                    main_resp.duration = _main_resp_allKeys[-1].duration
                    # was this correct?
                    if (main_resp.keys == str(corrKey)) or (main_resp.keys == corrKey):
                        main_resp.corr = 1
                    else:
                        main_resp.corr = 0
                    # a response ends the routine
                    continueRoutine = False
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, win=win)
                return
            # pause experiment here if requested
            if thisExp.status == PAUSED:
                pauseExperiment(
                    thisExp=thisExp, 
                    win=win, 
                    timers=[routineTimer, globalClock], 
                    currentRoutine=main_trial,
                )
                # skip the frame we paused on
                continue
            
            # has a Component requested the Routine to end?
            if not continueRoutine:
                main_trial.forceEnded = routineForceEnded = True
            # has the Routine been forcibly ended?
            if main_trial.forceEnded or routineForceEnded:
                break
            # has every Component finished?
            continueRoutine = False
            for thisComponent in main_trial.components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "main_trial" ---
        for thisComponent in main_trial.components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # store stop times for main_trial
        main_trial.tStop = globalClock.getTime(format='float')
        main_trial.tStopRefresh = tThisFlipGlobal
        thisExp.addData('main_trial.stopped', main_trial.tStop)
        # Run 'End Routine' code from main_trial_key_map
        prime_dur_ms = None
        if getattr(main_trial_prime, 'tStartRefresh', None) is not None and getattr(main_trial_prime, 'tStopRefresh', None) is not None:
            prime_dur_ms = (main_trial_prime.tStopRefresh - main_trial_prime.tStartRefresh) * 1000
        thisExp.addData('prime_actual_ms', prime_dur_ms)
        soa_actual_ms = None
        if getattr(main_trial_target, 'tStartRefresh', None) is not None and getattr(main_trial_prime, 'tStartRefresh', None) is not None:
            soa_actual_ms = (main_trial_target.tStartRefresh - main_trial_prime.tStartRefresh) * 1000
        thisExp.addData('soa_actual_ms', soa_actual_ms)
        # check responses
        if main_resp.keys in ['', [], None]:  # No response was made
            main_resp.keys = None
            # was no response the correct answer?!
            if str(corrKey).lower() == 'none':
               main_resp.corr = 1;  # correct non-response
            else:
               main_resp.corr = 0;  # failed to respond (incorrectly)
        # store data for main_trials_1 (TrialHandler)
        main_trials_1.addData('main_resp.keys',main_resp.keys)
        main_trials_1.addData('main_resp.corr', main_resp.corr)
        if main_resp.keys != None:  # we had a response
            main_trials_1.addData('main_resp.rt', main_resp.rt)
            main_trials_1.addData('main_resp.duration', main_resp.duration)
        # the Routine "main_trial" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        
        # --- Prepare to start Routine "main_iti" ---
        # create an object to store info about Routine main_iti
        main_iti = data.Routine(
            name='main_iti',
            components=[main_iti_blank],
        )
        main_iti.status = NOT_STARTED
        continueRoutine = True
        # update component parameters for each repeat
        # Run 'Begin Routine' code from main_iti_randomize
        itiDur = 0.6 + 0.1 * randint(0, 5)
        thisExp.addData('iti_duration', itiDur)
        # store start times for main_iti
        main_iti.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
        main_iti.tStart = globalClock.getTime(format='float')
        main_iti.status = STARTED
        thisExp.addData('main_iti.started', main_iti.tStart)
        main_iti.maxDuration = None
        # keep track of which components have finished
        main_itiComponents = main_iti.components
        for thisComponent in main_iti.components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "main_iti" ---
        thisExp.currentRoutine = main_iti
        main_iti.forceEnded = routineForceEnded = not continueRoutine
        while continueRoutine:
            # if trial has changed, end Routine now
            if hasattr(thisMain_trial_1, 'status') and thisMain_trial_1.status == STOPPING:
                continueRoutine = False
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *main_iti_blank* updates
            
            # if main_iti_blank is starting this frame...
            if main_iti_blank.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
                # keep track of start time/frame for later
                main_iti_blank.frameNStart = frameN  # exact frame index
                main_iti_blank.tStart = t  # local t and not account for scr refresh
                main_iti_blank.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(main_iti_blank, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'main_iti_blank.started')
                # update status
                main_iti_blank.status = STARTED
                main_iti_blank.setAutoDraw(True)
            
            # if main_iti_blank is active this frame...
            if main_iti_blank.status == STARTED:
                # update params
                pass
            
            # if main_iti_blank is stopping this frame...
            if main_iti_blank.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > main_iti_blank.tStartRefresh + itiDur-frameTolerance:
                    # keep track of stop time/frame for later
                    main_iti_blank.tStop = t  # not accounting for scr refresh
                    main_iti_blank.tStopRefresh = tThisFlipGlobal  # on global time
                    main_iti_blank.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'main_iti_blank.stopped')
                    # update status
                    main_iti_blank.status = FINISHED
                    main_iti_blank.setAutoDraw(False)
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, win=win)
                return
            # pause experiment here if requested
            if thisExp.status == PAUSED:
                pauseExperiment(
                    thisExp=thisExp, 
                    win=win, 
                    timers=[routineTimer, globalClock], 
                    currentRoutine=main_iti,
                )
                # skip the frame we paused on
                continue
            
            # has a Component requested the Routine to end?
            if not continueRoutine:
                main_iti.forceEnded = routineForceEnded = True
            # has the Routine been forcibly ended?
            if main_iti.forceEnded or routineForceEnded:
                break
            # has every Component finished?
            continueRoutine = False
            for thisComponent in main_iti.components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "main_iti" ---
        for thisComponent in main_iti.components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # store stop times for main_iti
        main_iti.tStop = globalClock.getTime(format='float')
        main_iti.tStopRefresh = tThisFlipGlobal
        thisExp.addData('main_iti.stopped', main_iti.tStop)
        # the Routine "main_iti" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        # mark thisMain_trial_1 as finished
        if hasattr(thisMain_trial_1, 'status'):
            thisMain_trial_1.status = FINISHED
        # if awaiting a pause, pause now
        if main_trials_1.status == PAUSED:
            thisExp.status = PAUSED
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[globalClock], 
            )
            # once done pausing, restore running status
            main_trials_1.status = STARTED
        thisExp.nextEntry()
        
    # completed 1.0 repeats of 'main_trials_1'
    main_trials_1.status = FINISHED
    
    if thisSession is not None:
        # if running in a Session with a Liaison client, send data up to now
        thisSession.sendExperimentData()
    # get names of stimulus parameters
    if main_trials_1.trialList in ([], [None], None):
        params = []
    else:
        params = main_trials_1.trialList[0].keys()
    # save data for this loop
    main_trials_1.saveAsText(filename + '_main_trials_1.csv', delim=',',
        stimOut=params,
        dataOut=['n','all_mean','all_std', 'all_raw'])
    
    # --- Prepare to start Routine "break_1_timer" ---
    # create an object to store info about Routine break_1_timer
    break_1_timer = data.Routine(
        name='break_1_timer',
        components=[break_1_display],
    )
    break_1_timer.status = NOT_STARTED
    continueRoutine = True
    # update component parameters for each repeat
    # Run 'Begin Routine' code from break_1_timer_code
    break_1_timer_clock = core.Clock()
    # store start times for break_1_timer
    break_1_timer.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
    break_1_timer.tStart = globalClock.getTime(format='float')
    break_1_timer.status = STARTED
    thisExp.addData('break_1_timer.started', break_1_timer.tStart)
    break_1_timer.maxDuration = None
    # keep track of which components have finished
    break_1_timerComponents = break_1_timer.components
    for thisComponent in break_1_timer.components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "break_1_timer" ---
    thisExp.currentRoutine = break_1_timer
    break_1_timer.forceEnded = routineForceEnded = not continueRoutine
    while continueRoutine and routineTimer.getTime() < 60.0:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *break_1_display* updates
        
        # if break_1_display is starting this frame...
        if break_1_display.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
            # keep track of start time/frame for later
            break_1_display.frameNStart = frameN  # exact frame index
            break_1_display.tStart = t  # local t and not account for scr refresh
            break_1_display.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(break_1_display, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'break_1_display.started')
            # update status
            break_1_display.status = STARTED
            break_1_display.setAutoDraw(True)
        
        # if break_1_display is active this frame...
        if break_1_display.status == STARTED:
            # update params
            pass
        
        # if break_1_display is stopping this frame...
        if break_1_display.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > break_1_display.tStartRefresh + 60.0-frameTolerance:
                # keep track of stop time/frame for later
                break_1_display.tStop = t  # not accounting for scr refresh
                break_1_display.tStopRefresh = tThisFlipGlobal  # on global time
                break_1_display.frameNStop = frameN  # exact frame index
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'break_1_display.stopped')
                # update status
                break_1_display.status = FINISHED
                break_1_display.setAutoDraw(False)
        # Run 'Each Frame' code from break_1_timer_code
        remaining = max(0, 60 - int(break_1_timer_clock.getTime()))
        break_1_display.setText(f'지금부터 1분간 쉬는시간입니다.\n\n남은 시간: {remaining}초')
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, win=win)
            return
        # pause experiment here if requested
        if thisExp.status == PAUSED:
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[routineTimer, globalClock], 
                currentRoutine=break_1_timer,
            )
            # skip the frame we paused on
            continue
        
        # has a Component requested the Routine to end?
        if not continueRoutine:
            break_1_timer.forceEnded = routineForceEnded = True
        # has the Routine been forcibly ended?
        if break_1_timer.forceEnded or routineForceEnded:
            break
        # has every Component finished?
        continueRoutine = False
        for thisComponent in break_1_timer.components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "break_1_timer" ---
    for thisComponent in break_1_timer.components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # store stop times for break_1_timer
    break_1_timer.tStop = globalClock.getTime(format='float')
    break_1_timer.tStopRefresh = tThisFlipGlobal
    thisExp.addData('break_1_timer.stopped', break_1_timer.tStop)
    # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
    if break_1_timer.maxDurationReached:
        routineTimer.addTime(-break_1_timer.maxDuration)
    elif break_1_timer.forceEnded:
        routineTimer.reset()
    else:
        routineTimer.addTime(-60.000000)
    thisExp.nextEntry()
    
    # --- Prepare to start Routine "break_1_ready" ---
    # create an object to store info about Routine break_1_ready
    break_1_ready = data.Routine(
        name='break_1_ready',
        components=[break_1_ready_text, break_1_ready_resp],
    )
    break_1_ready.status = NOT_STARTED
    continueRoutine = True
    # update component parameters for each repeat
    # create starting attributes for break_1_ready_resp
    break_1_ready_resp.keys = []
    break_1_ready_resp.rt = []
    _break_1_ready_resp_allKeys = []
    # store start times for break_1_ready
    break_1_ready.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
    break_1_ready.tStart = globalClock.getTime(format='float')
    break_1_ready.status = STARTED
    thisExp.addData('break_1_ready.started', break_1_ready.tStart)
    break_1_ready.maxDuration = None
    # keep track of which components have finished
    break_1_readyComponents = break_1_ready.components
    for thisComponent in break_1_ready.components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "break_1_ready" ---
    thisExp.currentRoutine = break_1_ready
    break_1_ready.forceEnded = routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *break_1_ready_text* updates
        
        # if break_1_ready_text is starting this frame...
        if break_1_ready_text.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
            # keep track of start time/frame for later
            break_1_ready_text.frameNStart = frameN  # exact frame index
            break_1_ready_text.tStart = t  # local t and not account for scr refresh
            break_1_ready_text.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(break_1_ready_text, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'break_1_ready_text.started')
            # update status
            break_1_ready_text.status = STARTED
            break_1_ready_text.setAutoDraw(True)
        
        # if break_1_ready_text is active this frame...
        if break_1_ready_text.status == STARTED:
            # update params
            pass
        
        # *break_1_ready_resp* updates
        waitOnFlip = False
        
        # if break_1_ready_resp is starting this frame...
        if break_1_ready_resp.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
            # keep track of start time/frame for later
            break_1_ready_resp.frameNStart = frameN  # exact frame index
            break_1_ready_resp.tStart = t  # local t and not account for scr refresh
            break_1_ready_resp.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(break_1_ready_resp, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'break_1_ready_resp.started')
            # update status
            break_1_ready_resp.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(break_1_ready_resp.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(break_1_ready_resp.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if break_1_ready_resp.status == STARTED and not waitOnFlip:
            theseKeys = break_1_ready_resp.getKeys(keyList=['space'], ignoreKeys=["escape"], waitRelease=False)
            _break_1_ready_resp_allKeys.extend(theseKeys)
            if len(_break_1_ready_resp_allKeys):
                break_1_ready_resp.keys = _break_1_ready_resp_allKeys[-1].name  # just the last key pressed
                break_1_ready_resp.rt = _break_1_ready_resp_allKeys[-1].rt
                break_1_ready_resp.duration = _break_1_ready_resp_allKeys[-1].duration
                # a response ends the routine
                continueRoutine = False
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, win=win)
            return
        # pause experiment here if requested
        if thisExp.status == PAUSED:
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[routineTimer, globalClock], 
                currentRoutine=break_1_ready,
            )
            # skip the frame we paused on
            continue
        
        # has a Component requested the Routine to end?
        if not continueRoutine:
            break_1_ready.forceEnded = routineForceEnded = True
        # has the Routine been forcibly ended?
        if break_1_ready.forceEnded or routineForceEnded:
            break
        # has every Component finished?
        continueRoutine = False
        for thisComponent in break_1_ready.components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "break_1_ready" ---
    for thisComponent in break_1_ready.components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # store stop times for break_1_ready
    break_1_ready.tStop = globalClock.getTime(format='float')
    break_1_ready.tStopRefresh = tThisFlipGlobal
    thisExp.addData('break_1_ready.stopped', break_1_ready.tStop)
    # check responses
    if break_1_ready_resp.keys in ['', [], None]:  # No response was made
        break_1_ready_resp.keys = None
    thisExp.addData('break_1_ready_resp.keys',break_1_ready_resp.keys)
    if break_1_ready_resp.keys != None:  # we had a response
        thisExp.addData('break_1_ready_resp.rt', break_1_ready_resp.rt)
        thisExp.addData('break_1_ready_resp.duration', break_1_ready_resp.duration)
    thisExp.nextEntry()
    # the Routine "break_1_ready" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # set up handler to look after randomisation of conditions etc
    main_trials_2 = data.TrialHandler2(
        name='main_trials_2',
        nReps=1.0, 
        method='sequential', 
        extraInfo=expInfo, 
        originPath=-1, 
        trialList=data.importConditions(
        mainFile, 
        selection='40:80'
    )
    , 
        seed=None, 
        isTrials=True, 
    )
    thisExp.addLoop(main_trials_2)  # add the loop to the experiment
    thisMain_trial_2 = main_trials_2.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisMain_trial_2.rgb)
    if thisMain_trial_2 != None:
        for paramName in thisMain_trial_2:
            globals()[paramName] = thisMain_trial_2[paramName]
    if thisSession is not None:
        # if running in a Session with a Liaison client, send data up to now
        thisSession.sendExperimentData()
    
    for thisMain_trial_2 in main_trials_2:
        main_trials_2.status = STARTED
        if hasattr(thisMain_trial_2, 'status'):
            thisMain_trial_2.status = STARTED
        currentLoop = main_trials_2
        thisExp.timestampOnFlip(win, 'thisRow.t', format=globalClock.format)
        if thisSession is not None:
            # if running in a Session with a Liaison client, send data up to now
            thisSession.sendExperimentData()
        # abbreviate parameter names if possible (e.g. rgb = thisMain_trial_2.rgb)
        if thisMain_trial_2 != None:
            for paramName in thisMain_trial_2:
                globals()[paramName] = thisMain_trial_2[paramName]
        
        # --- Prepare to start Routine "main_trial" ---
        # create an object to store info about Routine main_trial
        main_trial = data.Routine(
            name='main_trial',
            components=[main_trial_fixation, main_trial_mask, main_trial_prime, main_trial_target, main_resp],
        )
        main_trial.status = NOT_STARTED
        continueRoutine = True
        # update component parameters for each repeat
        # Run 'Begin Routine' code from main_trial_key_map
        corrKey = 'j' if correct_response == 'word_key' else 'f'
        thisExp.addData('resolved_correct_key', corrKey)
        main_trial_prime.setText(prime_word)
        main_trial_target.setText(stimulus)
        # create starting attributes for main_resp
        main_resp.keys = []
        main_resp.rt = []
        _main_resp_allKeys = []
        # store start times for main_trial
        main_trial.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
        main_trial.tStart = globalClock.getTime(format='float')
        main_trial.status = STARTED
        thisExp.addData('main_trial.started', main_trial.tStart)
        main_trial.maxDuration = None
        # keep track of which components have finished
        main_trialComponents = main_trial.components
        for thisComponent in main_trial.components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "main_trial" ---
        thisExp.currentRoutine = main_trial
        main_trial.forceEnded = routineForceEnded = not continueRoutine
        while continueRoutine:
            # if trial has changed, end Routine now
            if hasattr(thisMain_trial_2, 'status') and thisMain_trial_2.status == STOPPING:
                continueRoutine = False
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *main_trial_fixation* updates
            
            # if main_trial_fixation is starting this frame...
            if main_trial_fixation.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                main_trial_fixation.frameNStart = frameN  # exact frame index
                main_trial_fixation.tStart = t  # local t and not account for scr refresh
                main_trial_fixation.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(main_trial_fixation, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'main_trial_fixation.started')
                # update status
                main_trial_fixation.status = STARTED
                main_trial_fixation.setAutoDraw(True)
            
            # if main_trial_fixation is active this frame...
            if main_trial_fixation.status == STARTED:
                # update params
                pass
            
            # if main_trial_fixation is stopping this frame...
            if main_trial_fixation.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > main_trial_fixation.tStartRefresh + 0.5-frameTolerance:
                    # keep track of stop time/frame for later
                    main_trial_fixation.tStop = t  # not accounting for scr refresh
                    main_trial_fixation.tStopRefresh = tThisFlipGlobal  # on global time
                    main_trial_fixation.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'main_trial_fixation.stopped')
                    # update status
                    main_trial_fixation.status = FINISHED
                    main_trial_fixation.setAutoDraw(False)
            
            # *main_trial_mask* updates
            
            # if main_trial_mask is starting this frame...
            if main_trial_mask.status == NOT_STARTED and tThisFlip >= 0.5-frameTolerance:
                # keep track of start time/frame for later
                main_trial_mask.frameNStart = frameN  # exact frame index
                main_trial_mask.tStart = t  # local t and not account for scr refresh
                main_trial_mask.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(main_trial_mask, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'main_trial_mask.started')
                # update status
                main_trial_mask.status = STARTED
                main_trial_mask.setAutoDraw(True)
            
            # if main_trial_mask is active this frame...
            if main_trial_mask.status == STARTED:
                # update params
                pass
            
            # if main_trial_mask is stopping this frame...
            if main_trial_mask.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > main_trial_mask.tStartRefresh + 0.5-frameTolerance:
                    # keep track of stop time/frame for later
                    main_trial_mask.tStop = t  # not accounting for scr refresh
                    main_trial_mask.tStopRefresh = tThisFlipGlobal  # on global time
                    main_trial_mask.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'main_trial_mask.stopped')
                    # update status
                    main_trial_mask.status = FINISHED
                    main_trial_mask.setAutoDraw(False)
            
            # *main_trial_prime* updates
            
            # if main_trial_prime is starting this frame...
            if main_trial_prime.status == NOT_STARTED and tThisFlip >= 1.0-frameTolerance:
                # keep track of start time/frame for later
                main_trial_prime.frameNStart = frameN  # exact frame index
                main_trial_prime.tStart = t  # local t and not account for scr refresh
                main_trial_prime.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(main_trial_prime, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'main_trial_prime.started')
                # update status
                main_trial_prime.status = STARTED
                main_trial_prime.setAutoDraw(True)
            
            # if main_trial_prime is active this frame...
            if main_trial_prime.status == STARTED:
                # update params
                pass
            
            # if main_trial_prime is stopping this frame...
            if main_trial_prime.status == STARTED:
                if frameN >= (main_trial_prime.frameNStart + primeFrames):
                    # keep track of stop time/frame for later
                    main_trial_prime.tStop = t  # not accounting for scr refresh
                    main_trial_prime.tStopRefresh = tThisFlipGlobal  # on global time
                    main_trial_prime.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'main_trial_prime.stopped')
                    # update status
                    main_trial_prime.status = FINISHED
                    main_trial_prime.setAutoDraw(False)
            
            # *main_trial_target* updates
            
            # if main_trial_target is starting this frame...
            if main_trial_target.status == NOT_STARTED and tThisFlip >= targetOnset-frameTolerance:
                # keep track of start time/frame for later
                main_trial_target.frameNStart = frameN  # exact frame index
                main_trial_target.tStart = t  # local t and not account for scr refresh
                main_trial_target.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(main_trial_target, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'main_trial_target.started')
                # update status
                main_trial_target.status = STARTED
                main_trial_target.setAutoDraw(True)
            
            # if main_trial_target is active this frame...
            if main_trial_target.status == STARTED:
                # update params
                pass
            
            # if main_trial_target is stopping this frame...
            if main_trial_target.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > main_trial_target.tStartRefresh + 2.0-frameTolerance:
                    # keep track of stop time/frame for later
                    main_trial_target.tStop = t  # not accounting for scr refresh
                    main_trial_target.tStopRefresh = tThisFlipGlobal  # on global time
                    main_trial_target.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'main_trial_target.stopped')
                    # update status
                    main_trial_target.status = FINISHED
                    main_trial_target.setAutoDraw(False)
            
            # *main_resp* updates
            waitOnFlip = False
            
            # if main_resp is starting this frame...
            if main_resp.status == NOT_STARTED and tThisFlip >= targetOnset-frameTolerance:
                # keep track of start time/frame for later
                main_resp.frameNStart = frameN  # exact frame index
                main_resp.tStart = t  # local t and not account for scr refresh
                main_resp.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(main_resp, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'main_resp.started')
                # update status
                main_resp.status = STARTED
                # keyboard checking is just starting
                waitOnFlip = True
                win.callOnFlip(main_resp.clock.reset)  # t=0 on next screen flip
                win.callOnFlip(main_resp.clearEvents, eventType='keyboard')  # clear events on next screen flip
            
            # if main_resp is stopping this frame...
            if main_resp.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > main_resp.tStartRefresh + 2.0-frameTolerance:
                    # keep track of stop time/frame for later
                    main_resp.tStop = t  # not accounting for scr refresh
                    main_resp.tStopRefresh = tThisFlipGlobal  # on global time
                    main_resp.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'main_resp.stopped')
                    # update status
                    main_resp.status = FINISHED
                    main_resp.status = FINISHED
            if main_resp.status == STARTED and not waitOnFlip:
                theseKeys = main_resp.getKeys(keyList=['j','f'], ignoreKeys=["escape"], waitRelease=False)
                _main_resp_allKeys.extend(theseKeys)
                if len(_main_resp_allKeys):
                    main_resp.keys = _main_resp_allKeys[-1].name  # just the last key pressed
                    main_resp.rt = _main_resp_allKeys[-1].rt
                    main_resp.duration = _main_resp_allKeys[-1].duration
                    # was this correct?
                    if (main_resp.keys == str(corrKey)) or (main_resp.keys == corrKey):
                        main_resp.corr = 1
                    else:
                        main_resp.corr = 0
                    # a response ends the routine
                    continueRoutine = False
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, win=win)
                return
            # pause experiment here if requested
            if thisExp.status == PAUSED:
                pauseExperiment(
                    thisExp=thisExp, 
                    win=win, 
                    timers=[routineTimer, globalClock], 
                    currentRoutine=main_trial,
                )
                # skip the frame we paused on
                continue
            
            # has a Component requested the Routine to end?
            if not continueRoutine:
                main_trial.forceEnded = routineForceEnded = True
            # has the Routine been forcibly ended?
            if main_trial.forceEnded or routineForceEnded:
                break
            # has every Component finished?
            continueRoutine = False
            for thisComponent in main_trial.components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "main_trial" ---
        for thisComponent in main_trial.components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # store stop times for main_trial
        main_trial.tStop = globalClock.getTime(format='float')
        main_trial.tStopRefresh = tThisFlipGlobal
        thisExp.addData('main_trial.stopped', main_trial.tStop)
        # Run 'End Routine' code from main_trial_key_map
        prime_dur_ms = None
        if getattr(main_trial_prime, 'tStartRefresh', None) is not None and getattr(main_trial_prime, 'tStopRefresh', None) is not None:
            prime_dur_ms = (main_trial_prime.tStopRefresh - main_trial_prime.tStartRefresh) * 1000
        thisExp.addData('prime_actual_ms', prime_dur_ms)
        soa_actual_ms = None
        if getattr(main_trial_target, 'tStartRefresh', None) is not None and getattr(main_trial_prime, 'tStartRefresh', None) is not None:
            soa_actual_ms = (main_trial_target.tStartRefresh - main_trial_prime.tStartRefresh) * 1000
        thisExp.addData('soa_actual_ms', soa_actual_ms)
        # check responses
        if main_resp.keys in ['', [], None]:  # No response was made
            main_resp.keys = None
            # was no response the correct answer?!
            if str(corrKey).lower() == 'none':
               main_resp.corr = 1;  # correct non-response
            else:
               main_resp.corr = 0;  # failed to respond (incorrectly)
        # store data for main_trials_2 (TrialHandler)
        main_trials_2.addData('main_resp.keys',main_resp.keys)
        main_trials_2.addData('main_resp.corr', main_resp.corr)
        if main_resp.keys != None:  # we had a response
            main_trials_2.addData('main_resp.rt', main_resp.rt)
            main_trials_2.addData('main_resp.duration', main_resp.duration)
        # the Routine "main_trial" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        
        # --- Prepare to start Routine "main_iti" ---
        # create an object to store info about Routine main_iti
        main_iti = data.Routine(
            name='main_iti',
            components=[main_iti_blank],
        )
        main_iti.status = NOT_STARTED
        continueRoutine = True
        # update component parameters for each repeat
        # Run 'Begin Routine' code from main_iti_randomize
        itiDur = 0.6 + 0.1 * randint(0, 5)
        thisExp.addData('iti_duration', itiDur)
        # store start times for main_iti
        main_iti.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
        main_iti.tStart = globalClock.getTime(format='float')
        main_iti.status = STARTED
        thisExp.addData('main_iti.started', main_iti.tStart)
        main_iti.maxDuration = None
        # keep track of which components have finished
        main_itiComponents = main_iti.components
        for thisComponent in main_iti.components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "main_iti" ---
        thisExp.currentRoutine = main_iti
        main_iti.forceEnded = routineForceEnded = not continueRoutine
        while continueRoutine:
            # if trial has changed, end Routine now
            if hasattr(thisMain_trial_2, 'status') and thisMain_trial_2.status == STOPPING:
                continueRoutine = False
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *main_iti_blank* updates
            
            # if main_iti_blank is starting this frame...
            if main_iti_blank.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
                # keep track of start time/frame for later
                main_iti_blank.frameNStart = frameN  # exact frame index
                main_iti_blank.tStart = t  # local t and not account for scr refresh
                main_iti_blank.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(main_iti_blank, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'main_iti_blank.started')
                # update status
                main_iti_blank.status = STARTED
                main_iti_blank.setAutoDraw(True)
            
            # if main_iti_blank is active this frame...
            if main_iti_blank.status == STARTED:
                # update params
                pass
            
            # if main_iti_blank is stopping this frame...
            if main_iti_blank.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > main_iti_blank.tStartRefresh + itiDur-frameTolerance:
                    # keep track of stop time/frame for later
                    main_iti_blank.tStop = t  # not accounting for scr refresh
                    main_iti_blank.tStopRefresh = tThisFlipGlobal  # on global time
                    main_iti_blank.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'main_iti_blank.stopped')
                    # update status
                    main_iti_blank.status = FINISHED
                    main_iti_blank.setAutoDraw(False)
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, win=win)
                return
            # pause experiment here if requested
            if thisExp.status == PAUSED:
                pauseExperiment(
                    thisExp=thisExp, 
                    win=win, 
                    timers=[routineTimer, globalClock], 
                    currentRoutine=main_iti,
                )
                # skip the frame we paused on
                continue
            
            # has a Component requested the Routine to end?
            if not continueRoutine:
                main_iti.forceEnded = routineForceEnded = True
            # has the Routine been forcibly ended?
            if main_iti.forceEnded or routineForceEnded:
                break
            # has every Component finished?
            continueRoutine = False
            for thisComponent in main_iti.components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "main_iti" ---
        for thisComponent in main_iti.components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # store stop times for main_iti
        main_iti.tStop = globalClock.getTime(format='float')
        main_iti.tStopRefresh = tThisFlipGlobal
        thisExp.addData('main_iti.stopped', main_iti.tStop)
        # the Routine "main_iti" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        # mark thisMain_trial_2 as finished
        if hasattr(thisMain_trial_2, 'status'):
            thisMain_trial_2.status = FINISHED
        # if awaiting a pause, pause now
        if main_trials_2.status == PAUSED:
            thisExp.status = PAUSED
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[globalClock], 
            )
            # once done pausing, restore running status
            main_trials_2.status = STARTED
        thisExp.nextEntry()
        
    # completed 1.0 repeats of 'main_trials_2'
    main_trials_2.status = FINISHED
    
    if thisSession is not None:
        # if running in a Session with a Liaison client, send data up to now
        thisSession.sendExperimentData()
    # get names of stimulus parameters
    if main_trials_2.trialList in ([], [None], None):
        params = []
    else:
        params = main_trials_2.trialList[0].keys()
    # save data for this loop
    main_trials_2.saveAsText(filename + '_main_trials_2.csv', delim=',',
        stimOut=params,
        dataOut=['n','all_mean','all_std', 'all_raw'])
    
    # --- Prepare to start Routine "break_2_timer" ---
    # create an object to store info about Routine break_2_timer
    break_2_timer = data.Routine(
        name='break_2_timer',
        components=[break_2_display],
    )
    break_2_timer.status = NOT_STARTED
    continueRoutine = True
    # update component parameters for each repeat
    # Run 'Begin Routine' code from break_2_timer_code
    break_2_timer_clock = core.Clock()
    # store start times for break_2_timer
    break_2_timer.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
    break_2_timer.tStart = globalClock.getTime(format='float')
    break_2_timer.status = STARTED
    thisExp.addData('break_2_timer.started', break_2_timer.tStart)
    break_2_timer.maxDuration = None
    # keep track of which components have finished
    break_2_timerComponents = break_2_timer.components
    for thisComponent in break_2_timer.components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "break_2_timer" ---
    thisExp.currentRoutine = break_2_timer
    break_2_timer.forceEnded = routineForceEnded = not continueRoutine
    while continueRoutine and routineTimer.getTime() < 60.0:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *break_2_display* updates
        
        # if break_2_display is starting this frame...
        if break_2_display.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
            # keep track of start time/frame for later
            break_2_display.frameNStart = frameN  # exact frame index
            break_2_display.tStart = t  # local t and not account for scr refresh
            break_2_display.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(break_2_display, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'break_2_display.started')
            # update status
            break_2_display.status = STARTED
            break_2_display.setAutoDraw(True)
        
        # if break_2_display is active this frame...
        if break_2_display.status == STARTED:
            # update params
            pass
        
        # if break_2_display is stopping this frame...
        if break_2_display.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > break_2_display.tStartRefresh + 60.0-frameTolerance:
                # keep track of stop time/frame for later
                break_2_display.tStop = t  # not accounting for scr refresh
                break_2_display.tStopRefresh = tThisFlipGlobal  # on global time
                break_2_display.frameNStop = frameN  # exact frame index
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'break_2_display.stopped')
                # update status
                break_2_display.status = FINISHED
                break_2_display.setAutoDraw(False)
        # Run 'Each Frame' code from break_2_timer_code
        remaining = max(0, 60 - int(break_2_timer_clock.getTime()))
        break_2_display.setText(f'지금부터 1분간 쉬는시간입니다.\n\n남은 시간: {remaining}초')
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, win=win)
            return
        # pause experiment here if requested
        if thisExp.status == PAUSED:
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[routineTimer, globalClock], 
                currentRoutine=break_2_timer,
            )
            # skip the frame we paused on
            continue
        
        # has a Component requested the Routine to end?
        if not continueRoutine:
            break_2_timer.forceEnded = routineForceEnded = True
        # has the Routine been forcibly ended?
        if break_2_timer.forceEnded or routineForceEnded:
            break
        # has every Component finished?
        continueRoutine = False
        for thisComponent in break_2_timer.components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "break_2_timer" ---
    for thisComponent in break_2_timer.components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # store stop times for break_2_timer
    break_2_timer.tStop = globalClock.getTime(format='float')
    break_2_timer.tStopRefresh = tThisFlipGlobal
    thisExp.addData('break_2_timer.stopped', break_2_timer.tStop)
    # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
    if break_2_timer.maxDurationReached:
        routineTimer.addTime(-break_2_timer.maxDuration)
    elif break_2_timer.forceEnded:
        routineTimer.reset()
    else:
        routineTimer.addTime(-60.000000)
    thisExp.nextEntry()
    
    # --- Prepare to start Routine "break_2_ready" ---
    # create an object to store info about Routine break_2_ready
    break_2_ready = data.Routine(
        name='break_2_ready',
        components=[break_2_ready_text, break_2_ready_resp],
    )
    break_2_ready.status = NOT_STARTED
    continueRoutine = True
    # update component parameters for each repeat
    # create starting attributes for break_2_ready_resp
    break_2_ready_resp.keys = []
    break_2_ready_resp.rt = []
    _break_2_ready_resp_allKeys = []
    # store start times for break_2_ready
    break_2_ready.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
    break_2_ready.tStart = globalClock.getTime(format='float')
    break_2_ready.status = STARTED
    thisExp.addData('break_2_ready.started', break_2_ready.tStart)
    break_2_ready.maxDuration = None
    # keep track of which components have finished
    break_2_readyComponents = break_2_ready.components
    for thisComponent in break_2_ready.components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "break_2_ready" ---
    thisExp.currentRoutine = break_2_ready
    break_2_ready.forceEnded = routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *break_2_ready_text* updates
        
        # if break_2_ready_text is starting this frame...
        if break_2_ready_text.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
            # keep track of start time/frame for later
            break_2_ready_text.frameNStart = frameN  # exact frame index
            break_2_ready_text.tStart = t  # local t and not account for scr refresh
            break_2_ready_text.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(break_2_ready_text, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'break_2_ready_text.started')
            # update status
            break_2_ready_text.status = STARTED
            break_2_ready_text.setAutoDraw(True)
        
        # if break_2_ready_text is active this frame...
        if break_2_ready_text.status == STARTED:
            # update params
            pass
        
        # *break_2_ready_resp* updates
        waitOnFlip = False
        
        # if break_2_ready_resp is starting this frame...
        if break_2_ready_resp.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
            # keep track of start time/frame for later
            break_2_ready_resp.frameNStart = frameN  # exact frame index
            break_2_ready_resp.tStart = t  # local t and not account for scr refresh
            break_2_ready_resp.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(break_2_ready_resp, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'break_2_ready_resp.started')
            # update status
            break_2_ready_resp.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(break_2_ready_resp.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(break_2_ready_resp.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if break_2_ready_resp.status == STARTED and not waitOnFlip:
            theseKeys = break_2_ready_resp.getKeys(keyList=['space'], ignoreKeys=["escape"], waitRelease=False)
            _break_2_ready_resp_allKeys.extend(theseKeys)
            if len(_break_2_ready_resp_allKeys):
                break_2_ready_resp.keys = _break_2_ready_resp_allKeys[-1].name  # just the last key pressed
                break_2_ready_resp.rt = _break_2_ready_resp_allKeys[-1].rt
                break_2_ready_resp.duration = _break_2_ready_resp_allKeys[-1].duration
                # a response ends the routine
                continueRoutine = False
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, win=win)
            return
        # pause experiment here if requested
        if thisExp.status == PAUSED:
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[routineTimer, globalClock], 
                currentRoutine=break_2_ready,
            )
            # skip the frame we paused on
            continue
        
        # has a Component requested the Routine to end?
        if not continueRoutine:
            break_2_ready.forceEnded = routineForceEnded = True
        # has the Routine been forcibly ended?
        if break_2_ready.forceEnded or routineForceEnded:
            break
        # has every Component finished?
        continueRoutine = False
        for thisComponent in break_2_ready.components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "break_2_ready" ---
    for thisComponent in break_2_ready.components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # store stop times for break_2_ready
    break_2_ready.tStop = globalClock.getTime(format='float')
    break_2_ready.tStopRefresh = tThisFlipGlobal
    thisExp.addData('break_2_ready.stopped', break_2_ready.tStop)
    # check responses
    if break_2_ready_resp.keys in ['', [], None]:  # No response was made
        break_2_ready_resp.keys = None
    thisExp.addData('break_2_ready_resp.keys',break_2_ready_resp.keys)
    if break_2_ready_resp.keys != None:  # we had a response
        thisExp.addData('break_2_ready_resp.rt', break_2_ready_resp.rt)
        thisExp.addData('break_2_ready_resp.duration', break_2_ready_resp.duration)
    thisExp.nextEntry()
    # the Routine "break_2_ready" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # set up handler to look after randomisation of conditions etc
    main_trials_3 = data.TrialHandler2(
        name='main_trials_3',
        nReps=1.0, 
        method='sequential', 
        extraInfo=expInfo, 
        originPath=-1, 
        trialList=data.importConditions(
        mainFile, 
        selection='80:120'
    )
    , 
        seed=None, 
        isTrials=True, 
    )
    thisExp.addLoop(main_trials_3)  # add the loop to the experiment
    thisMain_trial_3 = main_trials_3.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisMain_trial_3.rgb)
    if thisMain_trial_3 != None:
        for paramName in thisMain_trial_3:
            globals()[paramName] = thisMain_trial_3[paramName]
    if thisSession is not None:
        # if running in a Session with a Liaison client, send data up to now
        thisSession.sendExperimentData()
    
    for thisMain_trial_3 in main_trials_3:
        main_trials_3.status = STARTED
        if hasattr(thisMain_trial_3, 'status'):
            thisMain_trial_3.status = STARTED
        currentLoop = main_trials_3
        thisExp.timestampOnFlip(win, 'thisRow.t', format=globalClock.format)
        if thisSession is not None:
            # if running in a Session with a Liaison client, send data up to now
            thisSession.sendExperimentData()
        # abbreviate parameter names if possible (e.g. rgb = thisMain_trial_3.rgb)
        if thisMain_trial_3 != None:
            for paramName in thisMain_trial_3:
                globals()[paramName] = thisMain_trial_3[paramName]
        
        # --- Prepare to start Routine "main_trial" ---
        # create an object to store info about Routine main_trial
        main_trial = data.Routine(
            name='main_trial',
            components=[main_trial_fixation, main_trial_mask, main_trial_prime, main_trial_target, main_resp],
        )
        main_trial.status = NOT_STARTED
        continueRoutine = True
        # update component parameters for each repeat
        # Run 'Begin Routine' code from main_trial_key_map
        corrKey = 'j' if correct_response == 'word_key' else 'f'
        thisExp.addData('resolved_correct_key', corrKey)
        main_trial_prime.setText(prime_word)
        main_trial_target.setText(stimulus)
        # create starting attributes for main_resp
        main_resp.keys = []
        main_resp.rt = []
        _main_resp_allKeys = []
        # store start times for main_trial
        main_trial.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
        main_trial.tStart = globalClock.getTime(format='float')
        main_trial.status = STARTED
        thisExp.addData('main_trial.started', main_trial.tStart)
        main_trial.maxDuration = None
        # keep track of which components have finished
        main_trialComponents = main_trial.components
        for thisComponent in main_trial.components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "main_trial" ---
        thisExp.currentRoutine = main_trial
        main_trial.forceEnded = routineForceEnded = not continueRoutine
        while continueRoutine:
            # if trial has changed, end Routine now
            if hasattr(thisMain_trial_3, 'status') and thisMain_trial_3.status == STOPPING:
                continueRoutine = False
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *main_trial_fixation* updates
            
            # if main_trial_fixation is starting this frame...
            if main_trial_fixation.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                main_trial_fixation.frameNStart = frameN  # exact frame index
                main_trial_fixation.tStart = t  # local t and not account for scr refresh
                main_trial_fixation.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(main_trial_fixation, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'main_trial_fixation.started')
                # update status
                main_trial_fixation.status = STARTED
                main_trial_fixation.setAutoDraw(True)
            
            # if main_trial_fixation is active this frame...
            if main_trial_fixation.status == STARTED:
                # update params
                pass
            
            # if main_trial_fixation is stopping this frame...
            if main_trial_fixation.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > main_trial_fixation.tStartRefresh + 0.5-frameTolerance:
                    # keep track of stop time/frame for later
                    main_trial_fixation.tStop = t  # not accounting for scr refresh
                    main_trial_fixation.tStopRefresh = tThisFlipGlobal  # on global time
                    main_trial_fixation.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'main_trial_fixation.stopped')
                    # update status
                    main_trial_fixation.status = FINISHED
                    main_trial_fixation.setAutoDraw(False)
            
            # *main_trial_mask* updates
            
            # if main_trial_mask is starting this frame...
            if main_trial_mask.status == NOT_STARTED and tThisFlip >= 0.5-frameTolerance:
                # keep track of start time/frame for later
                main_trial_mask.frameNStart = frameN  # exact frame index
                main_trial_mask.tStart = t  # local t and not account for scr refresh
                main_trial_mask.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(main_trial_mask, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'main_trial_mask.started')
                # update status
                main_trial_mask.status = STARTED
                main_trial_mask.setAutoDraw(True)
            
            # if main_trial_mask is active this frame...
            if main_trial_mask.status == STARTED:
                # update params
                pass
            
            # if main_trial_mask is stopping this frame...
            if main_trial_mask.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > main_trial_mask.tStartRefresh + 0.5-frameTolerance:
                    # keep track of stop time/frame for later
                    main_trial_mask.tStop = t  # not accounting for scr refresh
                    main_trial_mask.tStopRefresh = tThisFlipGlobal  # on global time
                    main_trial_mask.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'main_trial_mask.stopped')
                    # update status
                    main_trial_mask.status = FINISHED
                    main_trial_mask.setAutoDraw(False)
            
            # *main_trial_prime* updates
            
            # if main_trial_prime is starting this frame...
            if main_trial_prime.status == NOT_STARTED and tThisFlip >= 1.0-frameTolerance:
                # keep track of start time/frame for later
                main_trial_prime.frameNStart = frameN  # exact frame index
                main_trial_prime.tStart = t  # local t and not account for scr refresh
                main_trial_prime.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(main_trial_prime, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'main_trial_prime.started')
                # update status
                main_trial_prime.status = STARTED
                main_trial_prime.setAutoDraw(True)
            
            # if main_trial_prime is active this frame...
            if main_trial_prime.status == STARTED:
                # update params
                pass
            
            # if main_trial_prime is stopping this frame...
            if main_trial_prime.status == STARTED:
                if frameN >= (main_trial_prime.frameNStart + primeFrames):
                    # keep track of stop time/frame for later
                    main_trial_prime.tStop = t  # not accounting for scr refresh
                    main_trial_prime.tStopRefresh = tThisFlipGlobal  # on global time
                    main_trial_prime.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'main_trial_prime.stopped')
                    # update status
                    main_trial_prime.status = FINISHED
                    main_trial_prime.setAutoDraw(False)
            
            # *main_trial_target* updates
            
            # if main_trial_target is starting this frame...
            if main_trial_target.status == NOT_STARTED and tThisFlip >= targetOnset-frameTolerance:
                # keep track of start time/frame for later
                main_trial_target.frameNStart = frameN  # exact frame index
                main_trial_target.tStart = t  # local t and not account for scr refresh
                main_trial_target.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(main_trial_target, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'main_trial_target.started')
                # update status
                main_trial_target.status = STARTED
                main_trial_target.setAutoDraw(True)
            
            # if main_trial_target is active this frame...
            if main_trial_target.status == STARTED:
                # update params
                pass
            
            # if main_trial_target is stopping this frame...
            if main_trial_target.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > main_trial_target.tStartRefresh + 2.0-frameTolerance:
                    # keep track of stop time/frame for later
                    main_trial_target.tStop = t  # not accounting for scr refresh
                    main_trial_target.tStopRefresh = tThisFlipGlobal  # on global time
                    main_trial_target.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'main_trial_target.stopped')
                    # update status
                    main_trial_target.status = FINISHED
                    main_trial_target.setAutoDraw(False)
            
            # *main_resp* updates
            waitOnFlip = False
            
            # if main_resp is starting this frame...
            if main_resp.status == NOT_STARTED and tThisFlip >= targetOnset-frameTolerance:
                # keep track of start time/frame for later
                main_resp.frameNStart = frameN  # exact frame index
                main_resp.tStart = t  # local t and not account for scr refresh
                main_resp.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(main_resp, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'main_resp.started')
                # update status
                main_resp.status = STARTED
                # keyboard checking is just starting
                waitOnFlip = True
                win.callOnFlip(main_resp.clock.reset)  # t=0 on next screen flip
                win.callOnFlip(main_resp.clearEvents, eventType='keyboard')  # clear events on next screen flip
            
            # if main_resp is stopping this frame...
            if main_resp.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > main_resp.tStartRefresh + 2.0-frameTolerance:
                    # keep track of stop time/frame for later
                    main_resp.tStop = t  # not accounting for scr refresh
                    main_resp.tStopRefresh = tThisFlipGlobal  # on global time
                    main_resp.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'main_resp.stopped')
                    # update status
                    main_resp.status = FINISHED
                    main_resp.status = FINISHED
            if main_resp.status == STARTED and not waitOnFlip:
                theseKeys = main_resp.getKeys(keyList=['j','f'], ignoreKeys=["escape"], waitRelease=False)
                _main_resp_allKeys.extend(theseKeys)
                if len(_main_resp_allKeys):
                    main_resp.keys = _main_resp_allKeys[-1].name  # just the last key pressed
                    main_resp.rt = _main_resp_allKeys[-1].rt
                    main_resp.duration = _main_resp_allKeys[-1].duration
                    # was this correct?
                    if (main_resp.keys == str(corrKey)) or (main_resp.keys == corrKey):
                        main_resp.corr = 1
                    else:
                        main_resp.corr = 0
                    # a response ends the routine
                    continueRoutine = False
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, win=win)
                return
            # pause experiment here if requested
            if thisExp.status == PAUSED:
                pauseExperiment(
                    thisExp=thisExp, 
                    win=win, 
                    timers=[routineTimer, globalClock], 
                    currentRoutine=main_trial,
                )
                # skip the frame we paused on
                continue
            
            # has a Component requested the Routine to end?
            if not continueRoutine:
                main_trial.forceEnded = routineForceEnded = True
            # has the Routine been forcibly ended?
            if main_trial.forceEnded or routineForceEnded:
                break
            # has every Component finished?
            continueRoutine = False
            for thisComponent in main_trial.components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "main_trial" ---
        for thisComponent in main_trial.components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # store stop times for main_trial
        main_trial.tStop = globalClock.getTime(format='float')
        main_trial.tStopRefresh = tThisFlipGlobal
        thisExp.addData('main_trial.stopped', main_trial.tStop)
        # Run 'End Routine' code from main_trial_key_map
        prime_dur_ms = None
        if getattr(main_trial_prime, 'tStartRefresh', None) is not None and getattr(main_trial_prime, 'tStopRefresh', None) is not None:
            prime_dur_ms = (main_trial_prime.tStopRefresh - main_trial_prime.tStartRefresh) * 1000
        thisExp.addData('prime_actual_ms', prime_dur_ms)
        soa_actual_ms = None
        if getattr(main_trial_target, 'tStartRefresh', None) is not None and getattr(main_trial_prime, 'tStartRefresh', None) is not None:
            soa_actual_ms = (main_trial_target.tStartRefresh - main_trial_prime.tStartRefresh) * 1000
        thisExp.addData('soa_actual_ms', soa_actual_ms)
        # check responses
        if main_resp.keys in ['', [], None]:  # No response was made
            main_resp.keys = None
            # was no response the correct answer?!
            if str(corrKey).lower() == 'none':
               main_resp.corr = 1;  # correct non-response
            else:
               main_resp.corr = 0;  # failed to respond (incorrectly)
        # store data for main_trials_3 (TrialHandler)
        main_trials_3.addData('main_resp.keys',main_resp.keys)
        main_trials_3.addData('main_resp.corr', main_resp.corr)
        if main_resp.keys != None:  # we had a response
            main_trials_3.addData('main_resp.rt', main_resp.rt)
            main_trials_3.addData('main_resp.duration', main_resp.duration)
        # the Routine "main_trial" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        
        # --- Prepare to start Routine "main_iti" ---
        # create an object to store info about Routine main_iti
        main_iti = data.Routine(
            name='main_iti',
            components=[main_iti_blank],
        )
        main_iti.status = NOT_STARTED
        continueRoutine = True
        # update component parameters for each repeat
        # Run 'Begin Routine' code from main_iti_randomize
        itiDur = 0.6 + 0.1 * randint(0, 5)
        thisExp.addData('iti_duration', itiDur)
        # store start times for main_iti
        main_iti.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
        main_iti.tStart = globalClock.getTime(format='float')
        main_iti.status = STARTED
        thisExp.addData('main_iti.started', main_iti.tStart)
        main_iti.maxDuration = None
        # keep track of which components have finished
        main_itiComponents = main_iti.components
        for thisComponent in main_iti.components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "main_iti" ---
        thisExp.currentRoutine = main_iti
        main_iti.forceEnded = routineForceEnded = not continueRoutine
        while continueRoutine:
            # if trial has changed, end Routine now
            if hasattr(thisMain_trial_3, 'status') and thisMain_trial_3.status == STOPPING:
                continueRoutine = False
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *main_iti_blank* updates
            
            # if main_iti_blank is starting this frame...
            if main_iti_blank.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
                # keep track of start time/frame for later
                main_iti_blank.frameNStart = frameN  # exact frame index
                main_iti_blank.tStart = t  # local t and not account for scr refresh
                main_iti_blank.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(main_iti_blank, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'main_iti_blank.started')
                # update status
                main_iti_blank.status = STARTED
                main_iti_blank.setAutoDraw(True)
            
            # if main_iti_blank is active this frame...
            if main_iti_blank.status == STARTED:
                # update params
                pass
            
            # if main_iti_blank is stopping this frame...
            if main_iti_blank.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > main_iti_blank.tStartRefresh + itiDur-frameTolerance:
                    # keep track of stop time/frame for later
                    main_iti_blank.tStop = t  # not accounting for scr refresh
                    main_iti_blank.tStopRefresh = tThisFlipGlobal  # on global time
                    main_iti_blank.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'main_iti_blank.stopped')
                    # update status
                    main_iti_blank.status = FINISHED
                    main_iti_blank.setAutoDraw(False)
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, win=win)
                return
            # pause experiment here if requested
            if thisExp.status == PAUSED:
                pauseExperiment(
                    thisExp=thisExp, 
                    win=win, 
                    timers=[routineTimer, globalClock], 
                    currentRoutine=main_iti,
                )
                # skip the frame we paused on
                continue
            
            # has a Component requested the Routine to end?
            if not continueRoutine:
                main_iti.forceEnded = routineForceEnded = True
            # has the Routine been forcibly ended?
            if main_iti.forceEnded or routineForceEnded:
                break
            # has every Component finished?
            continueRoutine = False
            for thisComponent in main_iti.components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "main_iti" ---
        for thisComponent in main_iti.components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # store stop times for main_iti
        main_iti.tStop = globalClock.getTime(format='float')
        main_iti.tStopRefresh = tThisFlipGlobal
        thisExp.addData('main_iti.stopped', main_iti.tStop)
        # the Routine "main_iti" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        # mark thisMain_trial_3 as finished
        if hasattr(thisMain_trial_3, 'status'):
            thisMain_trial_3.status = FINISHED
        # if awaiting a pause, pause now
        if main_trials_3.status == PAUSED:
            thisExp.status = PAUSED
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[globalClock], 
            )
            # once done pausing, restore running status
            main_trials_3.status = STARTED
        thisExp.nextEntry()
        
    # completed 1.0 repeats of 'main_trials_3'
    main_trials_3.status = FINISHED
    
    if thisSession is not None:
        # if running in a Session with a Liaison client, send data up to now
        thisSession.sendExperimentData()
    # get names of stimulus parameters
    if main_trials_3.trialList in ([], [None], None):
        params = []
    else:
        params = main_trials_3.trialList[0].keys()
    # save data for this loop
    main_trials_3.saveAsText(filename + '_main_trials_3.csv', delim=',',
        stimOut=params,
        dataOut=['n','all_mean','all_std', 'all_raw'])
    
    # --- Prepare to start Routine "break_3_timer" ---
    # create an object to store info about Routine break_3_timer
    break_3_timer = data.Routine(
        name='break_3_timer',
        components=[break_3_display],
    )
    break_3_timer.status = NOT_STARTED
    continueRoutine = True
    # update component parameters for each repeat
    # Run 'Begin Routine' code from break_3_timer_code
    break_3_timer_clock = core.Clock()
    # store start times for break_3_timer
    break_3_timer.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
    break_3_timer.tStart = globalClock.getTime(format='float')
    break_3_timer.status = STARTED
    thisExp.addData('break_3_timer.started', break_3_timer.tStart)
    break_3_timer.maxDuration = None
    # keep track of which components have finished
    break_3_timerComponents = break_3_timer.components
    for thisComponent in break_3_timer.components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "break_3_timer" ---
    thisExp.currentRoutine = break_3_timer
    break_3_timer.forceEnded = routineForceEnded = not continueRoutine
    while continueRoutine and routineTimer.getTime() < 60.0:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *break_3_display* updates
        
        # if break_3_display is starting this frame...
        if break_3_display.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
            # keep track of start time/frame for later
            break_3_display.frameNStart = frameN  # exact frame index
            break_3_display.tStart = t  # local t and not account for scr refresh
            break_3_display.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(break_3_display, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'break_3_display.started')
            # update status
            break_3_display.status = STARTED
            break_3_display.setAutoDraw(True)
        
        # if break_3_display is active this frame...
        if break_3_display.status == STARTED:
            # update params
            pass
        
        # if break_3_display is stopping this frame...
        if break_3_display.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > break_3_display.tStartRefresh + 60.0-frameTolerance:
                # keep track of stop time/frame for later
                break_3_display.tStop = t  # not accounting for scr refresh
                break_3_display.tStopRefresh = tThisFlipGlobal  # on global time
                break_3_display.frameNStop = frameN  # exact frame index
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'break_3_display.stopped')
                # update status
                break_3_display.status = FINISHED
                break_3_display.setAutoDraw(False)
        # Run 'Each Frame' code from break_3_timer_code
        remaining = max(0, 60 - int(break_3_timer_clock.getTime()))
        break_3_display.setText(f'지금부터 1분간 쉬는시간입니다.\n\n남은 시간: {remaining}초')
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, win=win)
            return
        # pause experiment here if requested
        if thisExp.status == PAUSED:
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[routineTimer, globalClock], 
                currentRoutine=break_3_timer,
            )
            # skip the frame we paused on
            continue
        
        # has a Component requested the Routine to end?
        if not continueRoutine:
            break_3_timer.forceEnded = routineForceEnded = True
        # has the Routine been forcibly ended?
        if break_3_timer.forceEnded or routineForceEnded:
            break
        # has every Component finished?
        continueRoutine = False
        for thisComponent in break_3_timer.components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "break_3_timer" ---
    for thisComponent in break_3_timer.components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # store stop times for break_3_timer
    break_3_timer.tStop = globalClock.getTime(format='float')
    break_3_timer.tStopRefresh = tThisFlipGlobal
    thisExp.addData('break_3_timer.stopped', break_3_timer.tStop)
    # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
    if break_3_timer.maxDurationReached:
        routineTimer.addTime(-break_3_timer.maxDuration)
    elif break_3_timer.forceEnded:
        routineTimer.reset()
    else:
        routineTimer.addTime(-60.000000)
    thisExp.nextEntry()
    
    # --- Prepare to start Routine "break_3_ready" ---
    # create an object to store info about Routine break_3_ready
    break_3_ready = data.Routine(
        name='break_3_ready',
        components=[break_3_ready_text, break_3_ready_resp],
    )
    break_3_ready.status = NOT_STARTED
    continueRoutine = True
    # update component parameters for each repeat
    # create starting attributes for break_3_ready_resp
    break_3_ready_resp.keys = []
    break_3_ready_resp.rt = []
    _break_3_ready_resp_allKeys = []
    # store start times for break_3_ready
    break_3_ready.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
    break_3_ready.tStart = globalClock.getTime(format='float')
    break_3_ready.status = STARTED
    thisExp.addData('break_3_ready.started', break_3_ready.tStart)
    break_3_ready.maxDuration = None
    # keep track of which components have finished
    break_3_readyComponents = break_3_ready.components
    for thisComponent in break_3_ready.components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "break_3_ready" ---
    thisExp.currentRoutine = break_3_ready
    break_3_ready.forceEnded = routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *break_3_ready_text* updates
        
        # if break_3_ready_text is starting this frame...
        if break_3_ready_text.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
            # keep track of start time/frame for later
            break_3_ready_text.frameNStart = frameN  # exact frame index
            break_3_ready_text.tStart = t  # local t and not account for scr refresh
            break_3_ready_text.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(break_3_ready_text, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'break_3_ready_text.started')
            # update status
            break_3_ready_text.status = STARTED
            break_3_ready_text.setAutoDraw(True)
        
        # if break_3_ready_text is active this frame...
        if break_3_ready_text.status == STARTED:
            # update params
            pass
        
        # *break_3_ready_resp* updates
        waitOnFlip = False
        
        # if break_3_ready_resp is starting this frame...
        if break_3_ready_resp.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
            # keep track of start time/frame for later
            break_3_ready_resp.frameNStart = frameN  # exact frame index
            break_3_ready_resp.tStart = t  # local t and not account for scr refresh
            break_3_ready_resp.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(break_3_ready_resp, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'break_3_ready_resp.started')
            # update status
            break_3_ready_resp.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(break_3_ready_resp.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(break_3_ready_resp.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if break_3_ready_resp.status == STARTED and not waitOnFlip:
            theseKeys = break_3_ready_resp.getKeys(keyList=['space'], ignoreKeys=["escape"], waitRelease=False)
            _break_3_ready_resp_allKeys.extend(theseKeys)
            if len(_break_3_ready_resp_allKeys):
                break_3_ready_resp.keys = _break_3_ready_resp_allKeys[-1].name  # just the last key pressed
                break_3_ready_resp.rt = _break_3_ready_resp_allKeys[-1].rt
                break_3_ready_resp.duration = _break_3_ready_resp_allKeys[-1].duration
                # a response ends the routine
                continueRoutine = False
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, win=win)
            return
        # pause experiment here if requested
        if thisExp.status == PAUSED:
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[routineTimer, globalClock], 
                currentRoutine=break_3_ready,
            )
            # skip the frame we paused on
            continue
        
        # has a Component requested the Routine to end?
        if not continueRoutine:
            break_3_ready.forceEnded = routineForceEnded = True
        # has the Routine been forcibly ended?
        if break_3_ready.forceEnded or routineForceEnded:
            break
        # has every Component finished?
        continueRoutine = False
        for thisComponent in break_3_ready.components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "break_3_ready" ---
    for thisComponent in break_3_ready.components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # store stop times for break_3_ready
    break_3_ready.tStop = globalClock.getTime(format='float')
    break_3_ready.tStopRefresh = tThisFlipGlobal
    thisExp.addData('break_3_ready.stopped', break_3_ready.tStop)
    # check responses
    if break_3_ready_resp.keys in ['', [], None]:  # No response was made
        break_3_ready_resp.keys = None
    thisExp.addData('break_3_ready_resp.keys',break_3_ready_resp.keys)
    if break_3_ready_resp.keys != None:  # we had a response
        thisExp.addData('break_3_ready_resp.rt', break_3_ready_resp.rt)
        thisExp.addData('break_3_ready_resp.duration', break_3_ready_resp.duration)
    thisExp.nextEntry()
    # the Routine "break_3_ready" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # set up handler to look after randomisation of conditions etc
    main_trials_4 = data.TrialHandler2(
        name='main_trials_4',
        nReps=1.0, 
        method='sequential', 
        extraInfo=expInfo, 
        originPath=-1, 
        trialList=data.importConditions(
        mainFile, 
        selection='120:158'
    )
    , 
        seed=None, 
        isTrials=True, 
    )
    thisExp.addLoop(main_trials_4)  # add the loop to the experiment
    thisMain_trial_4 = main_trials_4.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisMain_trial_4.rgb)
    if thisMain_trial_4 != None:
        for paramName in thisMain_trial_4:
            globals()[paramName] = thisMain_trial_4[paramName]
    if thisSession is not None:
        # if running in a Session with a Liaison client, send data up to now
        thisSession.sendExperimentData()
    
    for thisMain_trial_4 in main_trials_4:
        main_trials_4.status = STARTED
        if hasattr(thisMain_trial_4, 'status'):
            thisMain_trial_4.status = STARTED
        currentLoop = main_trials_4
        thisExp.timestampOnFlip(win, 'thisRow.t', format=globalClock.format)
        if thisSession is not None:
            # if running in a Session with a Liaison client, send data up to now
            thisSession.sendExperimentData()
        # abbreviate parameter names if possible (e.g. rgb = thisMain_trial_4.rgb)
        if thisMain_trial_4 != None:
            for paramName in thisMain_trial_4:
                globals()[paramName] = thisMain_trial_4[paramName]
        
        # --- Prepare to start Routine "main_trial" ---
        # create an object to store info about Routine main_trial
        main_trial = data.Routine(
            name='main_trial',
            components=[main_trial_fixation, main_trial_mask, main_trial_prime, main_trial_target, main_resp],
        )
        main_trial.status = NOT_STARTED
        continueRoutine = True
        # update component parameters for each repeat
        # Run 'Begin Routine' code from main_trial_key_map
        corrKey = 'j' if correct_response == 'word_key' else 'f'
        thisExp.addData('resolved_correct_key', corrKey)
        main_trial_prime.setText(prime_word)
        main_trial_target.setText(stimulus)
        # create starting attributes for main_resp
        main_resp.keys = []
        main_resp.rt = []
        _main_resp_allKeys = []
        # store start times for main_trial
        main_trial.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
        main_trial.tStart = globalClock.getTime(format='float')
        main_trial.status = STARTED
        thisExp.addData('main_trial.started', main_trial.tStart)
        main_trial.maxDuration = None
        # keep track of which components have finished
        main_trialComponents = main_trial.components
        for thisComponent in main_trial.components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "main_trial" ---
        thisExp.currentRoutine = main_trial
        main_trial.forceEnded = routineForceEnded = not continueRoutine
        while continueRoutine:
            # if trial has changed, end Routine now
            if hasattr(thisMain_trial_4, 'status') and thisMain_trial_4.status == STOPPING:
                continueRoutine = False
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *main_trial_fixation* updates
            
            # if main_trial_fixation is starting this frame...
            if main_trial_fixation.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                main_trial_fixation.frameNStart = frameN  # exact frame index
                main_trial_fixation.tStart = t  # local t and not account for scr refresh
                main_trial_fixation.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(main_trial_fixation, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'main_trial_fixation.started')
                # update status
                main_trial_fixation.status = STARTED
                main_trial_fixation.setAutoDraw(True)
            
            # if main_trial_fixation is active this frame...
            if main_trial_fixation.status == STARTED:
                # update params
                pass
            
            # if main_trial_fixation is stopping this frame...
            if main_trial_fixation.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > main_trial_fixation.tStartRefresh + 0.5-frameTolerance:
                    # keep track of stop time/frame for later
                    main_trial_fixation.tStop = t  # not accounting for scr refresh
                    main_trial_fixation.tStopRefresh = tThisFlipGlobal  # on global time
                    main_trial_fixation.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'main_trial_fixation.stopped')
                    # update status
                    main_trial_fixation.status = FINISHED
                    main_trial_fixation.setAutoDraw(False)
            
            # *main_trial_mask* updates
            
            # if main_trial_mask is starting this frame...
            if main_trial_mask.status == NOT_STARTED and tThisFlip >= 0.5-frameTolerance:
                # keep track of start time/frame for later
                main_trial_mask.frameNStart = frameN  # exact frame index
                main_trial_mask.tStart = t  # local t and not account for scr refresh
                main_trial_mask.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(main_trial_mask, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'main_trial_mask.started')
                # update status
                main_trial_mask.status = STARTED
                main_trial_mask.setAutoDraw(True)
            
            # if main_trial_mask is active this frame...
            if main_trial_mask.status == STARTED:
                # update params
                pass
            
            # if main_trial_mask is stopping this frame...
            if main_trial_mask.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > main_trial_mask.tStartRefresh + 0.5-frameTolerance:
                    # keep track of stop time/frame for later
                    main_trial_mask.tStop = t  # not accounting for scr refresh
                    main_trial_mask.tStopRefresh = tThisFlipGlobal  # on global time
                    main_trial_mask.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'main_trial_mask.stopped')
                    # update status
                    main_trial_mask.status = FINISHED
                    main_trial_mask.setAutoDraw(False)
            
            # *main_trial_prime* updates
            
            # if main_trial_prime is starting this frame...
            if main_trial_prime.status == NOT_STARTED and tThisFlip >= 1.0-frameTolerance:
                # keep track of start time/frame for later
                main_trial_prime.frameNStart = frameN  # exact frame index
                main_trial_prime.tStart = t  # local t and not account for scr refresh
                main_trial_prime.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(main_trial_prime, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'main_trial_prime.started')
                # update status
                main_trial_prime.status = STARTED
                main_trial_prime.setAutoDraw(True)
            
            # if main_trial_prime is active this frame...
            if main_trial_prime.status == STARTED:
                # update params
                pass
            
            # if main_trial_prime is stopping this frame...
            if main_trial_prime.status == STARTED:
                if frameN >= (main_trial_prime.frameNStart + primeFrames):
                    # keep track of stop time/frame for later
                    main_trial_prime.tStop = t  # not accounting for scr refresh
                    main_trial_prime.tStopRefresh = tThisFlipGlobal  # on global time
                    main_trial_prime.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'main_trial_prime.stopped')
                    # update status
                    main_trial_prime.status = FINISHED
                    main_trial_prime.setAutoDraw(False)
            
            # *main_trial_target* updates
            
            # if main_trial_target is starting this frame...
            if main_trial_target.status == NOT_STARTED and tThisFlip >= targetOnset-frameTolerance:
                # keep track of start time/frame for later
                main_trial_target.frameNStart = frameN  # exact frame index
                main_trial_target.tStart = t  # local t and not account for scr refresh
                main_trial_target.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(main_trial_target, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'main_trial_target.started')
                # update status
                main_trial_target.status = STARTED
                main_trial_target.setAutoDraw(True)
            
            # if main_trial_target is active this frame...
            if main_trial_target.status == STARTED:
                # update params
                pass
            
            # if main_trial_target is stopping this frame...
            if main_trial_target.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > main_trial_target.tStartRefresh + 2.0-frameTolerance:
                    # keep track of stop time/frame for later
                    main_trial_target.tStop = t  # not accounting for scr refresh
                    main_trial_target.tStopRefresh = tThisFlipGlobal  # on global time
                    main_trial_target.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'main_trial_target.stopped')
                    # update status
                    main_trial_target.status = FINISHED
                    main_trial_target.setAutoDraw(False)
            
            # *main_resp* updates
            waitOnFlip = False
            
            # if main_resp is starting this frame...
            if main_resp.status == NOT_STARTED and tThisFlip >= targetOnset-frameTolerance:
                # keep track of start time/frame for later
                main_resp.frameNStart = frameN  # exact frame index
                main_resp.tStart = t  # local t and not account for scr refresh
                main_resp.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(main_resp, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'main_resp.started')
                # update status
                main_resp.status = STARTED
                # keyboard checking is just starting
                waitOnFlip = True
                win.callOnFlip(main_resp.clock.reset)  # t=0 on next screen flip
                win.callOnFlip(main_resp.clearEvents, eventType='keyboard')  # clear events on next screen flip
            
            # if main_resp is stopping this frame...
            if main_resp.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > main_resp.tStartRefresh + 2.0-frameTolerance:
                    # keep track of stop time/frame for later
                    main_resp.tStop = t  # not accounting for scr refresh
                    main_resp.tStopRefresh = tThisFlipGlobal  # on global time
                    main_resp.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'main_resp.stopped')
                    # update status
                    main_resp.status = FINISHED
                    main_resp.status = FINISHED
            if main_resp.status == STARTED and not waitOnFlip:
                theseKeys = main_resp.getKeys(keyList=['j','f'], ignoreKeys=["escape"], waitRelease=False)
                _main_resp_allKeys.extend(theseKeys)
                if len(_main_resp_allKeys):
                    main_resp.keys = _main_resp_allKeys[-1].name  # just the last key pressed
                    main_resp.rt = _main_resp_allKeys[-1].rt
                    main_resp.duration = _main_resp_allKeys[-1].duration
                    # was this correct?
                    if (main_resp.keys == str(corrKey)) or (main_resp.keys == corrKey):
                        main_resp.corr = 1
                    else:
                        main_resp.corr = 0
                    # a response ends the routine
                    continueRoutine = False
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, win=win)
                return
            # pause experiment here if requested
            if thisExp.status == PAUSED:
                pauseExperiment(
                    thisExp=thisExp, 
                    win=win, 
                    timers=[routineTimer, globalClock], 
                    currentRoutine=main_trial,
                )
                # skip the frame we paused on
                continue
            
            # has a Component requested the Routine to end?
            if not continueRoutine:
                main_trial.forceEnded = routineForceEnded = True
            # has the Routine been forcibly ended?
            if main_trial.forceEnded or routineForceEnded:
                break
            # has every Component finished?
            continueRoutine = False
            for thisComponent in main_trial.components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "main_trial" ---
        for thisComponent in main_trial.components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # store stop times for main_trial
        main_trial.tStop = globalClock.getTime(format='float')
        main_trial.tStopRefresh = tThisFlipGlobal
        thisExp.addData('main_trial.stopped', main_trial.tStop)
        # Run 'End Routine' code from main_trial_key_map
        prime_dur_ms = None
        if getattr(main_trial_prime, 'tStartRefresh', None) is not None and getattr(main_trial_prime, 'tStopRefresh', None) is not None:
            prime_dur_ms = (main_trial_prime.tStopRefresh - main_trial_prime.tStartRefresh) * 1000
        thisExp.addData('prime_actual_ms', prime_dur_ms)
        soa_actual_ms = None
        if getattr(main_trial_target, 'tStartRefresh', None) is not None and getattr(main_trial_prime, 'tStartRefresh', None) is not None:
            soa_actual_ms = (main_trial_target.tStartRefresh - main_trial_prime.tStartRefresh) * 1000
        thisExp.addData('soa_actual_ms', soa_actual_ms)
        # check responses
        if main_resp.keys in ['', [], None]:  # No response was made
            main_resp.keys = None
            # was no response the correct answer?!
            if str(corrKey).lower() == 'none':
               main_resp.corr = 1;  # correct non-response
            else:
               main_resp.corr = 0;  # failed to respond (incorrectly)
        # store data for main_trials_4 (TrialHandler)
        main_trials_4.addData('main_resp.keys',main_resp.keys)
        main_trials_4.addData('main_resp.corr', main_resp.corr)
        if main_resp.keys != None:  # we had a response
            main_trials_4.addData('main_resp.rt', main_resp.rt)
            main_trials_4.addData('main_resp.duration', main_resp.duration)
        # the Routine "main_trial" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        
        # --- Prepare to start Routine "main_iti" ---
        # create an object to store info about Routine main_iti
        main_iti = data.Routine(
            name='main_iti',
            components=[main_iti_blank],
        )
        main_iti.status = NOT_STARTED
        continueRoutine = True
        # update component parameters for each repeat
        # Run 'Begin Routine' code from main_iti_randomize
        itiDur = 0.6 + 0.1 * randint(0, 5)
        thisExp.addData('iti_duration', itiDur)
        # store start times for main_iti
        main_iti.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
        main_iti.tStart = globalClock.getTime(format='float')
        main_iti.status = STARTED
        thisExp.addData('main_iti.started', main_iti.tStart)
        main_iti.maxDuration = None
        # keep track of which components have finished
        main_itiComponents = main_iti.components
        for thisComponent in main_iti.components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "main_iti" ---
        thisExp.currentRoutine = main_iti
        main_iti.forceEnded = routineForceEnded = not continueRoutine
        while continueRoutine:
            # if trial has changed, end Routine now
            if hasattr(thisMain_trial_4, 'status') and thisMain_trial_4.status == STOPPING:
                continueRoutine = False
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *main_iti_blank* updates
            
            # if main_iti_blank is starting this frame...
            if main_iti_blank.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
                # keep track of start time/frame for later
                main_iti_blank.frameNStart = frameN  # exact frame index
                main_iti_blank.tStart = t  # local t and not account for scr refresh
                main_iti_blank.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(main_iti_blank, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'main_iti_blank.started')
                # update status
                main_iti_blank.status = STARTED
                main_iti_blank.setAutoDraw(True)
            
            # if main_iti_blank is active this frame...
            if main_iti_blank.status == STARTED:
                # update params
                pass
            
            # if main_iti_blank is stopping this frame...
            if main_iti_blank.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > main_iti_blank.tStartRefresh + itiDur-frameTolerance:
                    # keep track of stop time/frame for later
                    main_iti_blank.tStop = t  # not accounting for scr refresh
                    main_iti_blank.tStopRefresh = tThisFlipGlobal  # on global time
                    main_iti_blank.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'main_iti_blank.stopped')
                    # update status
                    main_iti_blank.status = FINISHED
                    main_iti_blank.setAutoDraw(False)
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, win=win)
                return
            # pause experiment here if requested
            if thisExp.status == PAUSED:
                pauseExperiment(
                    thisExp=thisExp, 
                    win=win, 
                    timers=[routineTimer, globalClock], 
                    currentRoutine=main_iti,
                )
                # skip the frame we paused on
                continue
            
            # has a Component requested the Routine to end?
            if not continueRoutine:
                main_iti.forceEnded = routineForceEnded = True
            # has the Routine been forcibly ended?
            if main_iti.forceEnded or routineForceEnded:
                break
            # has every Component finished?
            continueRoutine = False
            for thisComponent in main_iti.components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "main_iti" ---
        for thisComponent in main_iti.components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # store stop times for main_iti
        main_iti.tStop = globalClock.getTime(format='float')
        main_iti.tStopRefresh = tThisFlipGlobal
        thisExp.addData('main_iti.stopped', main_iti.tStop)
        # the Routine "main_iti" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        # mark thisMain_trial_4 as finished
        if hasattr(thisMain_trial_4, 'status'):
            thisMain_trial_4.status = FINISHED
        # if awaiting a pause, pause now
        if main_trials_4.status == PAUSED:
            thisExp.status = PAUSED
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[globalClock], 
            )
            # once done pausing, restore running status
            main_trials_4.status = STARTED
        thisExp.nextEntry()
        
    # completed 1.0 repeats of 'main_trials_4'
    main_trials_4.status = FINISHED
    
    if thisSession is not None:
        # if running in a Session with a Liaison client, send data up to now
        thisSession.sendExperimentData()
    # get names of stimulus parameters
    if main_trials_4.trialList in ([], [None], None):
        params = []
    else:
        params = main_trials_4.trialList[0].keys()
    # save data for this loop
    main_trials_4.saveAsText(filename + '_main_trials_4.csv', delim=',',
        stimOut=params,
        dataOut=['n','all_mean','all_std', 'all_raw'])
    
    # --- Prepare to start Routine "finish" ---
    # create an object to store info about Routine finish
    finish = data.Routine(
        name='finish',
        components=[finish_text, finish_resp],
    )
    finish.status = NOT_STARTED
    continueRoutine = True
    # update component parameters for each repeat
    # create starting attributes for finish_resp
    finish_resp.keys = []
    finish_resp.rt = []
    _finish_resp_allKeys = []
    # store start times for finish
    finish.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
    finish.tStart = globalClock.getTime(format='float')
    finish.status = STARTED
    thisExp.addData('finish.started', finish.tStart)
    finish.maxDuration = None
    # keep track of which components have finished
    finishComponents = finish.components
    for thisComponent in finish.components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "finish" ---
    thisExp.currentRoutine = finish
    finish.forceEnded = routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *finish_text* updates
        
        # if finish_text is starting this frame...
        if finish_text.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
            # keep track of start time/frame for later
            finish_text.frameNStart = frameN  # exact frame index
            finish_text.tStart = t  # local t and not account for scr refresh
            finish_text.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(finish_text, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'finish_text.started')
            # update status
            finish_text.status = STARTED
            finish_text.setAutoDraw(True)
        
        # if finish_text is active this frame...
        if finish_text.status == STARTED:
            # update params
            pass
        
        # *finish_resp* updates
        waitOnFlip = False
        
        # if finish_resp is starting this frame...
        if finish_resp.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
            # keep track of start time/frame for later
            finish_resp.frameNStart = frameN  # exact frame index
            finish_resp.tStart = t  # local t and not account for scr refresh
            finish_resp.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(finish_resp, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'finish_resp.started')
            # update status
            finish_resp.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(finish_resp.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(finish_resp.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if finish_resp.status == STARTED and not waitOnFlip:
            theseKeys = finish_resp.getKeys(keyList=['space'], ignoreKeys=["escape"], waitRelease=False)
            _finish_resp_allKeys.extend(theseKeys)
            if len(_finish_resp_allKeys):
                finish_resp.keys = _finish_resp_allKeys[-1].name  # just the last key pressed
                finish_resp.rt = _finish_resp_allKeys[-1].rt
                finish_resp.duration = _finish_resp_allKeys[-1].duration
                # a response ends the routine
                continueRoutine = False
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, win=win)
            return
        # pause experiment here if requested
        if thisExp.status == PAUSED:
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[routineTimer, globalClock], 
                currentRoutine=finish,
            )
            # skip the frame we paused on
            continue
        
        # has a Component requested the Routine to end?
        if not continueRoutine:
            finish.forceEnded = routineForceEnded = True
        # has the Routine been forcibly ended?
        if finish.forceEnded or routineForceEnded:
            break
        # has every Component finished?
        continueRoutine = False
        for thisComponent in finish.components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "finish" ---
    for thisComponent in finish.components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # store stop times for finish
    finish.tStop = globalClock.getTime(format='float')
    finish.tStopRefresh = tThisFlipGlobal
    thisExp.addData('finish.stopped', finish.tStop)
    # check responses
    if finish_resp.keys in ['', [], None]:  # No response was made
        finish_resp.keys = None
    thisExp.addData('finish_resp.keys',finish_resp.keys)
    if finish_resp.keys != None:  # we had a response
        thisExp.addData('finish_resp.rt', finish_resp.rt)
        thisExp.addData('finish_resp.duration', finish_resp.duration)
    thisExp.nextEntry()
    # the Routine "finish" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # mark experiment as finished
    endExperiment(thisExp, win=win)


def saveData(thisExp):
    """
    Save data from this experiment
    
    Parameters
    ==========
    thisExp : psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    """
    filename = thisExp.dataFileName
    # these shouldn't be strictly necessary (should auto-save)
    thisExp.saveAsWideText(filename + '.csv', delim='comma')
    thisExp.saveAsPickle(filename)


def endExperiment(thisExp, win=None):
    """
    End this experiment, performing final shut down operations.
    
    This function does NOT close the window or end the Python process - use `quit` for this.
    
    Parameters
    ==========
    thisExp : psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    win : psychopy.visual.Window
        Window for this experiment.
    """
    # stop any playback components
    if thisExp.currentRoutine is not None:
        for comp in thisExp.currentRoutine.getPlaybackComponents():
            comp.stop()
    if win is not None:
        # remove autodraw from all current components
        win.clearAutoDraw()
        # Flip one final time so any remaining win.callOnFlip() 
        # and win.timeOnFlip() tasks get executed
        win.flip()
    # return console logger level to WARNING
    logging.console.setLevel(logging.WARNING)
    # mark experiment handler as finished
    thisExp.status = FINISHED
    # run any 'at exit' functions
    for fcn in runAtExit:
        fcn()
    logging.flush()


def quit(thisExp, win=None, thisSession=None):
    """
    Fully quit, closing the window and ending the Python process.
    
    Parameters
    ==========
    win : psychopy.visual.Window
        Window to close.
    thisSession : psychopy.session.Session or None
        Handle of the Session object this experiment is being run from, if any.
    """
    thisExp.abort()  # or data files will save again on exit
    # make sure everything is closed down
    if win is not None:
        # Flip one final time so any remaining win.callOnFlip() 
        # and win.timeOnFlip() tasks get executed before quitting
        win.flip()
        win.close()
    logging.flush()
    if thisSession is not None:
        thisSession.stop()
    # terminate Python process
    core.quit()


# if running this experiment as a script...
if __name__ == '__main__':
    # call all functions in order
    expInfo = showExpInfoDlg(expInfo=expInfo)
    thisExp = setupData(expInfo=expInfo)
    logFile = setupLogging(filename=thisExp.dataFileName)
    win = setupWindow(expInfo=expInfo)
    setupDevices(expInfo=expInfo, thisExp=thisExp, win=win)
    run(
        expInfo=expInfo, 
        thisExp=thisExp, 
        win=win,
        globalClock='float'
    )
    saveData(thisExp=thisExp)
    quit(thisExp=thisExp, win=win)
